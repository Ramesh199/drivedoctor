"""PyQt6 dashboard for safe disk imaging and image-only file carving."""

import sys
import threading
from pathlib import Path

from PyQt6.QtCore import QThread, pyqtSignal
from PyQt6.QtWidgets import (
    QApplication, QComboBox, QFileDialog, QFormLayout, QHBoxLayout, QLabel,
    QLineEdit, QMainWindow, QMessageBox, QPushButton, QProgressBar, QTableWidget,
    QTableWidgetItem, QVBoxLayout, QWidget,
)

from diskretrieve.carving import CarvedFile, export_carved, scan_image
from diskretrieve.devices import Disk, assert_destination_is_separate, list_disks
from diskretrieve.imaging import image_disk


class ImagingWorker(QThread):
    progress_changed = pyqtSignal(int, int, str)
    failed = pyqtSignal(str)
    completed = pyqtSignal()

    def __init__(self, disk: Disk, image_path: str):
        super().__init__()
        self.disk = disk
        self.image_path = image_path
        self.cancelled = threading.Event()

    def run(self):
        try:
            image_disk(
                self.disk.device_path,
                self.disk.number,
                self.disk.size,
                self.image_path,
                cancelled=self.cancelled,
                progress=self.progress_changed.emit,
            )
            self.completed.emit()
        except Exception as exc:
            self.failed.emit(str(exc))

    def cancel(self):
        self.cancelled.set()


class ScanWorker(QThread):
    progress_changed = pyqtSignal(int, int)
    results_ready = pyqtSignal(object)
    failed = pyqtSignal(str)

    def __init__(self, image_path: str):
        super().__init__()
        self.image_path = image_path
        self.cancelled = threading.Event()

    def run(self):
        try:
            self.results_ready.emit(
                scan_image(self.image_path, cancelled=self.cancelled,
                           progress=self.progress_changed.emit)
            )
        except Exception as exc:
            self.failed.emit(str(exc))

    def cancel(self):
        self.cancelled.set()


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("DiskRetrieve — Read-only recovery")
        self.resize(900, 650)
        self.disks: list[Disk] = []
        self.carved: list[CarvedFile] = []
        self.worker = None

        root = QWidget()
        layout = QVBoxLayout(root)
        form = QFormLayout()
        self.disk_combo = QComboBox()
        self.image_path = QLineEdit()
        image_browse = QPushButton("Browse…")
        image_browse.clicked.connect(self._browse_image)
        image_row = QHBoxLayout()
        image_row.addWidget(self.image_path)
        image_row.addWidget(image_browse)
        image_container = QWidget()
        image_container.setLayout(image_row)
        form.addRow("Source physical disk:", self.disk_combo)
        form.addRow("Image destination:", image_container)
        layout.addLayout(form)

        self.partition_label = QLabel("Partitions and filesystems: not loaded")
        self.partition_label.setWordWrap(True)
        layout.addWidget(self.partition_label)
        self.health_label = QLabel(
            "Health is Windows-reported status only; raw SMART attributes are not available."
        )
        self.health_label.setWordWrap(True)
        layout.addWidget(self.health_label)

        buttons = QHBoxLayout()
        self.refresh_button = QPushButton("Refresh disks")
        self.refresh_button.clicked.connect(self._refresh_disks)
        self.image_button = QPushButton("Image source")
        self.image_button.clicked.connect(self._start_imaging)
        self.cancel_button = QPushButton("Cancel")
        self.cancel_button.setEnabled(False)
        self.cancel_button.clicked.connect(self._cancel)
        buttons.addWidget(self.refresh_button)
        buttons.addWidget(self.image_button)
        buttons.addWidget(self.cancel_button)
        layout.addLayout(buttons)
        self.progress = QProgressBar()
        layout.addWidget(self.progress)
        self.status = QLabel("Source opens read-only. Image files are never written to the source.")
        layout.addWidget(self.status)

        recovery = QHBoxLayout()
        self.recovery_path = QLineEdit()
        self.recovery_path.setPlaceholderText("Disk image to scan")
        recovery_browse = QPushButton("Choose image…")
        recovery_browse.clicked.connect(self._browse_recovery)
        self.scan_button = QPushButton("Scan image")
        self.scan_button.clicked.connect(self._start_scan)
        recovery.addWidget(self.recovery_path)
        recovery.addWidget(recovery_browse)
        recovery.addWidget(self.scan_button)
        layout.addLayout(recovery)
        self.results = QTableWidget(0, 3)
        self.results.setHorizontalHeaderLabels(["Recovered candidate", "Offset", "Length"])
        self.results.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.results)
        self.export_button = QPushButton("Export selected candidate…")
        self.export_button.clicked.connect(self._export_selected)
        layout.addWidget(self.export_button)
        self.setCentralWidget(root)
        self._refresh_disks()

    def _refresh_disks(self):
        try:
            self.disks = list_disks()
            self.disk_combo.clear()
            for disk in self.disks:
                self.disk_combo.addItem(str(disk), disk)
            if not self.disks:
                self.partition_label.setText("No physical disks found.")
        except Exception as exc:
            QMessageBox.critical(self, "Disk diagnostics failed", str(exc))

    def _selected_disk(self):
        return self.disk_combo.currentData()

    def _browse_image(self):
        path, _ = QFileDialog.getSaveFileName(self, "Choose image destination", "", "Raw image (*.img *.dd);;All files (*)")
        if path:
            self.image_path.setText(path)

    def _browse_recovery(self):
        path, _ = QFileDialog.getOpenFileName(self, "Choose disk image", "", "Disk images (*.img *.dd);;All files (*)")
        if path:
            self.recovery_path.setText(path)

    def _start_imaging(self):
        disk = self._selected_disk()
        path = self.image_path.text().strip()
        if disk is None or not path:
            QMessageBox.warning(self, "Missing input", "Select a source disk and image destination.")
            return
        if Path(path).exists() and not Path(path + ".map.json").exists():
            QMessageBox.warning(self, "Refusing overwrite", "Image already exists without its mapfile.")
            return
        self.worker = ImagingWorker(disk, path)
        self.worker.progress_changed.connect(self._image_progress)
        self.worker.failed.connect(self._failed)
        self.worker.completed.connect(lambda: self._finished("Imaging complete."))
        self._set_running(True)
        self.worker.start()

    def _image_progress(self, done: int, total: int, message: str):
        self.progress.setRange(0, max(1, total))
        self.progress.setValue(min(done, total))
        self.status.setText(message)

    def _start_scan(self):
        path = self.recovery_path.text().strip()
        if not path or not Path(path).is_file():
            QMessageBox.warning(self, "Missing image", "Choose an existing disk image.")
            return
        self.worker = ScanWorker(path)
        self.worker.progress_changed.connect(self._scan_progress)
        self.worker.results_ready.connect(self._scan_done)
        self.worker.failed.connect(self._failed)
        self._set_running(True)
        self.worker.start()

    def _scan_progress(self, done: int, total: int):
        self.progress.setRange(0, max(1, total))
        self.progress.setValue(min(done, total))
        self.status.setText(f"Scanning image: {done:,} / {total:,} bytes")

    def _scan_done(self, found):
        self.carved = list(found)
        self.results.setRowCount(len(self.carved))
        for row, item in enumerate(self.carved):
            for col, value in enumerate((item.name, f"0x{item.offset:x}", str(item.length))):
                self.results.setItem(row, col, QTableWidgetItem(value))
        self._set_running(False)
        self.status.setText(f"Scan complete: {len(self.carved)} candidate(s).")

    def _export_selected(self):
        row = self.results.currentRow()
        if row < 0 or row >= len(self.carved):
            QMessageBox.information(self, "Select a candidate", "Select a recovered candidate first.")
            return
        item = self.carved[row]
        path, _ = QFileDialog.getSaveFileName(self, "Export recovered file", item.name)
        if not path:
            return
        try:
            disk = self._selected_disk()
            if disk is None:
                raise ValueError("Select the source disk before exporting so the destination can be checked.")
            assert_destination_is_separate(path, disk.number)
            export_carved(self.recovery_path.text().strip(), item, path)
        except Exception as exc:
            QMessageBox.critical(self, "Export failed", str(exc))
        else:
            self.status.setText(f"Exported {item.name}")

    def _cancel(self):
        if self.worker is not None:
            self.worker.cancel()
            self.status.setText("Cancellation requested…")

    def _failed(self, message: str):
        self._set_running(False)
        QMessageBox.critical(self, "Operation failed", message)

    def _finished(self, message: str):
        self._set_running(False)
        self.status.setText(message)

    def _set_running(self, running: bool):
        self.refresh_button.setEnabled(not running)
        self.image_button.setEnabled(not running)
        self.scan_button.setEnabled(not running)
        self.cancel_button.setEnabled(running)


def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
