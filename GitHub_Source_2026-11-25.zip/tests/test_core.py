import tempfile
import unittest
import zipfile
from pathlib import Path

from diskretrieve.carving import _is_docx, scan_image
from diskretrieve.imaging import RangeMap


class RangeMapTests(unittest.TestCase):
    def test_splits_and_merges_status_ranges(self):
        ranges = RangeMap(100)
        ranges.set(20, 10, "finished")
        ranges.set(30, 10, "finished")
        self.assertEqual(
            [(r.offset, r.length, r.status) for r in ranges.ranges],
            [(0, 20, "untested"), (20, 20, "finished"), (40, 60, "untested")],
        )

    def test_rejects_incomplete_map(self):
        with self.assertRaises(ValueError):
            RangeMap(100, [{"offset": 0, "length": 99, "status": "finished"}])


class CarvingTests(unittest.TestCase):
    def test_scans_png_from_image(self):
        data = b"prefix" + b"\x89PNG\r\n\x1a\n" + b"payloadIEND" + b"\x00\x00\x00\x00"
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "sample.img"
            path.write_bytes(data)
            found = scan_image(str(path))
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].offset, 6)
        self.assertEqual(found[0].extension, "png")

    def test_identifies_docx_zip(self):
        import io
        buffer = io.BytesIO()
        with zipfile.ZipFile(buffer, "w") as archive:
            archive.writestr("word/document.xml", "<document/>")
        self.assertTrue(_is_docx(buffer.getvalue(), "zip"))

    def test_scans_signature_across_chunk_boundary(self):
        from diskretrieve.carving import CHUNK_SIZE
        data = b"x" * (CHUNK_SIZE - 4) + b"\x89PNG\r\n\x1a\n" + b"payloadIEND" + b"\x00\x00\x00\x00"
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "boundary.img"
            path.write_bytes(data)
            found = scan_image(str(path))
        self.assertEqual(len(found), 1)
        self.assertEqual(found[0].offset, CHUNK_SIZE - 4)
        self.assertEqual(found[0].extension, "png")

    def test_scans_mp4_footprint(self):
        data = b"prefix" + (24).to_bytes(4, "big") + b"ftyp" + b"isom" + b"x" * 12
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "sample.mp4.img"
            path.write_bytes(data)
            found = scan_image(str(path))
        mp4 = [item for item in found if item.extension == "mp4"]
        self.assertEqual(len(mp4), 1)
        self.assertEqual(mp4[0].offset, 6)
        self.assertEqual(mp4[0].length, 24)


if __name__ == "__main__":
    unittest.main()
