"""Streaming signature-based file carving from a disk image."""

import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Callable


@dataclass(frozen=True)
class CarvedFile:
    offset: int
    length: int
    extension: str

    @property
    def name(self) -> str:
        return f"recovered_{self.offset:012x}.{self.extension}"


CHUNK_SIZE = 4 * 1024 * 1024
MAX_CARVE_SIZE = 512 * 1024 * 1024
SIGNATURES = (
    (b"\x89PNG\r\n\x1a\n", "png"),
    (b"\xff\xd8\xff", "jpg"),
    (b"%PDF-", "pdf"),
    (b"PK\x03\x04", "zip"),
    (b"ftyp", "mp4"),
)


def _find(data: bytes, start: int, needle: bytes) -> int:
    return data.find(needle, start)


def _find_end_at_stream(
    stream,
    absolute: int,
    extension: str,
    total: int,
) -> int | None:
    limit = min(total, absolute + MAX_CARVE_SIZE)
    position = absolute
    carry = b""
    while position < limit:
        stream.seek(position)
        chunk = stream.read(min(CHUNK_SIZE, limit - position))
        if not chunk:
            return None
        data = carry + chunk
        base = position - len(carry)
        if extension == "png":
            marker = _find(data, 0, b"IEND")
            if marker >= 0:
                end = base + marker + 8
                if end >= absolute:
                    return end
        elif extension == "jpg":
            marker = _find(data, 0, b"\xff\xd9")
            if marker >= 0:
                end = base + marker + 2
                if end >= absolute:
                    return end
        elif extension == "pdf":
            marker = _find(data, 0, b"%%EOF")
            if marker >= 0:
                end = base + marker + 5
                if end >= absolute:
                    return end
        elif extension == "zip":
            marker = _find(data, 0, b"PK\x05\x06")
            if marker >= 0 and marker + 22 <= len(data):
                comment_length = int.from_bytes(data[marker + 20:marker + 22], "little")
                end = base + marker + 22 + comment_length
                if end >= absolute:
                    return end
        elif extension == "mp4" and absolute >= 4:
            stream.seek(absolute)
            size_bytes = stream.read(4)
            if len(size_bytes) == 4:
                size = int.from_bytes(size_bytes, "big")
                if 8 <= size <= MAX_CARVE_SIZE:
                    end = absolute + size
                    if end <= limit:
                        return end
        position += len(chunk)
        carry = data[-64 * 1024:]
    return None


def scan_image(
    image_path: str,
    *,
    cancelled=None,
    progress: Callable[[int, int], None] | None = None,
) -> list[CarvedFile]:
    """Scan an image without modifying it; results are offsets, not extracted data."""
    image = Path(image_path)
    total = image.stat().st_size
    overlap = max(64 * 1024, len(b"PK\x05\x06") + 22 + 65535)
    found: list[CarvedFile] = []
    seen_offsets: set[int] = set()
    position = 0
    carry = b""
    with image.open("rb") as stream:
        while True:
            if cancelled is not None and cancelled.is_set():
                raise InterruptedError("Image scan cancelled.")
            chunk = stream.read(CHUNK_SIZE)
            if not chunk:
                break
            data = carry + chunk
            base = position - len(carry)
            for signature, extension in SIGNATURES:
                cursor = 0
                while True:
                    start = _find(data, cursor, signature)
                    if start < 0:
                        break
                    absolute = base + start
                    cursor = start + len(signature)
                    if absolute in seen_offsets or absolute < 0:
                        continue
                    if extension == "mp4":
                        absolute -= 4
                        if absolute < 0:
                            continue
                    end = _find_end_at_stream(stream, absolute, extension, total)
                    if end is None:
                        continue
                    length = end - absolute
                    if 0 < length <= MAX_CARVE_SIZE:
                        if extension == "zip":
                            stream.seek(absolute)
                            candidate = stream.read(length)
                            extension = "docx" if _is_docx(candidate, extension) else extension
                        if absolute not in seen_offsets:
                            seen_offsets.add(absolute)
                            found.append(CarvedFile(absolute, length, extension))
            position += len(chunk)
            carry = data[-overlap:]
            if progress:
                progress(min(position, total), total)
    return sorted(found, key=lambda item: item.offset)


def _is_docx(candidate: bytes, extension: str) -> bool:
    if extension != "zip":
        return False
    try:
        import io
        with zipfile.ZipFile(io.BytesIO(candidate)) as archive:
            return "word/document.xml" in archive.namelist()
    except (OSError, zipfile.BadZipFile):
        return False


def export_carved(image_path: str, item: CarvedFile, destination: str) -> None:
    """Copy one carved extent to a new file without overwriting existing files."""
    target = Path(destination)
    target.parent.mkdir(parents=True, exist_ok=True)
    with open(image_path, "rb") as source, target.open("xb") as output:
        source.seek(item.offset)
        remaining = item.length
        while remaining:
            block = source.read(min(1024 * 1024, remaining))
            if not block:
                raise OSError("Image ended before the carved extent was fully read.")
            output.write(block)
            remaining -= len(block)
