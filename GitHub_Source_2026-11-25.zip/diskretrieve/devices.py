"""Windows disk diagnostics and destination safety checks."""

import json
import os
import subprocess
from dataclasses import dataclass


@dataclass(frozen=True)
class Disk:
    number: int
    name: str
    size: int
    health: str
    partitions: tuple[str, ...]

    @property
    def device_path(self) -> str:
        return rf"\\.\PhysicalDrive{self.number}"

    def __str__(self) -> str:
        gib = self.size / (1024 ** 3)
        return f"Disk {self.number}: {self.name} ({gib:.1f} GiB) — {self.health}"


_DISK_QUERY = r"""
$ErrorActionPreference = 'Stop'
$result = @(Get-Disk | ForEach-Object {
  $d = $_
  $parts = @(Get-Partition -DiskNumber $d.Number -ErrorAction SilentlyContinue |
    ForEach-Object {
      $p = $_
      $v = $null
      try { $v = Get-Volume -Partition $p -ErrorAction Stop } catch {}
      if ($v) {
        '{0} {1} {2}' -f $p.DriveLetter, $v.FileSystem, $v.Size
      } else {
        'Partition {0} (no mounted volume)' -f $p.PartitionNumber
      }
    })
  [pscustomobject]@{
    Number = [int]$d.Number
    Name = [string]$d.FriendlyName
    Size = [long]$d.Size
    Health = [string]$d.HealthStatus
    Partitions = @($parts)
  }
})
$result | ConvertTo-Json -Depth 4 -Compress
"""

_DESTINATION_QUERY = r"""
param([string]$letter)
$ErrorActionPreference = 'Stop'
$p = Get-Partition -DriveLetter $letter -ErrorAction Stop |
  Select-Object -First 1
if (-not $p) { throw 'No physical disk mapping found for destination volume.' }
[int]$p.DiskNumber
"""


def _powershell(script: str, *args: str) -> str:
    completed = subprocess.run(
        ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script, *args],
        capture_output=True,
        text=True,
        timeout=20,
        check=False,
    )
    if completed.returncode:
        raise RuntimeError(completed.stderr.strip() or "PowerShell disk query failed")
    return completed.stdout.strip()


def list_disks() -> list[Disk]:
    """Return connected disks and basic Windows storage-health information."""
    raw = _powershell(_DISK_QUERY)
    if not raw:
        return []
    records = json.loads(raw)
    if isinstance(records, dict):
        records = [records]
    return [
        Disk(
            number=int(item["Number"]),
            name=item.get("Name") or "Unknown disk",
            size=int(item.get("Size") or 0),
            health=item.get("Health") or "Unknown",
            partitions=tuple(str(p) for p in (item.get("Partitions") or [])),
        )
        for item in records
    ]


def assert_destination_is_separate(image_path: str, source_disk_number: int) -> None:
    """Fail closed unless the image path maps to a different physical disk."""
    path = os.path.abspath(image_path)
    drive, _ = os.path.splitdrive(path)
    if not drive or len(drive) < 2 or drive[1] != ":":
        raise ValueError("Choose a destination on a local drive with a drive letter.")
    letter = drive[0].upper()
    disk_number_text = _powershell(_DESTINATION_QUERY, letter)
    try:
        destination_disk_number = int(disk_number_text)
    except ValueError as exc:
        raise RuntimeError("Could not verify the destination physical disk.") from exc
    if destination_disk_number == source_disk_number:
        raise ValueError("The image destination is on the source physical disk.")
