"""Read-only Windows physical-disk imaging with a resumable JSON mapfile."""

import ctypes
import json
import os
import threading
import time
from ctypes import wintypes
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

if os.name == "nt":
    _kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    _kernel32.CreateFileW.restype = wintypes.HANDLE
    _kernel32.CreateFileW.argtypes = [
        wintypes.LPCWSTR, wintypes.DWORD, wintypes.DWORD, wintypes.LPVOID,
        wintypes.DWORD, wintypes.DWORD, wintypes.HANDLE
    ]
    _kernel32.CreateEventW.restype = wintypes.HANDLE
    _kernel32.CreateEventW.argtypes = [
        wintypes.LPVOID, wintypes.BOOL, wintypes.BOOL, wintypes.LPCWSTR
    ]
    _kernel32.ReadFile.argtypes = [
        wintypes.HANDLE, wintypes.LPVOID, wintypes.DWORD,
        ctypes.POINTER(wintypes.DWORD), wintypes.LPVOID
    ]
    _kernel32.WaitForSingleObject.argtypes = [wintypes.HANDLE, wintypes.DWORD]
    _kernel32.GetOverlappedResult.argtypes = [
        wintypes.HANDLE, wintypes.LPVOID, ctypes.POINTER(wintypes.DWORD), wintypes.BOOL
    ]
    _kernel32.CancelIoEx.argtypes = [wintypes.HANDLE, wintypes.LPVOID]
    _kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
else:  # Keep imports/test helpers usable on non-Windows systems.
    _kernel32 = None

GENERIC_READ = 0x80000000
FILE_SHARE_READ = 0x00000001
FILE_SHARE_WRITE = 0x00000002
OPEN_EXISTING = 3
FILE_FLAG_OVERLAPPED = 0x40000000
ERROR_IO_PENDING = 997
ERROR_HANDLE_EOF = 38
ERROR_DEVICE_NOT_CONNECTED = 1167
ERROR_DEV_NOT_EXIST = 55
ERROR_NOT_READY = 21
WAIT_OBJECT_0 = 0
WAIT_TIMEOUT = 258
INFINITE = 0xFFFFFFFF


class OVERLAPPED(ctypes.Structure):
    _fields_ = [
        ("Internal", ctypes.c_size_t),
        ("InternalHigh", ctypes.c_size_t),
        ("Offset", wintypes.DWORD),
        ("OffsetHigh", wintypes.DWORD),
        ("hEvent", wintypes.HANDLE),
    ]


@dataclass
class Range:
    offset: int
    length: int
    status: str


class RangeMap:
    """Compact interval map; updates split/merge ranges to keep JSON bounded."""

    def __init__(self, total_size: int, ranges: list[dict] | None = None):
        self.total_size = total_size
        self.ranges = (
            [Range(int(r["offset"]), int(r["length"]), str(r["status"])) for r in ranges]
            if ranges
            else ([Range(0, total_size, "untested")] if total_size else [])
        )
        self._validate()

    def range_at(self, offset: int) -> Range:
        for item in self.ranges:
            if item.offset <= offset < item.offset + item.length:
                return item
        raise ValueError("Offset is outside the map.")

    def _validate(self) -> None:
        cursor = 0
        valid = {"finished", "untrimmed", "bad-sector", "untested"}
        for item in self.ranges:
            if item.offset != cursor or item.length <= 0 or item.status not in valid:
                raise ValueError("Mapfile ranges are invalid or incomplete.")
            cursor += item.length
        if cursor != self.total_size:
            raise ValueError("Mapfile size does not match the source disk.")

    def set(self, start: int, length: int, status: str) -> None:
        end = start + length
        if start < 0 or length <= 0 or end > self.total_size:
            raise ValueError("Mapfile update is outside the source disk.")
        changed: list[Range] = []
        for item in self.ranges:
            item_end = item.offset + item.length
            if item_end <= start or item.offset >= end:
                changed.append(item)
                continue
            if item.offset < start:
                changed.append(Range(item.offset, start - item.offset, item.status))
            overlap_start = max(start, item.offset)
            overlap_end = min(end, item_end)
            changed.append(Range(overlap_start, overlap_end - overlap_start, status))
            if item_end > end:
                changed.append(Range(end, item_end - end, item.status))
        merged: list[Range] = []
        for item in changed:
            if merged and merged[-1].status == item.status and \
                    merged[-1].offset + merged[-1].length == item.offset:
                merged[-1].length += item.length
            else:
                merged.append(item)
        self.ranges = merged
        self._validate()

    def status_at(self, offset: int) -> str:
        for item in self.ranges:
            if item.offset <= offset < item.offset + item.length:
                return item.status
        raise ValueError("Offset is outside the map.")

    def to_json(self) -> list[dict]:
        return [vars(item) for item in self.ranges]


class WinRawReader:
    """Asynchronous Win32 reader. The source handle requests GENERIC_READ only."""

    def __init__(self, device_path: str, timeout_seconds: float):
        if os.name != "nt":
            raise OSError("Raw physical-disk imaging is supported only on Windows.")
        self.device_path = device_path
        self.timeout_ms = max(1, int(timeout_seconds * 1000))
        self.handle = None
        self._open()

    def _open(self) -> None:
        create_file = _kernel32.CreateFileW
        handle = create_file(
            self.device_path,
            GENERIC_READ,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            None,
            OPEN_EXISTING,
            FILE_FLAG_OVERLAPPED,
            None,
        )
        if handle == wintypes.HANDLE(-1).value:
            raise ctypes.WinError()
        self.handle = handle

    def close(self) -> None:
        if self.handle is not None:
            _kernel32.CloseHandle(self.handle)
            self.handle = None

    def reconnect(self, cancelled: threading.Event) -> None:
        self.close()
        while not cancelled.is_set():
            try:
                self._open()
                return
            except OSError:
                cancelled.wait(2.0)
        raise InterruptedError("Imaging cancelled while waiting for the source disk.")

    def read_at(self, offset: int, length: int, cancelled: threading.Event) -> bytes:
        if self.handle is None:
            self._open()
        buffer = ctypes.create_string_buffer(length)
        event = _kernel32.CreateEventW(None, True, False, None)
        if not event:
            raise ctypes.WinError()
        overlapped = OVERLAPPED()
        overlapped.Offset = offset & 0xFFFFFFFF
        overlapped.OffsetHigh = (offset >> 32) & 0xFFFFFFFF
        overlapped.hEvent = event
        transferred = wintypes.DWORD(0)
        try:
            ok = _kernel32.ReadFile(
                self.handle, buffer, length, ctypes.byref(transferred),
                ctypes.byref(overlapped)
            )
            if not ok:
                error = ctypes.get_last_error()
                if error != ERROR_IO_PENDING:
                    raise ctypes.WinError(error)
                wait = _kernel32.WaitForSingleObject(event, self.timeout_ms)
                if wait == WAIT_TIMEOUT:
                    _kernel32.CancelIoEx(self.handle, ctypes.byref(overlapped))
                    # Do not reuse the buffer until Windows has completed cancellation.
                    _kernel32.WaitForSingleObject(event, INFINITE)
                    raise TimeoutError(f"Read timed out at byte offset {offset}.")
                if wait != WAIT_OBJECT_0:
                    raise ctypes.WinError()
                if not _kernel32.GetOverlappedResult(
                    self.handle, ctypes.byref(overlapped), ctypes.byref(transferred), False
                ):
                    raise ctypes.WinError()
            return buffer.raw[:transferred.value]
        finally:
            _kernel32.CloseHandle(event)


def _save_map(path: Path, payload: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as stream:
        json.dump(payload, stream, indent=2)
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def image_disk(
    device_path: str,
    disk_number: int,
    source_size: int,
    image_path: str,
    *,
    block_size: int = 1024 * 1024,
    sector_size: int = 512,
    timeout_seconds: float = 10.0,
    cancelled: threading.Event | None = None,
    progress: Callable[[int, int, str], None] | None = None,
    map_path: str | None = None,
) -> None:
    """Image a physical disk; only image and map files are opened for writing."""
    if os.name != "nt":
        raise OSError("Physical disk imaging is supported only on Windows.")
    from .devices import assert_destination_is_separate

    if source_size <= 0 or sector_size <= 0 or block_size < sector_size:
        raise ValueError("Invalid source size or block/sector size.")
    if block_size % sector_size:
        raise ValueError("Block size must be a multiple of the sector size.")
    cancelled = cancelled or threading.Event()
    image = Path(image_path).resolve()
    mapfile = Path(map_path) if map_path else Path(str(image) + ".map.json")
    assert_destination_is_separate(str(image), disk_number)

    if mapfile.exists():
        payload = json.loads(mapfile.read_text(encoding="utf-8"))
        if payload.get("device_path") != device_path or payload.get("source_size") != source_size:
            raise ValueError("Mapfile belongs to a different source or disk size.")
        if not image.exists() or image.stat().st_size != source_size:
            raise ValueError("Existing image is missing or has the wrong size.")
        ranges = RangeMap(source_size, payload.get("ranges", []))
        output = image.open("r+b", buffering=0)
    else:
        if image.exists():
            raise FileExistsError("Image exists without a mapfile; refusing to overwrite it.")
        ranges = RangeMap(source_size)
        output = image.open("x+b", buffering=0)
        output.truncate(source_size)
        payload = {
            "version": 1,
            "device_path": device_path,
            "source_size": source_size,
            "sector_size": sector_size,
            "ranges": ranges.to_json(),
        }

    reader = WinRawReader(device_path, timeout_seconds)
    try:
        offset = 0
        while offset < source_size:
            if cancelled.is_set():
                raise InterruptedError("Imaging cancelled.")
            current_range = ranges.range_at(offset)
            range_remaining = current_range.offset + current_range.length - offset
            if current_range.status in ("finished", "bad-sector"):
                offset += range_remaining
                continue
            length = min(block_size, source_size - offset, range_remaining)
            try:
                data = reader.read_at(offset, length, cancelled)
                if len(data) != length:
                    raise OSError("Short read from source disk.")
                output.seek(offset)
                output.write(data)
                ranges.set(offset, length, "finished")
                offset += length
                payload["ranges"] = ranges.to_json()
                _save_map(mapfile, payload)
                if progress:
                    progress(offset, source_size, "Imaging")
            except (TimeoutError, OSError) as exc:
                if cancelled.is_set():
                    raise InterruptedError("Imaging cancelled.") from exc
                win_error = getattr(exc, "winerror", None)
                if win_error in (ERROR_DEVICE_NOT_CONNECTED, ERROR_DEV_NOT_EXIST, ERROR_NOT_READY):
                    if progress:
                        progress(offset, source_size, "Waiting for source disk to reconnect")
                    reader.reconnect(cancelled)
                    continue
                if length > sector_size:
                    block_size = max(sector_size, (length // 2 // sector_size) * sector_size)
                    continue
                ranges.set(offset, length, "bad-sector")
                offset += length
                payload["ranges"] = ranges.to_json()
                _save_map(mapfile, payload)
                if progress:
                    progress(offset, source_size, f"Bad sector at {offset - length}")
        if progress:
            progress(source_size, source_size, "Imaging complete")
    finally:
        reader.close()
        output.close()
