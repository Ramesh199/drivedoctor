# DiskRetrieve

DiskRetrieve is a Windows-only, safety-first prototype for imaging a physical
disk and carving common files from the resulting image. It uses Python for
orchestration and a PyQt6 desktop UI.

## Safety and scope

- The source is opened only with `GENERIC_READ`; the imager has no source-write,
  format, or repair path.
- The image is created on a different physical disk. The app resolves the
  destination drive letter to a Windows disk number and refuses the operation
  if it cannot prove the destination is separate.
- Imaging uses overlapped Win32 reads with a configurable timeout. Failed
  reads are retried with smaller blocks; unreadable sectors are marked and
  skipped. A disconnected device is reopened by its `PhysicalDriveN` identity.
- The JSON mapfile is updated atomically and supports resuming finished ranges.
- File carving scans an image, never a physical source.

This prototype does **not** implement MFT/partition reconstruction, raw SMART
attribute passthrough, filesystem mounting, or repair. Windows' storage health
status is shown as a basic diagnostic, not a substitute for vendor SMART
tools. Carving is signature-based and may produce incomplete or false-positive
files. For physically failing drives, minimize power cycles and consider a
professional recovery service.

## Requirements and run

- Windows 10/11, Python 3.10+
- Administrator privileges are typically required to read `\\.\PhysicalDriveN`.
- Install dependencies and launch:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -e .
python app.py
```

Select a physical disk, choose an image path on a separate disk, and start
imaging. Do not select the source disk as the image destination. To resume,
select the existing image and its matching `.map.json` file will be used.
After imaging, choose the image in the recovery section and scan it.

## Layout and data flow

```text
app.py                    PyQt6 dashboard and worker-thread progress events
diskretrieve/devices.py   Windows disk/partition diagnostics and safe target check
diskretrieve/imaging.py   GENERIC_READ overlapped raw reads, image writer, mapfile
diskretrieve/carving.py   Streaming signature scanner over image files
tests/                    Hardware-independent tests for ranges and signatures
```

The UI selects a `PhysicalDriveN` and starts a worker. The worker verifies the
image destination, reads source ranges, writes only the image file, and emits
progress. The imager persists range states (`finished`, `bad-sector`,
`untrimmed`, and `untested`) to the adjacent mapfile. The carving worker then
reads the image and reports file offsets; it does not modify the image.

An authenticated local DriveDoctor helper UI is available from the Rust CLI:

```powershell
cd drivedoctor
cargo run -p drivedoctor -- serve --port 8731
```

Open the exact `/?token=...` URL printed by the helper. It is bound to
`127.0.0.1` and requires the session token for API and UI access.

## Recovery caveats

The first version only carves JPEG, PNG, PDF, ZIP/DOCX, and basic MP4 files.
It does not reconstruct directory trees or original filenames. Exported
carved files must be written to a separate destination; the GUI does not expose
the source as an export destination.
