use std::collections::HashMap;
use std::io::{Read, Write};
use std::net::{TcpListener, TcpStream};
use std::path::PathBuf;
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use drivedoctor_core::{samples, ActionId, Symptom};
use drivedoctor_engine::{Engine, ImageProgress, JobControl};
use serde_json::{json, Value};

struct Session {
    token: String,
    arms: HashMap<String, Arm>,
    job: JobSnapshot,
    control: Arc<JobControl>,
}

struct Arm {
    disk: u32,
    action: String,
    ready: Instant,
}

#[derive(Clone)]
struct JobSnapshot {
    running: bool,
    progress: ImageProgress,
    error: Option<String>,
    done: bool,
}

pub fn serve(port: u16) -> Result<(), String> {
    let token = random_token();
    let session = Arc::new(Mutex::new(Session {
        token: token.clone(),
        arms: HashMap::new(),
        control: JobControl::new(),
        job: JobSnapshot {
            running: false,
            progress: ImageProgress { phase: "idle".into(), done: 0, total: 0, bad: 0, message: "Idle".into() },
            error: None,
            done: false,
        },
    }));
    let listener = TcpListener::bind(("127.0.0.1", port)).map_err(|err| format!("bind 127.0.0.1:{port}: {err}"))?;
    write_session(port, &token)?;
    println!("DriveDoctor helper listening on http://127.0.0.1:{port}");
    println!("Token: {token}");
    println!("Open the UI with http://127.0.0.1:{port}/?token={token} after the frontend is built, or paste the token into the Vite app.");
    for stream in listener.incoming() {
        let Ok(stream) = stream else { continue };
        let session = Arc::clone(&session);
        std::thread::spawn(move || {
            let _ = handle(stream, session);
        });
    }
    Ok(())
}

fn handle(mut stream: TcpStream, session: Arc<Mutex<Session>>) -> Result<(), String> {
    let _ = stream.set_read_timeout(Some(Duration::from_secs(30)));
    let mut buf = vec![0u8; 64 * 1024];
    let mut collected = Vec::new();
    loop {
        let n = stream.read(&mut buf).map_err(|err| err.to_string())?;
        if n == 0 {
            break;
        }
        collected.extend_from_slice(&buf[..n]);
        if collected.windows(4).any(|w| w == b"\r\n\r\n") {
            break;
        }
        if collected.len() > 1024 * 1024 {
            return respond(&mut stream, 413, &json!({"error": "request is too large"}));
        }
    }
    let text = String::from_utf8_lossy(&collected);
    let (head, _) = text.split_once("\r\n\r\n").unwrap_or((text.as_ref(), ""));
    let mut lines = head.lines();
    let request = lines.next().unwrap_or("");
    let mut parts = request.split_whitespace();
    let method = parts.next().unwrap_or("");
    let path = parts.next().unwrap_or("/");
    if method == "GET" && (path == "/" || path.starts_with("/?")) {
        let query_token = path.split('?').nth(1).and_then(|query| {
            query.split('&').find_map(|item| item.strip_prefix("token="))
        }).unwrap_or("");
        let token_ok = session.lock().map(|guard| tokens_equal(&guard.token, query_token)).unwrap_or(false);
        if token_ok {
            return respond_html(&mut stream, include_str!("app.html"));
        }
        return respond(&mut stream, 401, &json!({"error": "open the UI using the token URL printed in the helper"}));
    }
    if method == "OPTIONS" {
        return respond(&mut stream, 204, &json!({}));
    }
    let mut header_token = String::new();
    let mut content_length = 0usize;
    for line in lines {
        let lower = line.to_ascii_lowercase();
        if let Some(value) = lower.strip_prefix("x-drivedoctor-token:") {
            header_token = value.trim().to_owned();
        } else if let Some(value) = line.to_ascii_lowercase().strip_prefix("content-length:") {
            content_length = value.trim().parse().unwrap_or(0);
        }
    }
    // Re-read the token with original case from the raw header.
    header_token.clear();
    for line in head.lines() {
        if let Some((name, value)) = line.split_once(':') {
            if name.eq_ignore_ascii_case("x-drivedoctor-token") {
                header_token = value.trim().to_owned();
            }
        }
    }
    let header_end = collected.windows(4).position(|w| w == b"\r\n\r\n").unwrap_or(collected.len()) + 4;
    while collected.len() < header_end + content_length && content_length > 0 && content_length < 1024 * 1024 {
        let n = stream.read(&mut buf).unwrap_or(0);
        if n == 0 {
            break;
        }
        collected.extend_from_slice(&buf[..n]);
    }
    let body = if collected.len() >= header_end {
        &collected[header_end..collected.len().min(header_end + content_length)]
    } else {
        &[]
    };
    let token_ok = {
        let guard = session.lock().map_err(|_| "session lock".to_string())?;
        tokens_equal(&guard.token, &header_token)
    };
    if !token_ok {
        return respond(&mut stream, 401, &json!({"error": "missing or wrong helper token"}));
    }
    let value: Value = if body.is_empty() { json!({}) } else { serde_json::from_slice(body).unwrap_or(json!({})) };
    let (status, payload) = route(method, path, &value, &session);
    respond(&mut stream, status, &payload)
}

fn route(method: &str, path: &str, body: &Value, session: &Arc<Mutex<Session>>) -> (u16, Value) {
    let path = path.split('?').next().unwrap_or(path);
    match (method, path) {
        ("GET", "/v1/health") => (200, json!({"ok": true, "name": "DriveDoctor"})),
        ("GET", "/v1/drives") => match Engine::open().and_then(|engine| engine.list()) {
            Ok(disks) => {
                let items: Vec<Value> = disks.into_iter().map(|disk| {
                    json!({
                        "disk_number": disk.identity.disk_number,
                        "model": disk.identity.model,
                        "serial": disk.identity.serial,
                        "capacity_bytes": disk.identity.capacity_bytes,
                        "bus": disk.identity.bus,
                        "status": disk.operational_status,
                        "health": disk.health_status,
                        "offline": disk.offline,
                        "read_only": disk.read_only,
                        "system": disk.identity.is_system_disk(),
                        "path": disk.identity.device_path,
                        "vid": disk.identity.vid,
                        "pid": disk.identity.pid,
                    })
                }).collect();
                (200, json!({"drives": items}))
            }
            Err(err) => (500, json!({"error": err})),
        },
        ("GET", "/v1/samples") => (200, json!({"samples": samples::sample_ids()})),
        ("POST", "/v1/recovery/scan") => {
            let image = body.get("image").and_then(|v| v.as_str()).unwrap_or("");
            if image.is_empty() {
                return (400, json!({"error": "image path is required"}));
            }
            match std::fs::File::open(image).and_then(|file| {
                let length = file.metadata().map(|meta| meta.len())?;
                drivedoctor_core::carving::scan_image(file, length)
                    .map_err(|err| std::io::Error::new(std::io::ErrorKind::InvalidData, err))
            }) {
                Ok(items) => (200, json!({"items": items})),
                Err(err) => (400, json!({"error": err.to_string()})),
            }
        }
        ("POST", "/v1/recovery/export") => {
            let image = body.get("image").and_then(|v| v.as_str()).unwrap_or("");
            let destination = body.get("destination").and_then(|v| v.as_str()).unwrap_or("");
            let offset = body.get("offset").and_then(|v| v.as_u64());
            let length = body.get("length").and_then(|v| v.as_u64());
            if image.is_empty() || destination.is_empty() || offset.is_none() || length.is_none() {
                return (400, json!({"error": "image, destination, offset, and length are required"}));
            }
            if length.unwrap_or(0) == 0 {
                return (400, json!({"error": "length must be greater than zero"}));
            }
            match export_extent(image, destination, offset.unwrap_or(0), length.unwrap_or(0)) {
                Ok(text) => (200, json!({"result": text})),
                Err(err) => (400, json!({"error": err})),
            }
        }
        ("POST", "/v1/verify") => {
            let disk = body.get("disk_number").and_then(|v| v.as_u64()).unwrap_or(u64::MAX) as u32;
            match Engine::open().and_then(|engine| engine.diagnose(disk, &[])) {
                Ok(report) => (200, serde_json::to_value(json!({
                    "trust": report.current_trust,
                    "repairability": report.repairability,
                    "root_cause": report.root_cause,
                })).unwrap_or(json!({}))),
                Err(err) => (400, json!({"error": err})),
            }
        }
        ("GET", path) if path.starts_with("/v1/samples/") => {
            let id = &path["/v1/samples/".len()..];
            match Engine::sample(id) {
                Ok(report) => (200, serde_json::to_value(report).unwrap_or(json!({}))),
                Err(err) => (404, json!({"error": err})),
            }
        }
        ("POST", "/v1/diagnose") => {
            let disk = body.get("disk_number").and_then(|v| v.as_u64()).unwrap_or(u64::MAX) as u32;
            let symptoms = symptoms_of(body);
            match Engine::open().and_then(|engine| engine.diagnose(disk, &symptoms)) {
                Ok(report) => (200, serde_json::to_value(report).unwrap_or(json!({}))),
                Err(err) => (400, json!({"error": err})),
            }
        }
        ("POST", "/v1/safety/ack") => {
            let disk = body.get("disk_number").and_then(|v| v.as_u64()).unwrap_or(u64::MAX) as u32;
            let serial = body.get("typed_serial").and_then(|v| v.as_str()).unwrap_or("");
            match Engine::open().and_then(|engine| engine.acknowledge_no_data(disk, serial)) {
                Ok(()) => (200, json!({"open": true})),
                Err(err) => (400, json!({"error": err})),
            }
        }
        ("GET", "/v1/safety") => (200, json!({"note": "pass disk_number to POST /v1/diagnose; the gate is stored per serial"})),
        ("POST", "/v1/repair/preview") => {
            let disk = body.get("disk_number").and_then(|v| v.as_u64()).unwrap_or(u64::MAX) as u32;
            let action = match action_of(body) {
                Ok(action) => action,
                Err(err) => return (400, json!({"error": err})),
            };
            match Engine::open().and_then(|engine| engine.preview(disk, action)) {
                Ok(text) => (200, json!({"preview": text})),
                Err(err) => (400, json!({"error": err})),
            }
        }
        ("POST", "/v1/repair/arm") => {
            let disk = body.get("disk_number").and_then(|v| v.as_u64()).unwrap_or(u64::MAX) as u32;
            let action = body.get("action").and_then(|v| v.as_str()).unwrap_or("").to_owned();
            if action.is_empty() {
                return (400, json!({"error": "action is required"}));
            }
            let token = random_token();
            if let Ok(mut guard) = session.lock() {
                guard.arms.insert(token.clone(), Arm { disk, action, ready: Instant::now() + Duration::from_secs(10) });
            }
            (200, json!({"token": token, "wait_seconds": 10}))
        }
        ("POST", "/v1/repair/commit") => commit(body, session),
        ("POST", "/v1/image") => start_image(body, session),
        ("GET", "/v1/jobs") => {
            let guard = session.lock().ok();
            match guard {
                Some(guard) => (200, json!({
                    "running": guard.job.running,
                    "done": guard.job.done,
                    "error": guard.job.error,
                    "phase": guard.job.progress.phase,
                    "copied": guard.job.progress.done,
                    "total": guard.job.progress.total,
                    "bad": guard.job.progress.bad,
                    "message": guard.job.progress.message,
                })),
                None => (500, json!({"error": "job lock"})),
            }
        }
        ("POST", "/v1/jobs/pause") => flag(session, true, false),
        ("POST", "/v1/jobs/resume") => flag(session, false, false),
        ("POST", "/v1/jobs/cancel") => flag(session, false, true),
        ("POST", "/v1/ata") => {
            let disk = body.get("disk_number").and_then(|v| v.as_u64()).unwrap_or(u64::MAX) as u32;
            let command = body.get("command").and_then(|v| v.as_str()).unwrap_or("");
            match drivedoctor_engine::ata(disk, command) {
                Ok(text) => (200, json!({"output": text})),
                Err(err) => (400, json!({"error": err})),
            }
        }
        _ => (404, json!({"error": "unknown route"})),
    }
}

fn commit(body: &Value, session: &Arc<Mutex<Session>>) -> (u16, Value) {
    let disk = body.get("disk_number").and_then(|v| v.as_u64()).unwrap_or(u64::MAX) as u32;
    let phrase = body.get("phrase").and_then(|v| v.as_str()).unwrap_or("").to_owned();
    let token = body.get("token").and_then(|v| v.as_str()).unwrap_or("").to_owned();
    let action = match action_of(body) {
        Ok(action) => action,
        Err(err) => return (400, json!({"error": err})),
    };
    let ready = {
        let Ok(mut guard) = session.lock() else {
            return (500, json!({"error": "session lock"}));
        };
        match guard.arms.get(&token) {
            Some(arm) if arm.disk == disk && arm.action == action.as_str() => arm.ready,
            _ => return (400, json!({"error": "arm token is missing or does not match this action"})),
        }
    };
    if Instant::now() < ready {
        return (400, json!({"error": "the 10 second countdown has not finished"}));
    }
    if let Ok(mut guard) = session.lock() {
        guard.arms.remove(&token);
    }
    match Engine::open().and_then(|engine| engine.commit(disk, action, &phrase)) {
        Ok(text) => (200, json!({"result": text})),
        Err(err) => (400, json!({"error": err})),
    }
}

fn start_image(body: &Value, session: &Arc<Mutex<Session>>) -> (u16, Value) {
    let disk = body.get("disk_number").and_then(|v| v.as_u64()).unwrap_or(u64::MAX) as u32;
    let output = body.get("destination").and_then(|v| v.as_str()).unwrap_or("").to_owned();
    if output.is_empty() {
        return (400, json!({"error": "destination path is required"}));
    }
    {
        let Ok(guard) = session.lock() else {
            return (500, json!({"error": "session lock"}));
        };
        if guard.job.running {
            return (409, json!({"error": "an image is already running"}));
        }
    }
    let control = {
        let Ok(mut guard) = session.lock() else {
            return (500, json!({"error": "session lock"}));
        };
        guard.control = JobControl::new();
        guard.job.running = true;
        guard.job.done = false;
        guard.job.error = None;
        Arc::clone(&guard.control)
    };
    let session_thread = Arc::clone(session);
    let destination = PathBuf::from(output);
    std::thread::spawn(move || {
        let result = Engine::open().and_then(|engine| {
            engine.image(disk, &destination, &control, |progress| {
                if let Ok(mut guard) = session_thread.lock() {
                    guard.job.progress = progress;
                }
            })
        });
        if let Ok(mut guard) = session_thread.lock() {
            guard.job.running = false;
            guard.job.done = result.is_ok();
            guard.job.error = result.err();
            if guard.job.error.is_none() {
                guard.job.progress.message = "Imaging complete".into();
            }
        }
    });
    (200, json!({"started": true}))
}

fn flag(session: &Arc<Mutex<Session>>, pause: bool, cancel: bool) -> (u16, Value) {
    if let Ok(guard) = session.lock() {
        if pause {
            guard.control.pause.store(true, std::sync::atomic::Ordering::Relaxed);
        } else if !cancel {
            guard.control.pause.store(false, std::sync::atomic::Ordering::Relaxed);
        }
        if cancel {
            guard.control.cancel.store(true, std::sync::atomic::Ordering::Relaxed);
        }
    }
    (200, json!({"ok": true}))
}

fn symptoms_of(body: &Value) -> Vec<Symptom> {
    body.get("symptoms")
        .and_then(|v| v.as_array())
        .map(|items| {
            items.iter().filter_map(|item| item.as_str()).filter_map(|name| {
                serde_json::from_value(Value::String(name.to_owned())).ok()
            }).collect()
        })
        .unwrap_or_default()
}

fn action_of(body: &Value) -> Result<ActionId, String> {
    let name = body.get("action").and_then(|v| v.as_str()).unwrap_or("");
    serde_json::from_value(Value::String(name.to_owned())).map_err(|_| format!("unknown action '{name}'"))
}

fn export_extent(image: &str, destination: &str, offset: u64, length: u64) -> Result<String, String> {
    use std::fs::OpenOptions;
    use std::io::{Seek, SeekFrom};
    let mut source = std::fs::File::open(image).map_err(|err| err.to_string())?;
    let image_len = source.metadata().map_err(|err| err.to_string())?.len();
    let end = match offset.checked_add(length) {
        Some(end) => end,
        None => return Err("carved extent offset overflow".into()),
    };
    if end > image_len {
        return Err("carved extent is outside the image".into());
    }
    let mut target = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(destination)
        .map_err(|err| err.to_string())?;
    source.seek(SeekFrom::Start(offset)).map_err(|err| err.to_string())?;
    let mut remaining = length;
    let mut buffer = vec![0u8; 1024 * 1024];
    while remaining > 0 {
        let read_len = (remaining as usize).min(buffer.len());
        let read = source.read(&mut buffer[..read_len]).map_err(|err| err.to_string())?;
        if read == 0 {
            return Err("image ended before the carved extent was fully read".into());
        }
        target.write_all(&buffer[..read]).map_err(|err| err.to_string())?;
        remaining -= read as u64;
    }
    target.flush().map_err(|err| err.to_string())?;
    Ok(format!("Exported {} bytes to {}", length, destination))
}

fn respond(stream: &mut TcpStream, status: u16, body: &Value) -> Result<(), String> {
    let payload = serde_json::to_vec(body).map_err(|err| err.to_string())?;
    let reason = match status {
        200 => "OK",
        204 => "No Content",
        400 => "Bad Request",
        401 => "Unauthorized",
        404 => "Not Found",
        409 => "Conflict",
        413 => "Payload Too Large",
        _ => "Error",
    };
    let header = format!(
        "HTTP/1.1 {status} {reason}\r\nContent-Type: application/json\r\nContent-Length: {}\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Headers: Content-Type, X-DriveDoctor-Token\r\nAccess-Control-Allow-Methods: GET, POST, OPTIONS\r\nConnection: close\r\n\r\n",
        payload.len()
    );
    stream.write_all(header.as_bytes()).map_err(|err| err.to_string())?;
    if status != 204 {
        stream.write_all(&payload).map_err(|err| err.to_string())?;
    }
    Ok(())
}

fn respond_html(stream: &mut TcpStream, body: &str) -> Result<(), String> {
    let bytes = body.as_bytes();
    let header = format!(
        "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: {}\r\nCache-Control: no-store\r\nX-Content-Type-Options: nosniff\r\nConnection: close\r\n\r\n",
        bytes.len()
    );
    stream.write_all(header.as_bytes()).map_err(|err| err.to_string())?;
    stream.write_all(bytes).map_err(|err| err.to_string())
}

fn tokens_equal(expected: &str, given: &str) -> bool {
    let a = expected.as_bytes();
    let b = given.as_bytes();
    if a.len() != b.len() || a.is_empty() {
        return false;
    }
    let mut diff = 0u8;
    for index in 0..a.len() {
        diff |= a[index] ^ b[index];
    }
    diff == 0
}

fn random_token() -> String {
    let mut bytes = [0u8; 32];
    let ok = unsafe { SystemFunction036(bytes.as_mut_ptr(), bytes.len() as u32) };
    if ok == 0 {
        let ticks = SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_nanos()).unwrap_or(0);
        bytes = ticks.to_le_bytes().repeat(2).try_into().unwrap_or([0; 32]);
    }
    drivedoctor_core::journal::hex_encode(&bytes)
}

fn write_session(port: u16, token: &str) -> Result<(), String> {
    let root = drivedoctor_case_root()?;
    std::fs::create_dir_all(&root).map_err(|err| err.to_string())?;
    let body = json!({"port": port, "token": token});
    std::fs::write(root.join("session.json"), serde_json::to_vec_pretty(&body).map_err(|e| e.to_string())?).map_err(|err| err.to_string())
}

fn drivedoctor_case_root() -> Result<PathBuf, String> {
    let base = std::env::var_os("LOCALAPPDATA").map(PathBuf::from).ok_or("LOCALAPPDATA is not set")?;
    Ok(base.join("DriveDoctor"))
}

#[link(name = "advapi32")]
extern "system" {
    fn SystemFunction036(buffer: *mut u8, length: u32) -> u8;
}
