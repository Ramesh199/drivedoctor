mod serve;

use std::path::PathBuf;

use clap::{Parser, Subcommand};
use drivedoctor_core::Symptom;
use drivedoctor_engine::Engine;

#[derive(Parser)]
#[command(name = "drivedoctor", about = "Diagnose a failed external drive before anything is written.")]
struct Cli {
    #[command(subcommand)]
    command: Command,
}

#[derive(Subcommand)]
enum Command {
    /// List disks Windows can see.
    List,
    /// Read-only layered diagnosis.
    Diagnose {
        #[arg(long)]
        disk: u32,
        /// Repeat for each symptom, for example --symptom clicking.
        #[arg(long)]
        symptom: Vec<String>,
    },
    /// Run a built-in sample case. Nothing on a real disk is touched.
    Sample { id: String },
    /// Copy a disk to an image on a different physical disk.
    Image {
        #[arg(long)]
        disk: u32,
        #[arg(long)]
        output: PathBuf,
    },
    /// Open the safety gate by typing the drive serial. This does not erase anything.
    Ack {
        #[arg(long)]
        disk: u32,
        #[arg(long)]
        serial: String,
    },
    /// Local helper for the desktop UI. Binds to 127.0.0.1 only.
    Serve {
        #[arg(long, default_value_t = 8731)]
        port: u16,
    },
}

fn main() {
    if let Err(err) = run() {
        eprintln!("DriveDoctor: {err}");
        std::process::exit(1);
    }
}

fn run() -> Result<(), String> {
    match Cli::parse().command {
        Command::List => {
            let engine = Engine::open()?;
            for disk in engine.list()? {
                let gib = disk.identity.capacity_bytes as f64 / 1024.0 / 1024.0 / 1024.0;
                println!(
                    "Disk {}: {} ({gib:.1} GiB) {} {} {}",
                    disk.identity.disk_number,
                    disk.identity.model,
                    disk.identity.bus,
                    disk.operational_status,
                    disk.identity.device_path
                );
            }
        }
        Command::Diagnose { disk, symptom } => {
            let engine = Engine::open()?;
            let symptoms = parse_symptoms(&symptom)?;
            let report = engine.diagnose(disk, &symptoms)?;
            println!("{}", serde_json::to_string_pretty(&report).map_err(|err| err.to_string())?);
        }
        Command::Sample { id } => {
            let report = Engine::sample(&id)?;
            println!("{}", serde_json::to_string_pretty(&report).map_err(|err| err.to_string())?);
        }
        Command::Image { disk, output } => {
            let engine = Engine::open()?;
            let control = drivedoctor_engine::JobControl::new();
            engine.image(disk, &output, &control, |progress| {
                println!("{} {} / {} {}", progress.phase, progress.done, progress.total, progress.message);
            })?;
        }
        Command::Ack { disk, serial } => {
            let engine = Engine::open()?;
            engine.acknowledge_no_data(disk, &serial)?;
            println!("Safety gate open for disk {disk}. Repairs that write still require the serial again.");
        }
        Command::Serve { port } => serve::serve(port)?,
    }
    Ok(())
}

fn parse_symptoms(names: &[String]) -> Result<Vec<Symptom>, String> {
    let mut out = Vec::new();
    for name in names {
        let parsed: Symptom = serde_json::from_value(serde_json::Value::String(name.to_lowercase()))
            .map_err(|_| format!("unknown symptom '{name}'"))?;
        out.push(parsed);
    }
    Ok(out)
}
