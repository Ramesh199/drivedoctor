use std::path::{Path, PathBuf};

use drivedoctor_core::{DriveIdentity, RiskLevel};
use rusqlite::{params, Connection};

pub struct CaseStore {
    conn: Connection,
    root: PathBuf,
}

#[derive(Clone, Debug)]
pub struct ActionRecord {
    pub created_at: String,
    pub action: String,
    pub risk: String,
    pub result: String,
    pub detail: String,
}

#[derive(Clone, Debug)]
pub struct SafetyRecord {
    pub image_path: Option<String>,
    pub image_complete: bool,
    pub no_data_serial: Option<String>,
}

#[derive(Clone, Debug)]
pub struct SmartSample {
    pub created_at: String,
    pub json: String,
}

impl CaseStore {
    pub fn open_default() -> Result<Self, String> {
        let root = default_root()?;
        std::fs::create_dir_all(&root).map_err(|err| err.to_string())?;
        Self::open(root.join("cases.sqlite"), root)
    }

    pub fn open(db_path: impl AsRef<Path>, root: PathBuf) -> Result<Self, String> {
        if let Some(parent) = db_path.as_ref().parent() {
            std::fs::create_dir_all(parent).map_err(|err| err.to_string())?;
        }
        let conn = Connection::open(db_path).map_err(|err| err.to_string())?;
        conn.execute_batch(
            "
            PRAGMA journal_mode = WAL;
            CREATE TABLE IF NOT EXISTS drives (
                serial TEXT PRIMARY KEY,
                model TEXT NOT NULL,
                capacity_bytes INTEGER NOT NULL,
                device_path TEXT NOT NULL,
                first_seen TEXT NOT NULL,
                last_seen TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS actions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                serial TEXT NOT NULL,
                created_at TEXT NOT NULL,
                action TEXT NOT NULL,
                risk TEXT NOT NULL,
                result TEXT NOT NULL,
                detail TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS smart_samples (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                serial TEXT NOT NULL,
                created_at TEXT NOT NULL,
                json TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS safety (
                serial TEXT PRIMARY KEY,
                image_path TEXT,
                image_complete INTEGER NOT NULL DEFAULT 0,
                no_data_serial TEXT
            );
            ",
        )
        .map_err(|err| err.to_string())?;
        Ok(Self { conn, root })
    }

    pub fn root(&self) -> &Path {
        &self.root
    }

    pub fn case_dir(&self, serial: &str) -> PathBuf {
        let safe: String = serial.chars().filter(|c| c.is_ascii_alphanumeric() || *c == '-' || *c == '_').collect();
        self.root.join(if safe.is_empty() { "unknown-serial" } else { &safe })
    }

    pub fn record_drive(&self, identity: &DriveIdentity) -> Result<(), String> {
        let now = timestamp();
        self.conn
            .execute(
                "INSERT INTO drives (serial, model, capacity_bytes, device_path, first_seen, last_seen)
                 VALUES (?1, ?2, ?3, ?4, ?5, ?5)
                 ON CONFLICT(serial) DO UPDATE SET
                    model = excluded.model,
                    capacity_bytes = excluded.capacity_bytes,
                    device_path = excluded.device_path,
                    last_seen = excluded.last_seen",
                params![identity.serial, identity.model, identity.capacity_bytes as i64, identity.device_path, now],
            )
            .map_err(|err| err.to_string())?;
        Ok(())
    }

    pub fn record_action(&self, serial: &str, action: &str, risk: RiskLevel, result: &str, detail: &str) -> Result<(), String> {
        self.conn
            .execute(
                "INSERT INTO actions (serial, created_at, action, risk, result, detail) VALUES (?1, ?2, ?3, ?4, ?5, ?6)",
                params![serial, timestamp(), action, risk.label(), result, detail],
            )
            .map_err(|err| err.to_string())?;
        Ok(())
    }

    pub fn actions(&self, serial: &str) -> Result<Vec<ActionRecord>, String> {
        let mut stmt = self
            .conn
            .prepare("SELECT created_at, action, risk, result, detail FROM actions WHERE serial = ?1 ORDER BY id")
            .map_err(|err| err.to_string())?;
        let rows = stmt
            .query_map(params![serial], |row| {
                Ok(ActionRecord {
                    created_at: row.get(0)?,
                    action: row.get(1)?,
                    risk: row.get(2)?,
                    result: row.get(3)?,
                    detail: row.get(4)?,
                })
            })
            .map_err(|err| err.to_string())?;
        rows.collect::<Result<Vec<_>, _>>().map_err(|err| err.to_string())
    }

    pub fn record_smart(&self, serial: &str, json: &str) -> Result<(), String> {
        self.conn
            .execute(
                "INSERT INTO smart_samples (serial, created_at, json) VALUES (?1, ?2, ?3)",
                params![serial, timestamp(), json],
            )
            .map_err(|err| err.to_string())?;
        Ok(())
    }

    pub fn latest_smart(&self, serial: &str) -> Result<Option<SmartSample>, String> {
        let mut stmt = self
            .conn
            .prepare("SELECT created_at, json FROM smart_samples WHERE serial = ?1 ORDER BY id DESC LIMIT 1")
            .map_err(|err| err.to_string())?;
        let mut rows = stmt.query(params![serial]).map_err(|err| err.to_string())?;
        if let Some(row) = rows.next().map_err(|err| err.to_string())? {
            Ok(Some(SmartSample { created_at: row.get(0).map_err(|e| e.to_string())?, json: row.get(1).map_err(|e| e.to_string())? }))
        } else {
            Ok(None)
        }
    }

    pub fn safety(&self, serial: &str) -> Result<SafetyRecord, String> {
        let mut stmt = self
            .conn
            .prepare("SELECT image_path, image_complete, no_data_serial FROM safety WHERE serial = ?1")
            .map_err(|err| err.to_string())?;
        let mut rows = stmt.query(params![serial]).map_err(|err| err.to_string())?;
        if let Some(row) = rows.next().map_err(|err| err.to_string())? {
            Ok(SafetyRecord {
                image_path: row.get(0).map_err(|e| e.to_string())?,
                image_complete: row.get::<_, i64>(1).map_err(|e| e.to_string())? != 0,
                no_data_serial: row.get(2).map_err(|e| e.to_string())?,
            })
        } else {
            Ok(SafetyRecord { image_path: None, image_complete: false, no_data_serial: None })
        }
    }

    pub fn set_image_complete(&self, serial: &str, path: &str) -> Result<(), String> {
        self.conn
            .execute(
                "INSERT INTO safety (serial, image_path, image_complete, no_data_serial) VALUES (?1, ?2, 1, NULL)
                 ON CONFLICT(serial) DO UPDATE SET image_path = excluded.image_path, image_complete = 1",
                params![serial, path],
            )
            .map_err(|err| err.to_string())?;
        Ok(())
    }

    pub fn set_no_data_ack(&self, serial: &str, typed: &str) -> Result<(), String> {
        self.conn
            .execute(
                "INSERT INTO safety (serial, image_path, image_complete, no_data_serial) VALUES (?1, NULL, 0, ?2)
                 ON CONFLICT(serial) DO UPDATE SET no_data_serial = excluded.no_data_serial",
                params![serial, typed],
            )
            .map_err(|err| err.to_string())?;
        Ok(())
    }
}

pub fn default_root() -> Result<PathBuf, String> {
    let base = std::env::var_os("LOCALAPPDATA")
        .map(PathBuf::from)
        .or_else(|| std::env::var_os("HOME").map(PathBuf::from))
        .ok_or("neither LOCALAPPDATA nor HOME is set")?;
    Ok(base.join("DriveDoctor"))
}

fn timestamp() -> String {
    use std::time::{SystemTime, UNIX_EPOCH};
    let secs = SystemTime::now().duration_since(UNIX_EPOCH).map(|d| d.as_secs()).unwrap_or(0);
    format!("{secs}")
}
