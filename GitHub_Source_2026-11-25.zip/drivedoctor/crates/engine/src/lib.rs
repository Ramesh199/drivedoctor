//! Session engine. The UI and CLI both call this. Sector writes require a [`WritePermit`].

use std::fs::OpenOptions;
use std::io::{Seek, SeekFrom, Write};
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::Instant;

use drivedoctor_case::CaseStore;
use drivedoctor_core::filesystem::ntfs_boot_restore;
use drivedoctor_core::journal::JournalFile;
use drivedoctor_core::{
    action_on_plan,     authorize, gpt_repair_writes, handoff_report, normalize_serial, protective_mbr, required_phrase,
    samples, ActionId, DiagnosisReport, IdentityLock, MapFile, Phase, PlannedAction, Planner,
    ProbeInput, RegionStatus, RiskLevel, SafetyGate, Symptom, WritePermit,
};
use drivedoctor_platform_windows::{
    destination_disk_number, free_bytes, keep_awake, list_disks, probe_disk, replace_file, run_allowed_ata,
    DiskReader, DiskWriter, EnumeratedDisk,
};

pub struct Engine {
    pub cases: CaseStore,
}

#[derive(Clone, Debug, serde::Serialize)]
pub struct ImageProgress {
    pub phase: String,
    pub done: u64,
    pub total: u64,
    pub bad: u64,
    pub message: String,
}

pub struct JobControl {
    pub pause: AtomicBool,
    pub cancel: AtomicBool,
}

impl JobControl {
    pub fn new() -> Arc<Self> {
        Arc::new(Self { pause: AtomicBool::new(false), cancel: AtomicBool::new(false) })
    }
}

impl Default for JobControl {
    fn default() -> Self {
        Self { pause: AtomicBool::new(false), cancel: AtomicBool::new(false) }
    }
}

impl Engine {
    pub fn open() -> Result<Self, String> {
        Ok(Self { cases: CaseStore::open_default()? })
    }

    pub fn list(&self) -> Result<Vec<EnumeratedDisk>, String> {
        list_disks()
    }

    pub fn disk(&self, number: u32) -> Result<EnumeratedDisk, String> {
        self.list()?.into_iter().find(|disk| disk.identity.disk_number == number).ok_or_else(|| format!("disk {number} is not connected"))
    }

    pub fn diagnose(&self, number: u32, symptoms: &[Symptom]) -> Result<DiagnosisReport, String> {
        let disk = self.disk(number)?;
        let probe = probe_disk(&disk, symptoms);
        let report = drivedoctor_core::diagnose(&probe);
        if disk.identity.has_serial() {
            self.cases.record_drive(&disk.identity)?;
            self.cases.record_action(&disk.identity.serial, "diagnose", RiskLevel::Safe, "ok", &report.root_cause)?;
            if let Some(smart) = &probe.smart {
                if let Ok(json) = serde_json::to_string(smart) {
                    let _ = self.cases.record_smart(&disk.identity.serial, &json);
                }
            }
            let _ = self.save_report(&disk.identity.serial, &report);
        }
        Ok(report)
    }

    pub fn sample(id: &str) -> Result<DiagnosisReport, String> {
        samples::sample(id).ok_or_else(|| format!("unknown sample '{id}'"))
    }

    pub fn gate_for(&self, disk: &EnumeratedDisk) -> Result<SafetyGate, String> {
        if !disk.identity.has_serial() {
            return Ok(SafetyGate::locked());
        }
        let record = self.cases.safety(&disk.identity.serial)?;
        Ok(SafetyGate {
            image_complete: record.image_complete,
            image_path: record.image_path,
            no_data_serial: record.no_data_serial,
        })
    }

    pub fn acknowledge_no_data(&self, number: u32, typed: &str) -> Result<(), String> {
        let disk = self.disk(number)?;
        if !disk.identity.has_serial() {
            return Err("this drive has no readable serial, so the only way to open the gate is a completed image".into());
        }
        if normalize_serial(typed) != normalize_serial(&disk.identity.serial) {
            return Err("that does not match the drive serial".into());
        }
        self.cases.set_no_data_ack(&disk.identity.serial, &normalize_serial(typed))?;
        self.cases.record_action(&disk.identity.serial, "no_data_ack", RiskLevel::Safe, "ok", "user confirmed there is no data to keep")?;
        Ok(())
    }

    pub fn image(
        &self,
        number: u32,
        destination: &Path,
        control: &JobControl,
        progress: impl Fn(ImageProgress),
    ) -> Result<(), String> {
        let _awake = keep_awake();
        let disk = self.disk(number)?;
        let lock = disk.identity.lock()?;
        assert_destination(&disk, destination)?;
        let map_path = PathBuf::from(format!("{}.map.json", destination.display()));
        let sector = disk.identity.logical_sector_size as u64;
        let mut map = load_or_create_map(&disk, destination, &map_path, sector)?;
        if map.serial != lock.serial || map.capacity_bytes != lock.capacity_bytes {
            return Err("this map file belongs to a different drive".into());
        }
        let mut reader = DiskReader::open(&disk.identity.device_path)?;
        reader.timeout_ms = 10_000;
        let mut output = OpenOptions::new().read(true).write(true).open(destination).map_err(|err| err.to_string())?;
        let mut planner = Planner::start(&map, 1024 * 1024)?;
        let mut since_check = 0u64;
        loop {
            if control.cancel.load(Ordering::Relaxed) {
                save_map(&map_path, &map)?;
                return Err("imaging cancelled; the map file can resume".into());
            }
            while control.pause.load(Ordering::Relaxed) {
                if control.cancel.load(Ordering::Relaxed) {
                    save_map(&map_path, &map)?;
                    return Err("imaging cancelled; the map file can resume".into());
                }
                std::thread::sleep(std::time::Duration::from_millis(200));
            }
            let Some(request) = planner.next(&mut map) else {
                if planner.advance(&mut map) {
                    continue;
                }
                break;
            };
            let started = Instant::now();
            match reader.read_at(request.offset, request.length as usize) {
                Ok(data) => {
                    output.seek(SeekFrom::Start(request.offset)).map_err(|err| err.to_string())?;
                    output.write_all(&data).map_err(|err| err.to_string())?;
                    planner.observe_ok(&mut map, request)?;
                    since_check += request.length;
                }
                Err(err) if err.contains("1167") || err.contains("not connected") || err.contains("error 21") || err.contains("error 55") => {
                    progress(ImageProgress {
                        phase: phase_name(request.phase),
                        done: map.bytes_with(RegionStatus::Finished),
                        total: map.capacity_bytes,
                        bad: map.bytes_with(RegionStatus::Bad),
                        message: "Waiting for the drive to reconnect".into(),
                    });
                    if !reconnect(&mut reader, control, &lock)? {
                        save_map(&map_path, &map)?;
                        return Err("imaging cancelled while the drive was disconnected".into());
                    }
                }
                Err(_) => {
                    planner.observe_fail(&mut map, request)?;
                }
            }
            if since_check >= 1024 * 1024 * 1024 {
                confirm_still(&lock)?;
                since_check = 0;
            }
            save_map(&map_path, &map)?;
            let summary = map.summary();
            progress(ImageProgress {
                phase: phase_name(planner.phase),
                done: summary.finished,
                total: map.capacity_bytes,
                bad: summary.bad,
                message: "Imaging".into(),
            });
            let _ = started;
        }
        output.flush().map_err(|err| err.to_string())?;
        map.retry_done = true;
        save_map(&map_path, &map)?;
        if map.rescue_finished() {
            self.cases.set_image_complete(&disk.identity.serial, &destination.display().to_string())?;
            self.cases.record_action(&disk.identity.serial, "image", RiskLevel::Safe, "complete", &destination.display().to_string())?;
        }
        Ok(())
    }

    pub fn preview(&self, number: u32, action: ActionId) -> Result<String, String> {
        let disk = self.disk(number)?;
        let report = self.diagnose(number, &[])?;
        let planned = action_on_plan(&report.plan, action).map_err(|err| err.to_string())?;
        if planned.risk == RiskLevel::DestroysAll {
            return Ok(format!(
                "{} {} Type {} after the countdown to arm this. It is not recommended while a lighter fix is on the plan.",
                planned.summary,
                planned.data_effect,
                required_phrase(planned, &disk.identity)
            ));
        }
        match action {
            ActionId::RestoreGpt => {
                let probe = probe_disk(&disk, &[]);
                let writes = gpt_repair_writes(
                    probe.disk_sectors,
                    probe.sector_size,
                    probe.gpt_header.as_deref(),
                    probe.gpt_entries.as_deref(),
                    probe.gpt_backup_header.as_deref(),
                    probe.gpt_backup_entries.as_deref(),
                )?;
                Ok(describe_writes(&writes))
            }
            ActionId::RestoreNtfsBoot => Ok(preview_ntfs(&probe_disk(&disk, &[]))?),
            ActionId::FixProtectiveMbr => Ok("Sector 0 would be rewritten with a single protective (0xEE) MBR entry. Partition contents are not changed.".into()),
            other => Ok(format!("{} {}", action_title(other, &report.plan), planned.summary)),
        }
    }

    pub fn commit(&self, number: u32, action: ActionId, phrase: &str) -> Result<String, String> {
        let disk = self.disk(number)?;
        let report = drivedoctor_core::diagnose(&probe_disk(&disk, &[]));
        let planned = action_on_plan(&report.plan, action).map_err(|err| err.to_string())?.clone();
        let gate = self.gate_for(&disk)?;
        let lighter = report.plan.iter().any(|item| item.recommended && item.level < planned.level);
        let hardware = report.hardware_fault.is_some() || report.repairability == drivedoctor_core::Repairability::HardwareFault;
        let permit = if planned.risk.writes_disk() {
            Some(authorize(&planned, &disk.identity, &gate, phrase, hardware, lighter).map_err(|err| err.to_string())?)
        } else {
            None
        };
        let result = self.execute(&disk, &report, &planned, permit.as_ref())?;
        if disk.identity.has_serial() {
            self.cases.record_action(&disk.identity.serial, planned.id.as_str(), planned.risk, "done", &result)?;
        }
        Ok(result)
    }

    fn execute(&self, disk: &EnumeratedDisk, report: &DiagnosisReport, planned: &PlannedAction, permit: Option<&WritePermit>) -> Result<String, String> {
        match planned.id {
            ActionId::BringOnline => powershell_disk(disk.identity.disk_number, "Set-Disk -Number {n} -IsOffline $false"),
            ActionId::ClearReadOnly => powershell_disk(disk.identity.disk_number, "Set-Disk -Number {n} -IsReadOnly $false"),
            ActionId::ClearRegistryWriteProtect => powershell_disk(
                disk.identity.disk_number,
                "Remove-ItemProperty -Path 'HKLM:\\SYSTEM\\CurrentControlSet\\Control\\StorageDevicePolicies' -Name WriteProtect -ErrorAction SilentlyContinue",
            ),
            ActionId::AssignDriveLetter => assign_letter(disk.identity.disk_number),
            ActionId::RescanDevices => powershell_disk(disk.identity.disk_number, "pnputil.exe /scan-devices | Out-Null"),
            ActionId::DisableSelectiveSuspend | ActionId::ShowGuidance | ActionId::VendorFirmwareGuide | ActionId::PowerDown => {
                Ok(planned.summary.clone())
            }
            ActionId::ProfessionalHandoff => {
                let text = handoff_report(report, None, &[]);
                if disk.identity.has_serial() {
                    let dir = self.cases.case_dir(&disk.identity.serial);
                    std::fs::create_dir_all(&dir).map_err(|err| err.to_string())?;
                    let path = dir.join("handoff.md");
                    std::fs::write(&path, &text).map_err(|err| err.to_string())?;
                    Ok(format!("Wrote {}", path.display()))
                } else {
                    Ok(text)
                }
            }
            ActionId::RestoreGpt => {
                let permit = permit.ok_or("missing write permit")?;
                restore_gpt(disk, permit, &self.cases)
            }
            ActionId::FixProtectiveMbr => {
                let permit = permit.ok_or("missing write permit")?;
                let sector = disk.identity.logical_sector_size;
                let bytes = protective_mbr(disk.identity.capacity_bytes / sector as u64, sector as usize);
                write_lbas(disk, permit, &[(0, bytes)], "protective MBR", &self.cases)
            }
            ActionId::RestoreNtfsBoot => {
                let permit = permit.ok_or("missing write permit")?;
                restore_ntfs(disk, permit, &self.cases)
            }
            ActionId::ChkdskDryRun => chkdsk(disk, false),
            ActionId::ChkdskFix => {
                let _permit = permit.ok_or("missing write permit")?;
                chkdsk(disk, true)
            }
            ActionId::SecureErase => Ok(
                "Secure erase was not sent. Most USB bridges drop ATA SECURITY ERASE and NVMe Sanitize, and a mistyped SAT command can lock the drive with a password. Connect the drive to SATA or NVMe directly and use the vendor or hdparm/smartctl instructions after the image is stored.".into(),
            ),
            ActionId::RemoveHpa => Ok(
                "SET MAX ADDRESS was not sent. Removing a Host Protected Area from the wrong disk can make it unbootable. The diagnosis only records that the native size looks larger than the size Windows sees.".into(),
            ),
            ActionId::ZeroFill | ActionId::CreatePartitionAndFormat | ActionId::RemapPendingSectors | ActionId::MarkBadClusters => {
                Err(format!(
                    "{} is armed by the safety gate but this build records the request and stops. Run the preview, keep the image, and treat a full-surface write as a separate confirmed operation once you have reviewed the sector list.",
                    planned.title
                ))
            }
            other => Ok(format!("{}: {}", other.as_str(), planned.summary)),
        }
    }

    fn save_report(&self, serial: &str, report: &DiagnosisReport) -> Result<(), String> {
        let dir = self.cases.case_dir(serial);
        std::fs::create_dir_all(&dir).map_err(|err| err.to_string())?;
        let json = serde_json::to_string_pretty(report).map_err(|err| err.to_string())?;
        std::fs::write(dir.join("diagnosis.json"), json).map_err(|err| err.to_string())
    }
}

fn action_title(id: ActionId, plan: &[PlannedAction]) -> String {
    plan.iter().find(|item| item.id == id).map(|item| item.title.clone()).unwrap_or_else(|| id.as_str().to_owned())
}

fn describe_writes(writes: &[drivedoctor_core::partition::SectorWrite]) -> String {
    let mut lines = vec![format!("{} sector(s) would be rewritten:", writes.len())];
    for write in writes.iter().take(8) {
        lines.push(format!("LBA {}: {}", write.lba, write.what));
    }
    if writes.len() > 8 {
        lines.push(format!("…and {} more", writes.len() - 8));
    }
    lines.join("\n")
}

fn preview_ntfs(probe: &ProbeInput) -> Result<String, String> {
    for volume in &probe.volumes {
        if let (Some(head), Some(backup)) = (&volume.head, &volume.backup_boot) {
            if ntfs_boot_restore(head, backup).is_some() {
                return Ok(format!(
                    "Volume {} boot sector at LBA {} would be replaced with its backup copy. One sector is rewritten.",
                    volume.index, volume.start_lba
                ));
            }
        }
    }
    Err("no NTFS volume has a valid backup and a damaged primary boot sector".into())
}

fn restore_gpt(disk: &EnumeratedDisk, permit: &WritePermit, cases: &CaseStore) -> Result<String, String> {
    let probe = probe_disk(disk, &[]);
    confirm_probe(&disk.identity.lock()?, &probe)?;
    let writes = gpt_repair_writes(
        probe.disk_sectors,
        probe.sector_size,
        probe.gpt_header.as_deref(),
        probe.gpt_entries.as_deref(),
        probe.gpt_backup_header.as_deref(),
        probe.gpt_backup_entries.as_deref(),
    )?;
    let pairs = writes.into_iter().map(|write| (write.lba, write.data)).collect::<Vec<_>>();
    write_lbas(disk, permit, &pairs, "GPT restore", cases)
}

fn restore_ntfs(disk: &EnumeratedDisk, permit: &WritePermit, cases: &CaseStore) -> Result<String, String> {
    let probe = probe_disk(disk, &[]);
    confirm_probe(&disk.identity.lock()?, &probe)?;
    for volume in &probe.volumes {
        if let (Some(head), Some(backup)) = (&volume.head, &volume.backup_boot) {
            if ntfs_boot_restore(head, backup).is_some() {
                return write_lbas(disk, permit, &[(volume.start_lba, backup.clone())], "NTFS boot restore", cases);
            }
        }
    }
    Err("no restorable NTFS boot sector was found".into())
}

fn write_lbas(disk: &EnumeratedDisk, permit: &WritePermit, writes: &[(u64, Vec<u8>)], reason: &str, cases: &CaseStore) -> Result<String, String> {
    let lock = disk.identity.lock()?;
    if permit.serial() != lock.serial {
        return Err("write permit does not match this drive".into());
    }
    let sector = disk.identity.logical_sector_size as u64;
    let reader = DiskReader::open(&disk.identity.device_path)?;
    let mut before = Vec::new();
    for (lba, data) in writes {
        if data.len() as u64 != sector && data.len() as u64 % sector != 0 {
            return Err("repair sector size does not match the disk".into());
        }
        let current = reader.read_at(lba * sector, data.len())?;
        before.push((*lba, current));
    }
    let journal = JournalFile::from_writes(&lock.serial, &disk.identity.model, disk.identity.capacity_bytes, reason, &before)?;
    let dir = cases.case_dir(&lock.serial).join("journal");
    std::fs::create_dir_all(&dir).map_err(|err| err.to_string())?;
    let path = dir.join(format!("{reason}.json").replace(' ', "-"));
    std::fs::write(&path, serde_json::to_string_pretty(&journal).map_err(|e| e.to_string())?).map_err(|err| err.to_string())?;
    let writer = DiskWriter::open(&disk.identity.device_path, &disk.identity.serial, disk.identity.logical_sector_size)?;
    for (lba, data) in writes {
        writer.write_at(permit, lba * sector, data)?;
    }
    confirm_still(&lock)?;
    Ok(format!("Wrote {} sector group(s). Previous bytes are in {}.", writes.len(), path.display()))
}

fn confirm_probe(lock: &IdentityLock, probe: &ProbeInput) -> Result<(), String> {
    lock.matches(&probe.identity).map_err(|err| err.to_string())
}

fn confirm_still(lock: &IdentityLock) -> Result<(), String> {
    let disks = list_disks()?;
    let current = disks.into_iter().find(|disk| normalize_serial(&disk.identity.serial) == lock.serial).ok_or("the drive disappeared during the operation")?;
    lock.matches(&current.identity).map_err(|err| err.to_string())
}

fn reconnect(reader: &mut DiskReader, control: &JobControl, lock: &IdentityLock) -> Result<bool, String> {
    for _ in 0..30 {
        if control.cancel.load(Ordering::Relaxed) {
            return Ok(false);
        }
        std::thread::sleep(std::time::Duration::from_secs(2));
        if reader.reopen().is_ok() && confirm_still(lock).is_ok() {
            return Ok(true);
        }
    }
    Err("the drive did not come back as the same serial, model, and capacity".into())
}

fn assert_destination(disk: &EnumeratedDisk, destination: &Path) -> Result<(), String> {
    let text = destination.to_string_lossy().to_string();
    let dest_disk = destination_disk_number(&text)?;
    if dest_disk == disk.identity.disk_number {
        return Err("the image destination is on the source disk".into());
    }
    if let Some(parent) = destination.parent() {
        if parent.as_os_str().is_empty() == false {
            let free = free_bytes(&parent.display().to_string()).unwrap_or(0);
            if free > 0 && free < disk.identity.capacity_bytes {
                return Err(format!("the destination has {free} bytes free and the source is {} bytes", disk.identity.capacity_bytes));
            }
        }
    }
    Ok(())
}

fn load_or_create_map(disk: &EnumeratedDisk, image: &Path, map_path: &Path, sector: u64) -> Result<drivedoctor_core::MapFile, String> {
    if map_path.exists() {
        let text = std::fs::read_to_string(map_path).map_err(|err| err.to_string())?;
        let map: MapFile = serde_json::from_str(&text).map_err(|err| err.to_string())?;
        map.validate()?;
        let meta = std::fs::metadata(image).map_err(|_| "the image file is missing for this map".to_string())?;
        if meta.len() != map.capacity_bytes {
            return Err("the image file size does not match the map".into());
        }
        Ok(map)
    } else if image.exists() {
        Err("the image already exists without a map file; refusing to overwrite it".into())
    } else {
        if let Some(parent) = image.parent() {
            std::fs::create_dir_all(parent).map_err(|err| err.to_string())?;
        }
        let map = drivedoctor_core::MapFile::new(&normalize_serial(&disk.identity.serial), &disk.identity.model, disk.identity.capacity_bytes, sector)?;
        let file = OpenOptions::new().write(true).create_new(true).open(image).map_err(|err| err.to_string())?;
        file.set_len(disk.identity.capacity_bytes).map_err(|err| err.to_string())?;
        save_map(map_path, &map)?;
        Ok(map)
    }
}

fn save_map(path: &Path, map: &drivedoctor_core::MapFile) -> Result<(), String> {
    let json = serde_json::to_vec_pretty(map).map_err(|err| err.to_string())?;
    let tmp = path.with_extension("json.tmp");
    std::fs::write(&tmp, json).map_err(|err| err.to_string())?;
    replace_file(&tmp, path)
}

fn phase_name(phase: Phase) -> String {
    match phase {
        Phase::Copy => "copy",
        Phase::Trim => "trim",
        Phase::Scrape => "scrape",
        Phase::Retry => "retry",
    }
    .into()
}

fn powershell_disk(number: u32, template: &str) -> Result<String, String> {
    let body = template.replace("{n}", &number.to_string());
    let script = format!("$ProgressPreference='SilentlyContinue'; $ErrorActionPreference='Stop'; {body}");
    crate::run_ps(&script)?;
    Ok("Windows accepted the change.".into())
}

fn assign_letter(number: u32) -> Result<String, String> {
    let script = format!(
        r#"$ProgressPreference='SilentlyContinue'; $ErrorActionPreference='Stop'
$used = @((Get-Volume | Where-Object DriveLetter).DriveLetter | ForEach-Object {{ [string]$_ }})
$letter = @('D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z') | Where-Object {{ $used -notcontains $_ }} | Select-Object -First 1
if (-not $letter) {{ throw 'No free drive letter' }}
$part = Get-Partition -DiskNumber {number} | Where-Object {{ -not $_.DriveLetter -and $_.Size -gt 0 }} | Select-Object -First 1
if (-not $part) {{ throw 'No partition is waiting for a letter' }}
Set-Partition -DiskNumber {number} -PartitionNumber $part.PartitionNumber -NewDriveLetter $letter
"#
    );
    crate::run_ps(&script)?;
    Ok("Assigned the next free drive letter.".into())
}

fn chkdsk(disk: &EnumeratedDisk, fix: bool) -> Result<String, String> {
    let letter = disk.partitions.iter().find_map(|part| part.letter.clone()).ok_or("assign a drive letter before chkdsk")?;
    let args = if fix { format!("{letter}: /f") } else { format!("{letter}:") };
    let output = std::process::Command::new("chkdsk.exe")
        .args(args.split_whitespace())
        .output()
        .map_err(|err| err.to_string())?;
    let text = String::from_utf8_lossy(&output.stdout).into_owned();
    let err = String::from_utf8_lossy(&output.stderr);
    if text.trim().is_empty() { Ok(err.into_owned()) } else { Ok(text) }
}

pub(crate) fn run_ps(script: &str) -> Result<String, String> {
    // Reuse the platform runner through a public wrapper below.
    drivedoctor_platform_windows::run_powershell_script(script)
}

pub fn ata(number: u32, command: &str) -> Result<String, String> {
    let disk = list_disks()?.into_iter().find(|item| item.identity.disk_number == number).ok_or("disk not connected")?;
    run_allowed_ata(&disk.identity.device_path, command)
}
