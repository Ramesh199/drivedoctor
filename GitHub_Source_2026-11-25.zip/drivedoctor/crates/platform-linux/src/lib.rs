//! Linux reads go through udev, sysfs, and `ioctl` (`SG_IO`, `HDIO_*`, `BLK*`) on `/dev/sdX`.
//! This crate is the boundary for that work. It does not pretend those calls exist yet.

#[derive(Debug)]
pub struct Unsupported;

impl std::fmt::Display for Unsupported {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("Linux support is not built yet. The intended path is udev, sysfs, SG_IO, and /dev/sdX.")
    }
}

pub fn list_disks() -> Result<(), Unsupported> {
    Err(Unsupported)
}
