//! macOS reads go through IOKit, DiskArbitration, and `/dev/rdiskN`.
//! This crate is the boundary for that work. It does not pretend those calls exist yet.

#[derive(Debug)]
pub struct Unsupported;

impl std::fmt::Display for Unsupported {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str("macOS support is not built yet. The intended path is IOKit, DiskArbitration, and /dev/rdiskN.")
    }
}

pub fn list_disks() -> Result<(), Unsupported> {
    Err(Unsupported)
}
