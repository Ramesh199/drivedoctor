use drivedoctor_core::DriveIdentity;
use serde_json::Value;

#[derive(Clone, Debug)]
pub struct EnumPartition {
    pub number: u32,
    pub letter: Option<String>,
    pub size: u64,
    pub offset: u64,
    pub filesystem: String,
    pub health: String,
    pub bitlocker_locked: bool,
}

#[derive(Clone, Debug)]
pub struct EnumeratedDisk {
    pub identity: DriveIdentity,
    pub offline: bool,
    pub read_only: bool,
    pub operational_status: String,
    pub health_status: String,
    pub partition_style: String,
    pub partitions: Vec<EnumPartition>,
    pub registry_write_protect: bool,
    pub surprise_removals: u32,
    pub driver_problems: Vec<String>,
}

const SCRIPT: &str = r#"
$ProgressPreference = 'SilentlyContinue'
$ErrorActionPreference = 'Continue'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false
$OutputEncoding = [Console]::OutputEncoding
$reg = $false
try {
  $item = Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\StorageDevicePolicies' -Name WriteProtect -ErrorAction Stop
  $reg = [int]$item.WriteProtect -eq 1
} catch {}
$removals = 0
try {
  $events = @(Get-WinEvent -FilterHashtable @{LogName='System'; Id=157; StartTime=(Get-Date).AddHours(-6)} -ErrorAction Stop)
  $removals = $events.Count
} catch {}
$drivers = @()
try {
  $drivers = @(Get-PnpDevice -Class DiskDrive,USB -Status Error -ErrorAction SilentlyContinue | ForEach-Object { $_.FriendlyName })
} catch {}
$cim = @(Get-CimInstance Win32_DiskDrive)
$disks = @(Get-Disk | ForEach-Object {
  $d = $_
  $match = $cim | Where-Object { $_.Index -eq $d.Number } | Select-Object -First 1
  $parts = @(Get-Partition -DiskNumber $d.Number -ErrorAction SilentlyContinue | ForEach-Object {
    $part = $_
    $vol = $null
    try { $vol = Get-Volume -Partition $part -ErrorAction Stop } catch {}
    $locked = $false
    if ($vol -and $vol.DriveLetter) {
      try {
        $bl = Get-BitLockerVolume -MountPoint "$($vol.DriveLetter):" -ErrorAction Stop
        $locked = ($bl.LockStatus -eq 'Locked')
      } catch {}
    }
    [pscustomobject]@{
      Number = [int]$part.PartitionNumber
      Letter = $(if ($part.DriveLetter) { [string]$part.DriveLetter } else { '' })
      Size = [int64]$part.Size
      Offset = [int64]$part.Offset
      FileSystem = $(if ($vol) { [string]$vol.FileSystem } else { '' })
      Health = $(if ($vol) { [string]$vol.HealthStatus } else { '' })
      BitLockerLocked = [bool]$locked
    }
  })
  [pscustomobject]@{
    Number = [int]$d.Number
    FriendlyName = [string]$d.FriendlyName
    SerialNumber = [string]$d.SerialNumber
    Firmware = $(if ($match) { [string]$match.FirmwareRevision } else { '' })
    Pnp = $(if ($match) { [string]$match.PNPDeviceID } else { '' })
    Model = $(if ($match -and $match.Model) { [string]$match.Model } else { [string]$d.FriendlyName })
    Size = [int64]$d.Size
    PartitionStyle = [string]$d.PartitionStyle
    HealthStatus = [string]$d.HealthStatus
    OperationalStatus = [string]$d.OperationalStatus
    BusType = [string]$d.BusType
    IsOffline = [bool]$d.IsOffline
    IsReadOnly = [bool]$d.IsReadOnly
    IsSystem = [bool]$d.IsSystem
    IsBoot = [bool]$d.IsBoot
    LogicalSectorSize = [int]$d.LogicalSectorSize
    PhysicalSectorSize = [int]$d.PhysicalSectorSize
    Partitions = @($parts)
  }
})
[pscustomobject]@{
  RegistryWriteProtect = [bool]$reg
  SurpriseRemovals = [int]$removals
  DriverProblems = @($drivers)
  Disks = @($disks)
} | ConvertTo-Json -Depth 6 -Compress
"#;

pub fn list_disks() -> Result<Vec<EnumeratedDisk>, String> {
    let raw = run_powershell(SCRIPT)?;
    let value: Value = serde_json::from_str(raw.trim()).map_err(|err| format!("disk inventory was not JSON: {err}"))?;
    let registry = value.get("RegistryWriteProtect").and_then(|v| v.as_bool()).unwrap_or(false);
    let removals = value.get("SurpriseRemovals").and_then(|v| v.as_u64()).unwrap_or(0) as u32;
    let drivers = string_list(value.get("DriverProblems"));
    let mut disks = Vec::new();
    for item in array_of(&value, "Disks") {
        if let Ok(disk) = parse_disk(&item, registry, removals, &drivers) {
            disks.push(disk);
        }
    }
    Ok(disks)
}

pub fn destination_disk_number(path: &str) -> Result<u32, String> {
    let letter = path_drive_letter(path)?;
    let script = format!(
        "$ProgressPreference='SilentlyContinue'; [Console]::OutputEncoding = New-Object System.Text.UTF8Encoding $false; $p = Get-Partition -DriveLetter '{letter}' -ErrorAction Stop | Select-Object -First 1; [int]$p.DiskNumber"
    );
    let raw = run_powershell(&script)?;
    raw.trim().parse::<u32>().map_err(|_| format!("could not map {letter}: to a physical disk ({raw})"))
}

fn parse_disk(item: &Value, registry: bool, removals: u32, drivers: &[String]) -> Result<EnumeratedDisk, String> {
    let number = item.get("Number").and_then(|v| v.as_u64()).ok_or("disk number missing")? as u32;
    let model = string_field(item, "Model");
    let pnp = string_field(item, "Pnp");
    let (vid, pid) = vid_pid(&pnp);
    let logical = item.get("LogicalSectorSize").and_then(|v| v.as_u64()).unwrap_or(512).max(512) as u32;
    let physical = item.get("PhysicalSectorSize").and_then(|v| v.as_u64()).unwrap_or(logical as u64) as u32;
    let mut partitions = Vec::new();
    for part in array_of(item, "Partitions") {
        let letter = string_field(&part, "Letter");
        partitions.push(EnumPartition {
            number: part.get("Number").and_then(|v| v.as_u64()).unwrap_or(0) as u32,
            letter: if letter.is_empty() { None } else { Some(letter) },
            size: part.get("Size").and_then(|v| v.as_u64()).unwrap_or(0),
            offset: part.get("Offset").and_then(|v| v.as_u64()).unwrap_or(0),
            filesystem: string_field(&part, "FileSystem"),
            health: string_field(&part, "Health"),
            bitlocker_locked: part.get("BitLockerLocked").and_then(|v| v.as_bool()).unwrap_or(false),
        });
    }
    Ok(EnumeratedDisk {
        identity: DriveIdentity {
            disk_number: number,
            device_path: format!(r"\\.\PhysicalDrive{number}"),
            model: if model.is_empty() { string_field(item, "FriendlyName") } else { model },
            serial: string_field(item, "SerialNumber"),
            firmware: string_field(item, "Firmware").trim().to_owned(),
            capacity_bytes: item.get("Size").and_then(|v| v.as_u64()).unwrap_or(0),
            logical_sector_size: logical,
            physical_sector_size: physical,
            bus: string_field(item, "BusType"),
            is_boot: item.get("IsBoot").and_then(|v| v.as_bool()).unwrap_or(false),
            is_system: item.get("IsSystem").and_then(|v| v.as_bool()).unwrap_or(false),
            pnp_id: pnp,
            vid,
            pid,
            usb_product: string_field(item, "FriendlyName"),
        },
        offline: item.get("IsOffline").and_then(|v| v.as_bool()).unwrap_or(false),
        read_only: item.get("IsReadOnly").and_then(|v| v.as_bool()).unwrap_or(false),
        operational_status: string_field(item, "OperationalStatus"),
        health_status: string_field(item, "HealthStatus"),
        partition_style: string_field(item, "PartitionStyle"),
        partitions,
        registry_write_protect: registry,
        surprise_removals: removals,
        driver_problems: drivers.to_vec(),
    })
}

fn vid_pid(pnp: &str) -> (Option<u16>, Option<u16>) {
    let upper = pnp.to_ascii_uppercase();
    let vid = capture_hex(&upper, "VID_");
    let pid = capture_hex(&upper, "PID_");
    (vid, pid)
}

fn capture_hex(text: &str, key: &str) -> Option<u16> {
    let start = text.find(key)? + key.len();
    let hex = text.get(start..start + 4)?;
    u16::from_str_radix(hex, 16).ok()
}

fn array_of(value: &Value, key: &str) -> Vec<Value> {
    match value.get(key) {
        Some(Value::Array(items)) => items.clone(),
        Some(Value::Null) | None => Vec::new(),
        Some(other) => vec![other.clone()],
    }
}

fn string_list(value: Option<&Value>) -> Vec<String> {
    match value {
        Some(Value::Array(items)) => items.iter().filter_map(|v| v.as_str()).map(|s| s.trim().to_owned()).filter(|s| !s.is_empty()).collect(),
        Some(Value::String(item)) => vec![item.clone()],
        _ => Vec::new(),
    }
}

fn string_field(value: &Value, key: &str) -> String {
    value.get(key).and_then(|v| v.as_str()).unwrap_or("").trim().to_owned()
}

fn path_drive_letter(path: &str) -> Result<char, String> {
    let trimmed = path.trim();
    let bytes = trimmed.as_bytes();
    if bytes.len() >= 2 && bytes[1] == b':' && bytes[0].is_ascii_alphabetic() {
        Ok((bytes[0] as char).to_ascii_uppercase())
    } else {
        Err("choose a destination on a drive letter, for example E:\\recovery\\disk.img".into())
    }
}

pub fn run_powershell(script: &str) -> Result<String, String> {
    use std::io::Write;
    use std::process::{Command, Stdio};
    let mut child = Command::new("powershell.exe")
        .args(["-NoProfile", "-NonInteractive", "-Command", "-"])
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(|err| format!("could not start PowerShell: {err}"))?;
    child.stdin.take().ok_or("PowerShell stdin closed")?.write_all(script.as_bytes()).map_err(|err| err.to_string())?;
    let output = child.wait_with_output().map_err(|err| err.to_string())?;
    if !output.status.success() {
        let err = decode(&output.stderr);
        return Err(if err.trim().is_empty() { "PowerShell disk query failed".into() } else { err });
    }
    Ok(decode(&output.stdout))
}

fn decode(bytes: &[u8]) -> String {
    if bytes.len() >= 2 && bytes[1] == 0 {
        let start = if bytes[0] == 0xFF && bytes[1] == 0xFE { 2 } else { 0 };
        let units = bytes[start..]
            .chunks(2)
            .filter(|chunk| chunk.len() == 2)
            .map(|chunk| u16::from_le_bytes([chunk[0], chunk[1]]))
            .collect::<Vec<_>>();
        String::from_utf16_lossy(&units)
    } else {
        String::from_utf8_lossy(bytes).into_owned()
    }
}
