use std::path::PathBuf;
use std::process::{Command, Stdio};
use std::time::{Duration, Instant};

use drivedoctor_core::ata::{parse_allowed, AllowedAta};
use drivedoctor_core::smart::SmartDump;

use crate::io::DiskReader;

pub fn smart_dump(device_path: &str) -> Result<Option<SmartDump>, String> {
    let Some(smartctl) = find_smartctl() else {
        return Ok(None);
    };
    for device_type in ["sat", "nvme", "scsi", "auto"] {
        let mut command = Command::new(&smartctl);
        command.arg("-j");
        if device_type != "auto" {
            command.args(["-d", device_type]);
        }
        command.arg(device_path);
        let Ok(output) = run_timeout(&mut command, Duration::from_secs(25)) else {
            continue;
        };
        let text = String::from_utf8_lossy(&output.stdout);
        if let Ok(dump) = drivedoctor_core::smart::parse_smartctl_json(&text) {
            if !dump.attributes.is_empty() || dump.nvme.is_some() || dump.passed.is_some() {
                return Ok(Some(dump));
            }
        }
    }
    Ok(None)
}

pub fn run_allowed_ata(device_path: &str, command_name: &str) -> Result<String, String> {
    let command = parse_allowed(command_name).ok_or_else(|| {
        format!("'{command_name}' is not on the read-only allow list. Allowed: identify_device, smart_read_data, smart_return_status, smart_log_directory.")
    })?;
    let smartctl = find_smartctl().ok_or("smartmontools is not installed. DriveDoctor will not send raw ATA commands without it.")?;
    let mut process = Command::new(smartctl);
    process.args(AllowedAta::smartctl_args(command));
    process.arg(device_path);
    let output = run_timeout(&mut process, Duration::from_secs(25))?;
    let mut text = String::from_utf8_lossy(&output.stdout).into_owned();
    if text.trim().is_empty() {
        text = String::from_utf8_lossy(&output.stderr).into_owned();
    }
    Ok(text)
}

pub fn find_smartctl() -> Option<PathBuf> {
    if let Ok(path) = which("smartctl.exe") {
        return Some(path);
    }
    let candidate = PathBuf::from(r"C:\Program Files\smartmontools\bin\smartctl.exe");
    if candidate.exists() { Some(candidate) } else { None }
}

fn which(name: &str) -> Result<PathBuf, String> {
    let output = Command::new("where.exe").arg(name).stdout(Stdio::piped()).stderr(Stdio::null()).output().map_err(|e| e.to_string())?;
    if !output.status.success() {
        return Err("not found".into());
    }
    let text = String::from_utf8_lossy(&output.stdout);
    let first = text.lines().find(|line| !line.trim().is_empty()).ok_or("not found")?;
    Ok(PathBuf::from(first.trim()))
}

fn run_timeout(command: &mut Command, timeout: Duration) -> Result<std::process::Output, String> {
    let mut child = command.stdout(Stdio::piped()).stderr(Stdio::piped()).spawn().map_err(|err| err.to_string())?;
    let started = Instant::now();
    loop {
        if let Some(status) = child.try_wait().map_err(|err| err.to_string())? {
            let _ = status;
            return child.wait_with_output().map_err(|err| err.to_string());
        }
        if started.elapsed() > timeout {
            let _ = child.kill();
            let _ = child.wait();
            return Err("smartctl timed out".into());
        }
        std::thread::sleep(Duration::from_millis(200));
    }
}

/// Touch the reader type so a missing device fails before smartctl is asked to guess.
pub fn device_is_openable(path: &str) -> bool {
    DiskReader::open(path).is_ok()
}
