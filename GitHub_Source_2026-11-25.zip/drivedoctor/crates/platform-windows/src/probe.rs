use drivedoctor_core::{filesystem::VolumeProbe, Symptom};

use crate::enumerate::EnumeratedDisk;
use crate::io::DiskReader;
use crate::smartctl::smart_dump;

pub fn probe_disk(disk: &EnumeratedDisk, symptoms: &[Symptom]) -> drivedoctor_core::ProbeInput {
    let sector = disk.identity.logical_sector_size.max(512);
    let sectors = if sector == 0 { 0 } else { disk.identity.capacity_bytes / sector as u64 };
    let mut probe = drivedoctor_core::ProbeInput {
        sample: false,
        identity: disk.identity.clone(),
        symptoms: symptoms.to_vec(),
        offline: disk.offline,
        read_only: disk.read_only,
        operational_status: disk.operational_status.clone(),
        registry_write_protect: disk.registry_write_protect,
        driver_problems: disk.driver_problems.clone(),
        surprise_removals: disk.surprise_removals,
        read_error: None,
        smart: None,
        sector_size: sector,
        disk_sectors: sectors,
        mbr: None,
        gpt_header: None,
        gpt_entries: None,
        gpt_backup_header: None,
        gpt_backup_entries: None,
        volumes: Vec::new(),
        lost_signatures: Vec::new(),
    };
    if let Ok(Some(dump)) = smart_dump(&disk.identity.device_path) {
        probe.smart = Some(dump);
    }
    if disk.offline {
        probe.read_error = Some("The disk is offline, so sectors were not read.".into());
        return probe;
    }
    let reader = match DiskReader::open(&disk.identity.device_path) {
        Ok(reader) => reader,
        Err(err) => {
            probe.read_error = Some(err);
            return probe;
        }
    };
    match read_tables(&reader, sector, sectors) {
        Ok(tables) => {
            probe.mbr = tables.mbr;
            probe.gpt_header = tables.header;
            probe.gpt_entries = tables.entries;
            probe.gpt_backup_header = tables.backup_header;
            probe.gpt_backup_entries = tables.backup_entries;
        }
        Err(err) => {
            probe.read_error = Some(err);
            return probe;
        }
    }
    for part in &disk.partitions {
        if part.size == 0 || sector == 0 {
            continue;
        }
        let start = part.offset / sector as u64;
        let length_sectors = part.size / sector as u64;
        let head = reader.read_at(start * sector as u64, (sector as usize) * 8).ok();
        let mut exfat = None;
        if head.as_ref().map(|bytes| bytes.len() >= 11 && &bytes[3..11] == b"EXFAT   ").unwrap_or(false) {
            exfat = reader.read_at(start * sector as u64, (sector as usize) * 12).ok();
        }
        let backup = if length_sectors > 1 {
            reader.read_at((start + length_sectors - 1) * sector as u64, sector as usize).ok()
        } else {
            None
        };
        probe.volumes.push(VolumeProbe {
            index: part.number,
            start_lba: start,
            length_bytes: part.size,
            drive_letter: part.letter.clone(),
            bitlocker_locked: part.bitlocker_locked,
            windows_filesystem: part.filesystem.clone(),
            windows_health: part.health.clone(),
            head,
            backup_boot: backup,
            exfat_boot_region: exfat,
        });
    }
    probe
}

struct Tables {
    mbr: Option<Vec<u8>>,
    header: Option<Vec<u8>>,
    entries: Option<Vec<u8>>,
    backup_header: Option<Vec<u8>>,
    backup_entries: Option<Vec<u8>>,
}

fn read_tables(reader: &DiskReader, sector: u32, disk_sectors: u64) -> Result<Tables, String> {
    let sector = sector as u64;
    let mbr = reader.read_at(0, sector as usize)?;
    let header = if disk_sectors > 1 { Some(reader.read_at(sector, sector as usize)?) } else { None };
    let backup_header = if disk_sectors > 2 {
        Some(reader.read_at((disk_sectors - 1) * sector, sector as usize)?)
    } else {
        None
    };
    let entries = header.as_ref().and_then(|bytes| read_entries(reader, bytes, sector));
    let backup_entries = backup_header.as_ref().and_then(|bytes| read_entries(reader, bytes, sector));
    Ok(Tables { mbr: Some(mbr), header, entries, backup_header, backup_entries })
}

fn read_entries(reader: &DiskReader, header: &[u8], sector: u64) -> Option<Vec<u8>> {
    if header.len() < 92 || &header[0..8] != b"EFI PART" {
        return None;
    }
    let entry_lba = u64::from_le_bytes(header[72..80].try_into().ok()?);
    let count = u32::from_le_bytes(header[80..84].try_into().ok()?);
    let size = u32::from_le_bytes(header[84..88].try_into().ok()?);
    if count == 0 || count > 4096 || !(128..=1024).contains(&size) {
        return None;
    }
    let bytes = count.saturating_mul(size) as usize;
    if bytes > 1024 * 1024 {
        return None;
    }
    // Round up to whole sectors. The extra bytes are ignored by the CRC over the declared array.
    let rounded = bytes.div_ceil(sector as usize) * sector as usize;
    reader.read_at(entry_lba.saturating_mul(sector), rounded).ok()
}
