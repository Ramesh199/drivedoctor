use std::ffi::OsStr;
use std::os::windows::ffi::OsStrExt;

use drivedoctor_core::{normalize_serial, WritePermit};

const GENERIC_READ: u32 = 0x8000_0000;
const GENERIC_WRITE: u32 = 0x4000_0000;
const FILE_SHARE_READ: u32 = 0x0000_0001;
const FILE_SHARE_WRITE: u32 = 0x0000_0002;
const OPEN_EXISTING: u32 = 3;
const FILE_FLAG_OVERLAPPED: u32 = 0x4000_0000;
const ERROR_IO_PENDING: u32 = 997;
const WAIT_OBJECT_0: u32 = 0;
const WAIT_TIMEOUT: u32 = 258;
const INFINITE: u32 = 0xFFFF_FFFF;

#[repr(C)]
struct Overlapped {
    internal: usize,
    internal_high: usize,
    offset: u32,
    offset_high: u32,
    event: isize,
}

#[link(name = "kernel32")]
extern "system" {
    fn CreateFileW(name: *const u16, access: u32, share: u32, security: *mut core::ffi::c_void, disposition: u32, flags: u32, template: isize) -> isize;
    fn ReadFile(handle: isize, buffer: *mut u8, len: u32, read: *mut u32, overlapped: *mut Overlapped) -> i32;
    fn WriteFile(handle: isize, buffer: *const u8, len: u32, written: *mut u32, overlapped: *mut Overlapped) -> i32;
    fn CreateEventW(security: *mut core::ffi::c_void, manual: i32, initial: i32, name: *const u16) -> isize;
    fn WaitForSingleObject(handle: isize, millis: u32) -> u32;
    fn GetOverlappedResult(handle: isize, overlapped: *mut Overlapped, transferred: *mut u32, wait: i32) -> i32;
    fn CancelIoEx(handle: isize, overlapped: *mut Overlapped) -> i32;
    fn CloseHandle(handle: isize) -> i32;
    fn GetLastError() -> u32;
    fn SetThreadExecutionState(flags: u32) -> u32;
    fn GetDiskFreeSpaceExW(path: *const u16, free_caller: *mut u64, total: *mut u64, free_total: *mut u64) -> i32;
    fn MoveFileExW(existing: *const u16, new_name: *const u16, flags: u32) -> i32;
}

fn wide(value: &str) -> Vec<u16> {
    OsStr::new(value).encode_wide().chain(std::iter::once(0)).collect()
}

fn last_error(action: &str) -> String {
    let code = unsafe { GetLastError() };
    format!("{action} failed (Windows error {code})")
}

pub struct DiskReader {
    path: String,
    handle: isize,
    pub timeout_ms: u32,
}

impl DiskReader {
    pub fn open(path: &str) -> Result<Self, String> {
        let handle = open_handle(path, GENERIC_READ)?;
        Ok(Self { path: path.to_owned(), handle, timeout_ms: 8_000 })
    }

    pub fn path(&self) -> &str {
        &self.path
    }

    pub fn reopen(&mut self) -> Result<(), String> {
        self.close();
        self.handle = open_handle(&self.path, GENERIC_READ)?;
        Ok(())
    }

    pub fn read_at(&self, offset: u64, length: usize) -> Result<Vec<u8>, String> {
        if length == 0 || length > 16 * 1024 * 1024 {
            return Err("refusing a read that is empty or larger than 16 MiB".into());
        }
        let mut buffer = vec![0u8; length];
        let event = unsafe { CreateEventW(std::ptr::null_mut(), 1, 0, std::ptr::null()) };
        if event == 0 || event == -1 {
            return Err(last_error("CreateEvent"));
        }
        let mut overlapped = Overlapped {
            internal: 0,
            internal_high: 0,
            offset: offset as u32,
            offset_high: (offset >> 32) as u32,
            event,
        };
        let mut transferred = 0u32;
        let ok = unsafe {
            ReadFile(self.handle, buffer.as_mut_ptr(), length as u32, &mut transferred, &mut overlapped)
        };
        let result = if ok == 0 {
            let err = unsafe { GetLastError() };
            if err != ERROR_IO_PENDING {
                Err(format!("read at {offset} failed (Windows error {err})"))
            } else {
                let wait = unsafe { WaitForSingleObject(event, self.timeout_ms) };
                if wait == WAIT_TIMEOUT {
                    unsafe {
                        CancelIoEx(self.handle, &mut overlapped);
                        WaitForSingleObject(event, INFINITE);
                    }
                    Err(format!("read timed out at byte offset {offset}"))
                } else if wait != WAIT_OBJECT_0 {
                    Err(format!("read wait failed at {offset}"))
                } else if unsafe { GetOverlappedResult(self.handle, &mut overlapped, &mut transferred, 0) } == 0 {
                    Err(last_error(&format!("read at {offset}")))
                } else {
                    Ok(())
                }
            }
        } else {
            Ok(())
        };
        unsafe { CloseHandle(event) };
        result?;
        if transferred as usize != length {
            return Err(format!("short read at {offset}: {transferred} of {length} bytes"));
        }
        Ok(buffer)
    }

    fn close(&mut self) {
        if self.handle != 0 && self.handle != -1 {
            unsafe { CloseHandle(self.handle) };
            self.handle = -1;
        }
    }
}

impl Drop for DiskReader {
    fn drop(&mut self) {
        self.close();
    }
}

pub struct DiskWriter {
    handle: isize,
    serial: String,
    sector_size: u32,
}

impl DiskWriter {
    pub fn open(path: &str, serial: &str, sector_size: u32) -> Result<Self, String> {
        if sector_size == 0 || !sector_size.is_power_of_two() {
            return Err("sector size is not usable".into());
        }
        Ok(Self {
            handle: open_handle(path, GENERIC_READ | GENERIC_WRITE)?,
            serial: normalize_serial(serial),
            sector_size,
        })
    }

    pub fn write_at(&self, permit: &WritePermit, offset: u64, data: &[u8]) -> Result<(), String> {
        if permit.serial() != self.serial {
            return Err("write permit is for a different drive; aborting".into());
        }
        if data.is_empty() || data.len() % self.sector_size as usize != 0 || offset % self.sector_size as u64 != 0 {
            return Err("writes must be sector aligned".into());
        }
        if data.len() > 1024 * 1024 {
            return Err("refusing a single write larger than 1 MiB".into());
        }
        let event = unsafe { CreateEventW(std::ptr::null_mut(), 1, 0, std::ptr::null()) };
        if event == 0 || event == -1 {
            return Err(last_error("CreateEvent"));
        }
        let mut overlapped = Overlapped {
            internal: 0,
            internal_high: 0,
            offset: offset as u32,
            offset_high: (offset >> 32) as u32,
            event,
        };
        let mut transferred = 0u32;
        let ok = unsafe { WriteFile(self.handle, data.as_ptr(), data.len() as u32, &mut transferred, &mut overlapped) };
        let result = if ok == 0 {
            let err = unsafe { GetLastError() };
            if err != ERROR_IO_PENDING {
                Err(format!("write at {offset} failed (Windows error {err})"))
            } else {
                let wait = unsafe { WaitForSingleObject(event, 20_000) };
                if wait == WAIT_TIMEOUT {
                    unsafe {
                        CancelIoEx(self.handle, &mut overlapped);
                        WaitForSingleObject(event, INFINITE);
                    }
                    Err(format!("write timed out at {offset}; stopping so a partial repair is not continued blindly"))
                } else if unsafe { GetOverlappedResult(self.handle, &mut overlapped, &mut transferred, 0) } == 0 {
                    Err(last_error(&format!("write at {offset}")))
                } else {
                    Ok(())
                }
            }
        } else {
            Ok(())
        };
        unsafe { CloseHandle(event) };
        result?;
        if transferred as usize != data.len() {
            return Err(format!("short write at {offset}"));
        }
        Ok(())
    }
}

impl Drop for DiskWriter {
    fn drop(&mut self) {
        if self.handle != 0 && self.handle != -1 {
            unsafe { CloseHandle(self.handle) };
        }
    }
}

fn open_handle(path: &str, access: u32) -> Result<isize, String> {
    let name = wide(path);
    let handle = unsafe {
        CreateFileW(
            name.as_ptr(),
            access,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            std::ptr::null_mut(),
            OPEN_EXISTING,
            FILE_FLAG_OVERLAPPED,
            0,
        )
    };
    if handle == 0 || handle == -1 {
        Err(last_error(&format!("opening {path}")))
    } else {
        Ok(handle)
    }
}

pub struct AwakeGuard;

impl AwakeGuard {
    pub fn acquire() -> Self {
        unsafe { SetThreadExecutionState(0x8000_0000 | 0x0000_0001) };
        Self
    }
}

impl Drop for AwakeGuard {
    fn drop(&mut self) {
        unsafe { SetThreadExecutionState(0x8000_0000) };
    }
}

pub fn keep_awake() -> AwakeGuard {
    AwakeGuard::acquire()
}

pub fn free_bytes(path: &str) -> Result<u64, String> {
    let name = wide(path);
    let mut free = 0u64;
    let ok = unsafe { GetDiskFreeSpaceExW(name.as_ptr(), &mut free, std::ptr::null_mut(), std::ptr::null_mut()) };
    if ok == 0 {
        Err(last_error("GetDiskFreeSpaceEx"))
    } else {
        Ok(free)
    }
}

pub fn replace_file(from: &std::path::Path, to: &std::path::Path) -> Result<(), String> {
    let src = wide(&from.to_string_lossy());
    let dst = wide(&to.to_string_lossy());
    let ok = unsafe { MoveFileExW(src.as_ptr(), dst.as_ptr(), 0x1 | 0x8) };
    if ok == 0 {
        Err(last_error("replacing file"))
    } else {
        Ok(())
    }
}
