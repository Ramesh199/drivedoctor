//! Windows disk enumeration and raw reads. Writes live behind a [`WritePermit`].

#![cfg(windows)]

mod enumerate;
mod io;
mod probe;
mod smartctl;

pub use enumerate::{destination_disk_number, list_disks, run_powershell as run_powershell_script, EnumeratedDisk};
pub use io::{free_bytes, keep_awake, replace_file, DiskReader, DiskWriter};
pub use probe::probe_disk;
pub use smartctl::{run_allowed_ata, smart_dump};
