use std::io::{Read, Seek, SeekFrom};

#[derive(Clone, Debug, PartialEq, Eq, serde::Serialize)]
pub struct CarvedFile {
    pub offset: u64,
    pub length: u64,
    pub extension: String,
}

impl CarvedFile {
    pub fn name(&self) -> String {
        format!("recovered_{:012x}.{}", self.offset, self.extension)
    }
}

const CHUNK: usize = 1024 * 1024;
const MAX_CARVE: u64 = 64 * 1024 * 1024;
const SIGNATURES: &[(&[u8], &str)] = &[
    (b"\x89PNG\r\n\x1a\n", "png"),
    (b"\xff\xd8\xff", "jpg"),
    (b"%PDF-", "pdf"),
    (b"PK\x03\x04", "zip"),
];

/// Scan an image file. This never opens a physical disk.
pub fn scan_image<R: Read + Seek>(mut image: R, length: u64) -> Result<Vec<CarvedFile>, String> {
    let mut found = Vec::new();
    let mut seen = Vec::new();
    let mut position = 0u64;
    let mut carry = Vec::new();
    let overlap = 64 * 1024usize;
    loop {
        let mut chunk = vec![0u8; CHUNK];
        let read = image.read(&mut chunk).map_err(|err| err.to_string())?;
        if read == 0 {
            break;
        }
        chunk.truncate(read);
        let mut data = carry.clone();
        data.extend_from_slice(&chunk);
        let base = position - carry.len() as u64;
        for (signature, extension) in SIGNATURES {
            let mut cursor = 0usize;
            while let Some(rel) = find_from(&data, cursor, signature) {
                let absolute = base + rel as u64;
                cursor = rel + signature.len();
                if seen.contains(&absolute) {
                    continue;
                }
                if let Some(end) = find_end(&data, rel, extension) {
                    let size = end as u64 - rel as u64;
                    if size > 0 && size <= MAX_CARVE && end <= data.len() {
                        seen.push(absolute);
                        let mut extension = (*extension).to_owned();
                        if extension == "zip" && data[rel..end].windows(18).any(|window| window == b"word/document.xml") {
                            extension = "docx".into();
                        }
                        found.push(CarvedFile { offset: absolute, length: size, extension });
                    }
                }
            }
        }
        position += read as u64;
        if data.len() > overlap {
            carry = data[data.len() - overlap..].to_vec();
        } else {
            carry = data;
        }
        if position >= length {
            break;
        }
    }
    found.sort_by_key(|item| item.offset);
    let _ = image.seek(SeekFrom::Start(0));
    Ok(found)
}

fn find_from(data: &[u8], start: usize, needle: &[u8]) -> Option<usize> {
    data[start..].windows(needle.len()).position(|window| window == needle).map(|pos| start + pos)
}

fn find_end(data: &[u8], start: usize, extension: &str) -> Option<usize> {
    match extension {
        "png" => find_from(data, start, b"IEND").map(|at| at + 8),
        "jpg" => find_from(data, start, b"\xff\xd9").map(|at| at + 2),
        "pdf" => find_from(data, start, b"%%EOF").map(|at| at + 5),
        "zip" => {
            let end = find_from(data, start, b"PK\x05\x06")?;
            if end + 22 > data.len() {
                return None;
            }
            let comment = u16::from_le_bytes([data[end + 20], data[end + 21]]) as usize;
            Some(end + 22 + comment)
        }
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Cursor;

    #[test]
    fn finds_a_png_inside_an_image() {
        let payload = b"prefix\x89PNG\r\n\x1a\npayloadIEND\x00\x00\x00\x00";
        let found = scan_image(Cursor::new(payload.to_vec()), payload.len() as u64).unwrap();
        assert_eq!(found.len(), 1);
        assert_eq!(found[0].offset, 6);
        assert_eq!(found[0].extension, "png");
    }
}
