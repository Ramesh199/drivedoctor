use crate::imaging::MapSummary;
use crate::model::DiagnosisReport;

pub fn handoff_report(report: &DiagnosisReport, map: Option<&MapSummary>, log: &[String]) -> String {
    let mut text = String::new();
    text.push_str("# DriveDoctor lab handoff\n\n");
    text.push_str("This report describes what the software saw. It is not a repair.\n\n");
    text.push_str(&format!("- Model: {}\n", report.identity.model));
    text.push_str(&format!("- Serial: {}\n", report.identity.serial));
    text.push_str(&format!("- Capacity: {} bytes\n", report.identity.capacity_bytes));
    text.push_str(&format!("- Bus: {}\n", report.identity.bus));
    text.push_str(&format!("- Firmware: {}\n", report.identity.firmware));
    text.push_str(&format!("- Path at capture: {}\n", report.identity.device_path));
    text.push_str(&format!("- Repairability: {}\n\n", report.repairability.label()));
    text.push_str("## What failed\n\n");
    text.push_str(&report.root_cause);
    text.push_str("\n\n");
    if let Some(fault) = &report.hardware_fault {
        text.push_str(&format!("## {}\n\n{}\n\n", fault.kind.title(), fault.explanation));
        for step in &fault.next_steps {
            text.push_str(&format!("- {step}\n"));
        }
        text.push('\n');
    }
    text.push_str("## Layer findings\n\n");
    for finding in &report.findings {
        text.push_str(&format!(
            "### {} — {}\n\n{}\n\n",
            finding.layer.title(),
            finding.summary,
            finding.detail
        ));
    }
    if !report.warnings.is_empty() {
        text.push_str("## Warnings\n\n");
        for warning in &report.warnings {
            text.push_str(&format!("- {warning}\n"));
        }
        text.push('\n');
    }
    if let Some(map) = map {
        text.push_str("## Image map\n\n");
        text.push_str(&format!(
            "Finished {} bytes, unreadable {} bytes, remaining {} bytes. Complete: {}.\n\n",
            map.finished, map.bad, map.remaining, map.complete
        ));
    }
    if !log.is_empty() {
        text.push_str("## Case log\n\n");
        for line in log {
            text.push_str(&format!("- {line}\n"));
        }
    }
    text.push_str("\nDo not keep powering a drive that clicks, does not spin, or smells burnt.\n");
    text
}
