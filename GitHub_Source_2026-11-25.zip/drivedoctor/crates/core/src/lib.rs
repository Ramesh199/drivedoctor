//! DriveDoctor core: layered diagnosis, safety gate, and repair planning.
//!
//! This crate never opens a device. Platform crates collect bytes and OS facts;
//! everything that decides *what is wrong* and *what may be written* lives here
//! and is covered by unit tests.

#![forbid(unsafe_code)]

pub mod ata;
pub mod bridges;
pub mod carving;
pub mod crc;
pub mod diagnose;
pub mod error;
pub mod filesystem;
pub mod firmware;
pub mod handoff;
pub mod imaging;
pub mod journal;
pub mod model;
pub mod ntfs;
pub mod partition;
pub mod plan;
pub mod safety;
pub mod samples;
pub mod smart;
pub mod symptoms;
pub mod trust;

pub use diagnose::{diagnose, ProbeInput};
pub use error::{AuthError, CoreError};
pub use handoff::handoff_report;
pub use imaging::{MapFile, Phase, Planner, RegionStatus};
pub use model::*;
pub use partition::{gpt_repair_writes, protective_mbr};
pub use safety::{action_on_plan, authorize, required_phrase, SafetyGate};
pub use trust::trust_score;
