use crate::diagnose::{diagnose, ProbeInput};
use crate::filesystem::{synthesize_ntfs_boot, VolumeProbe};
use crate::model::{DiagnosisReport, DriveIdentity, Symptom};
use crate::partition::{synthesize_gpt, GptPartSpec, BASIC_DATA_GUID};
use crate::smart::{SmartAttribute, SmartDump};

fn identity() -> DriveIdentity {
    DriveIdentity {
        disk_number: 9,
        device_path: r"\\.\PhysicalDrive9".into(),
        model: "WDC WD20EZRZ-00Z5HB0".into(),
        serial: "WD-SAMPLE0001".into(),
        firmware: "80.00A80".into(),
        capacity_bytes: 2048 * 512,
        logical_sector_size: 512,
        physical_sector_size: 4096,
        bus: "USB".into(),
        is_boot: false,
        is_system: false,
        pnp_id: r"USBSTOR\DISK&VEN_WDC".into(),
        vid: Some(0x174C),
        pid: Some(0x55AA),
        usb_product: "ASMedia".into(),
    }
}

fn healthy_probe() -> ProbeInput {
    let disk = synthesize_gpt(
        2048,
        512,
        &[GptPartSpec { type_guid: BASIC_DATA_GUID, start_lba: 34, end_lba: 1800, name: "Data".into() }],
    )
    .expect("sample gpt");
    let boot = synthesize_ntfs_boot(1700);
    ProbeInput {
        sample: true,
        identity: identity(),
        symptoms: vec![],
        offline: false,
        read_only: false,
        operational_status: "Online".into(),
        registry_write_protect: false,
        driver_problems: vec![],
        surprise_removals: 0,
        read_error: None,
        smart: Some(SmartDump { passed: Some(true), ..SmartDump::default() }),
        sector_size: 512,
        disk_sectors: 2048,
        mbr: Some(disk.mbr),
        gpt_header: Some(disk.header),
        gpt_entries: Some(disk.entries.clone()),
        gpt_backup_header: Some(disk.backup_header),
        gpt_backup_entries: Some(disk.entries),
        volumes: vec![VolumeProbe {
            index: 1,
            start_lba: 34,
            length_bytes: 1700 * 512,
            drive_letter: Some("E".into()),
            head: Some(boot.clone()),
            backup_boot: Some(boot),
            windows_filesystem: "NTFS".into(),
            ..VolumeProbe::default()
        }],
        lost_signatures: vec![],
    }
}

pub fn sample_ids() -> &'static [&'static str] {
    &["healthy", "clicking", "gpt-damage", "pending"]
}

pub fn sample(id: &str) -> Option<DiagnosisReport> {
    let probe = match id {
        "healthy" => healthy_probe(),
        "clicking" => {
            let mut probe = healthy_probe();
            probe.symptoms = vec![Symptom::Clicking];
            probe.identity.serial = "WD-SAMPLECLICK".into();
            probe
        }
        "gpt-damage" => {
            let mut probe = healthy_probe();
            if let Some(header) = probe.gpt_header.as_mut() {
                header[0] = b'X';
            }
            probe.identity.serial = "WD-SAMPLEGPT".into();
            probe
        }
        "pending" => {
            let mut probe = healthy_probe();
            probe.identity.serial = "WD-SAMPLEPEND".into();
            probe.smart = Some(SmartDump {
                passed: Some(true),
                attributes: vec![SmartAttribute {
                    id: 197,
                    name: "Current_Pending_Sector".into(),
                    current: 100,
                    worst: 100,
                    threshold: 0,
                    raw: 4,
                    prefail: false,
                }],
                ..SmartDump::default()
            });
            probe
        }
        _ => return None,
    };
    Some(diagnose(&probe))
}
