use serde::{Deserialize, Serialize};

use crate::model::{HardwareFaultKind, Symptom};

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Confidence {
    Low,
    Medium,
    High,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SymptomCause {
    pub symptom: Symptom,
    pub cause: String,
    pub confidence: Confidence,
    pub hardware: Option<HardwareFaultKind>,
    pub power_down: bool,
}

pub fn interpret(symptoms: &[Symptom]) -> Vec<SymptomCause> {
    let mut out = Vec::new();
    for symptom in symptoms {
        let cause = match symptom {
            Symptom::Clicking => SymptomCause {
                symptom: *symptom,
                cause: "Repeated clicking is the actuator parking and retrying. The head stack or its firmware calibration is the usual cause.".into(),
                confidence: Confidence::High,
                hardware: Some(HardwareFaultKind::HeadCrash),
                power_down: true,
            },
            Symptom::NotSpinning => SymptomCause {
                symptom: *symptom,
                cause: "A drive that does not spin is usually a seized bearing, a dead motor driver, or no power getting through the enclosure.".into(),
                confidence: Confidence::High,
                hardware: Some(HardwareFaultKind::SeizedMotor),
                power_down: true,
            },
            Symptom::BurntSmell => SymptomCause {
                symptom: *symptom,
                cause: "A burnt smell means a component on the board or in the enclosure has overheated. Powering it again can finish the damage.".into(),
                confidence: Confidence::High,
                hardware: Some(HardwareFaultKind::FireOrBurn),
                power_down: true,
            },
            Symptom::Liquid => SymptomCause {
                symptom: *symptom,
                cause: "Liquid bridges contacts and corrodes the board. Do not power the drive to 'see if it works'.".into(),
                confidence: Confidence::High,
                hardware: Some(HardwareFaultKind::LiquidDamage),
                power_down: true,
            },
            Symptom::Beeping => SymptomCause {
                symptom: *symptom,
                cause: "Beeping from an external drive is usually the USB port or hub not supplying enough power, or a failed 12 V adapter on a desktop enclosure.".into(),
                confidence: Confidence::Medium,
                hardware: Some(HardwareFaultKind::PcbFailure),
                power_down: false,
            },
            Symptom::Buzzing => SymptomCause {
                symptom: *symptom,
                cause: "A buzz can be the motor struggling to spin (power or bearing) or the heads stuck on the ramp.".into(),
                confidence: Confidence::Medium,
                hardware: Some(HardwareFaultKind::SeizedMotor),
                power_down: true,
            },
            Symptom::Dropped => SymptomCause {
                symptom: *symptom,
                cause: "A drop while spinning often damages the heads. If it now clicks or is not detected, stop retrying it.".into(),
                confidence: Confidence::Medium,
                hardware: None,
                power_down: false,
            },
            Symptom::VerySlow => SymptomCause {
                symptom: *symptom,
                cause: "Long delays usually mean the drive is retrying bad sectors, or a USB bridge is renegotiating the link.".into(),
                confidence: Confidence::Medium,
                hardware: None,
                power_down: false,
            },
            Symptom::Intermittent | Symptom::NotDetected => SymptomCause {
                symptom: *symptom,
                cause: "A drive that appears and disappears is often a cable, a weak port, USB selective suspend, or a failing bridge board.".into(),
                confidence: Confidence::Medium,
                hardware: None,
                power_down: false,
            },
            Symptom::AsksToFormat => SymptomCause {
                symptom: *symptom,
                cause: "Windows asks to format a volume when the partition table or the file system boot sector is unreadable. That is not, by itself, a dead drive.".into(),
                confidence: Confidence::Medium,
                hardware: None,
                power_down: false,
            },
            Symptom::ZeroCapacity => SymptomCause {
                symptom: *symptom,
                cause: "A size of 0 bytes or a few gigabytes on a large drive can be a firmware lock, a bridge that cannot read the drive, or an empty card reader.".into(),
                confidence: Confidence::Medium,
                hardware: Some(HardwareFaultKind::FirmwareCorruption),
                power_down: false,
            },
        };
        out.push(cause);
    }
    out
}

/// Severe mechanical or contamination symptoms. Software must not run write-heavy repair.
pub fn severe_hardware(symptoms: &[Symptom]) -> Option<SymptomCause> {
    interpret(symptoms).into_iter().find(|cause| cause.power_down && cause.hardware.is_some())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn clicking_is_a_stop_now_head_failure() {
        let cause = severe_hardware(&[Symptom::Clicking, Symptom::AsksToFormat]).unwrap();
        assert_eq!(cause.hardware, Some(HardwareFaultKind::HeadCrash));
        assert!(cause.power_down);
    }
}
