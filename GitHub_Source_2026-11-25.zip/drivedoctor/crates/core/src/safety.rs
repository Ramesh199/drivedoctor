use crate::error::AuthError;
use crate::model::{
    normalize_serial, ActionId, DriveIdentity, PlannedAction, RiskLevel, WritePermit,
};

/// Unlock for any repair that writes sectors or filesystem metadata.
///
/// Level 0 OS configuration (bring online, assign a letter) is `RiskLevel::Safe`
/// because imaging and diagnosis need it and it does not rewrite user data.
/// Metadata repair and everything above stay locked until an image finishes
/// or the user types the drive serial to confirm there is nothing to keep.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SafetyGate {
    pub image_complete: bool,
    pub image_path: Option<String>,
    pub no_data_serial: Option<String>,
}

impl SafetyGate {
    pub fn locked() -> Self {
        Self {
            image_complete: false,
            image_path: None,
            no_data_serial: None,
        }
    }

    pub fn is_open_for(&self, identity: &DriveIdentity) -> bool {
        if self.image_complete {
            return true;
        }
        match &self.no_data_serial {
            Some(typed) => identity.has_serial() && normalize_serial(typed) == normalize_serial(&identity.serial),
            None => false,
        }
    }
}

/// Issue a write permit, or refuse.
///
/// `typed_phrase` is the serial for metadata and targeted repairs. For
/// `DestroysAll` it must be `ERASE ` plus the serial. Safe actions do not
/// need a phrase. `lighter_fix_available` blocks skipping ahead to a wipe
/// or format while a metadata repair is still on the plan.
pub fn authorize(
    action: &PlannedAction,
    identity: &DriveIdentity,
    gate: &SafetyGate,
    typed_phrase: &str,
    hardware_blocks_writes: bool,
    lighter_fix_available: bool,
) -> Result<WritePermit, AuthError> {
    if identity.is_system_disk() && action.risk.writes_disk() {
        return Err(AuthError::SystemDiskForbidden);
    }
    if hardware_blocks_writes && action.level >= 2 {
        return Err(AuthError::HardwareFaultBlocksWrite);
    }
    if !action.recommended && lighter_fix_available && action.risk.writes_disk() {
        return Err(AuthError::LighterFixAvailable);
    }
    if action.risk.writes_disk() && !gate.is_open_for(identity) {
        return Err(AuthError::SafetyGateLocked);
    }
    if action.requires_typed_serial {
        if !identity.has_serial() {
            return Err(AuthError::SerialRequired);
        }
        let serial = normalize_serial(&identity.serial);
        let typed = normalize_serial(typed_phrase);
        let expected = if action.risk == RiskLevel::DestroysAll {
            format!("ERASE{serial}")
        } else {
            serial.clone()
        };
        if typed != expected {
            return Err(AuthError::PhraseMismatch);
        }
    }
    Ok(WritePermit::new(action.id, normalize_serial(&identity.serial), action.risk))
}

/// Phrase the user must type. Empty when the action does not require one.
pub fn required_phrase(action: &PlannedAction, identity: &DriveIdentity) -> String {
    if !action.requires_typed_serial || !identity.has_serial() {
        return String::new();
    }
    let serial = normalize_serial(&identity.serial);
    if action.risk == RiskLevel::DestroysAll {
        format!("ERASE {serial}")
    } else {
        serial
    }
}

pub fn action_on_plan<'a>(plan: &'a [PlannedAction], id: ActionId) -> Result<&'a PlannedAction, AuthError> {
    plan.iter().find(|item| item.id == id).ok_or(AuthError::ActionNotAllowed)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::ActionId;

    fn disk(system: bool) -> DriveIdentity {
        DriveIdentity {
            disk_number: 2,
            device_path: r"\\.\PhysicalDrive2".into(),
            model: "WDC WD20EZRZ".into(),
            serial: "WD-WCC4N1234567".into(),
            firmware: "80.00A80".into(),
            capacity_bytes: 2_000_398_934_016,
            logical_sector_size: 512,
            physical_sector_size: 4096,
            bus: "USB".into(),
            is_boot: system,
            is_system: system,
            pnp_id: String::new(),
            vid: Some(0x1058),
            pid: Some(0x25A2),
            usb_product: "My Passport".into(),
        }
    }

    fn action(id: ActionId, level: u8, risk: RiskLevel, recommended: bool) -> PlannedAction {
        PlannedAction {
            id,
            level,
            title: "t".into(),
            summary: "s".into(),
            risk,
            data_effect: "d".into(),
            estimated_time: "1s".into(),
            recommended,
            requires_gate: risk.writes_disk(),
            requires_typed_serial: risk.writes_disk(),
        }
    }

    #[test]
    fn metadata_stays_locked_until_image_or_serial() {
        let disk = disk(false);
        let action = action(ActionId::RestoreGpt, 1, RiskLevel::Metadata, true);
        let err = authorize(&action, &disk, &SafetyGate::locked(), "", false, false).unwrap_err();
        assert_eq!(err, AuthError::SafetyGateLocked);

        let imaged = SafetyGate {
            image_complete: true,
            image_path: Some("E:\\case\\disk.img".into()),
            no_data_serial: None,
        };
        assert!(authorize(&action, &disk, &imaged, "WD-WCC4N1234567", false, false).is_ok());

        let acked = SafetyGate {
            image_complete: false,
            image_path: None,
            no_data_serial: Some("wd-wcc4n1234567".into()),
        };
        assert!(authorize(&action, &disk, &acked, "WD WCC4N1234567", false, false).is_ok());
    }

    #[test]
    fn wrong_phrase_and_system_disk_are_refused() {
        let action = action(ActionId::RestoreNtfsBoot, 1, RiskLevel::Metadata, true);
        let imaged = SafetyGate { image_complete: true, image_path: None, no_data_serial: None };
        let err = authorize(&action, &disk(false), &imaged, "NOPE", false, false).unwrap_err();
        assert_eq!(err, AuthError::PhraseMismatch);
        let err = authorize(&action, &disk(true), &imaged, "WD-WCC4N1234567", false, false).unwrap_err();
        assert_eq!(err, AuthError::SystemDiskForbidden);
    }

    #[test]
    fn wipe_needs_erase_phrase_and_yields_to_lighter_fix() {
        let wipe = action(ActionId::ZeroFill, 3, RiskLevel::DestroysAll, false);
        let imaged = SafetyGate { image_complete: true, image_path: None, no_data_serial: None };
        let err = authorize(&wipe, &disk(false), &imaged, "WD-WCC4N1234567", false, true).unwrap_err();
        assert_eq!(err, AuthError::LighterFixAvailable);
        let err = authorize(&wipe, &disk(false), &imaged, "ERASE WD-WCC4N1234567", true, false).unwrap_err();
        assert_eq!(err, AuthError::HardwareFaultBlocksWrite);
        let permit = authorize(&wipe, &disk(false), &imaged, "erase WD-WCC4N1234567", false, false).unwrap();
        assert_eq!(permit.action(), ActionId::ZeroFill);
    }

    #[test]
    fn identity_lock_rejects_a_different_drive_on_the_same_path() {
        let original = disk(false).lock().unwrap();
        let mut swapped = disk(false);
        swapped.serial = "OTHER".into();
        assert_eq!(original.matches(&swapped), Err(AuthError::IdentityChanged));
        swapped.serial = "WD-WCC4N1234567".into();
        swapped.capacity_bytes -= 512;
        assert_eq!(original.matches(&swapped), Err(AuthError::IdentityChanged));
        swapped.capacity_bytes += 512;
        assert!(original.matches(&swapped).is_ok());
    }
}
