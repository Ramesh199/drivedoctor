use serde::{Deserialize, Serialize};

/// ddrescue-style interval map. Statuses stay sector-aligned.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum RegionStatus {
    Finished,
    NonTried,
    NonTrimmed,
    NonScraped,
    Bad,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct Region {
    pub offset: u64,
    pub length: u64,
    pub status: RegionStatus,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct MapFile {
    pub version: u32,
    pub serial: String,
    pub model: String,
    pub capacity_bytes: u64,
    pub sector_size: u64,
    pub regions: Vec<Region>,
    pub retry_done: bool,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum Phase {
    Copy,
    Trim,
    Scrape,
    Retry,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct ReadRequest {
    pub offset: u64,
    pub length: u64,
    pub phase: Phase,
}

#[derive(Clone, Debug)]
pub struct Planner {
    pub phase: Phase,
    pub cursor: u64,
    pub copy_block: u64,
    pub skip: u64,
    pub max_skip: u64,
    forward_failed_at: Option<u64>,
    retried_until: u64,
}

#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct ZoneMap {
    pub zone_count: u32,
    pub source_size: u64,
    pub max_latency_us: Vec<u64>,
    pub error_count: Vec<u32>,
}

impl MapFile {
    pub fn new(serial: &str, model: &str, capacity_bytes: u64, sector_size: u64) -> Result<Self, String> {
        if capacity_bytes == 0 || sector_size == 0 || capacity_bytes % sector_size != 0 {
            return Err("disk size must be a positive multiple of the sector size".into());
        }
        Ok(Self {
            version: 1,
            serial: serial.to_owned(),
            model: model.to_owned(),
            capacity_bytes,
            sector_size,
            regions: vec![Region { offset: 0, length: capacity_bytes, status: RegionStatus::NonTried }],
            retry_done: false,
        })
    }

    pub fn validate(&self) -> Result<(), String> {
        if self.sector_size == 0 {
            return Err("sector size is zero".into());
        }
        let mut cursor = 0u64;
        for region in &self.regions {
            if region.offset != cursor || region.length == 0 {
                return Err("map regions must cover the disk without gaps".into());
            }
            if region.offset % self.sector_size != 0 || region.length % self.sector_size != 0 {
                return Err("map regions must be sector aligned".into());
            }
            cursor = cursor.saturating_add(region.length);
        }
        if cursor != self.capacity_bytes {
            return Err("map size does not match the source disk".into());
        }
        Ok(())
    }

    pub fn region_index(&self, offset: u64) -> Result<usize, String> {
        self.regions
            .iter()
            .position(|region| region.offset <= offset && offset < region.offset + region.length)
            .ok_or_else(|| "offset is outside the map".into())
    }

    pub fn set(&mut self, start: u64, length: u64, status: RegionStatus) -> Result<(), String> {
        let end = start.checked_add(length).ok_or("map update overflow")?;
        if length == 0 || end > self.capacity_bytes {
            return Err("map update is outside the source disk".into());
        }
        let mut changed = Vec::new();
        for region in &self.regions {
            let region_end = region.offset + region.length;
            if region_end <= start || region.offset >= end {
                changed.push(region.clone());
                continue;
            }
            if region.offset < start {
                changed.push(Region { offset: region.offset, length: start - region.offset, status: region.status });
            }
            let overlap_start = start.max(region.offset);
            let overlap_end = end.min(region_end);
            changed.push(Region { offset: overlap_start, length: overlap_end - overlap_start, status });
            if region_end > end {
                changed.push(Region { offset: end, length: region_end - end, status: region.status });
            }
        }
        let mut merged = Vec::new();
        for region in changed {
            if let Some(last) = merged.last_mut() {
                let last: &mut Region = last;
                if last.status == region.status && last.offset + last.length == region.offset {
                    last.length += region.length;
                    continue;
                }
            }
            merged.push(region);
        }
        self.regions = merged;
        self.validate()
    }

    pub fn bytes_with(&self, status: RegionStatus) -> u64 {
        self.regions.iter().filter(|region| region.status == status).map(|region| region.length).sum()
    }

    /// A rescue copy is complete when every sector was read or recorded as bad.
    pub fn rescue_finished(&self) -> bool {
        self.retry_done
            && self.regions.iter().all(|region| {
                matches!(region.status, RegionStatus::Finished | RegionStatus::Bad)
            })
    }

    pub fn summary(&self) -> MapSummary {
        MapSummary {
            finished: self.bytes_with(RegionStatus::Finished),
            bad: self.bytes_with(RegionStatus::Bad),
            remaining: self.capacity_bytes
                - self.bytes_with(RegionStatus::Finished)
                - self.bytes_with(RegionStatus::Bad),
            complete: self.rescue_finished(),
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct MapSummary {
    pub finished: u64,
    pub bad: u64,
    pub remaining: u64,
    pub complete: bool,
}

impl Planner {
    pub fn start(map: &MapFile, copy_block: u64) -> Result<Self, String> {
        map.validate()?;
        let copy_block = copy_block.max(map.sector_size);
        let copy_block = copy_block - (copy_block % map.sector_size);
        Ok(Self {
            phase: initial_phase(map),
            cursor: 0,
            copy_block,
            skip: copy_block,
            max_skip: (64 * 1024 * 1024).max(copy_block),
            forward_failed_at: None,
            retried_until: 0,
        })
    }

    pub fn next(&mut self, map: &mut MapFile) -> Option<ReadRequest> {
        match self.phase {
            Phase::Copy => self.next_copy(map),
            Phase::Trim => self.next_trim(map),
            Phase::Scrape => self.next_status(map, RegionStatus::NonScraped, Phase::Scrape),
            Phase::Retry => self.next_retry(map),
        }
    }

    /// Move to the next phase. Returns true when there is more work.
    pub fn advance(&mut self, map: &mut MapFile) -> bool {
        self.cursor = 0;
        self.forward_failed_at = None;
        self.phase = match self.phase {
            Phase::Copy if map.bytes_with(RegionStatus::NonTried) > 0 && self.copy_block > map.sector_size => {
                self.copy_block = (self.copy_block / 2).max(map.sector_size);
                self.copy_block -= self.copy_block % map.sector_size;
                self.skip = self.copy_block;
                Phase::Copy
            }
            Phase::Copy if map.bytes_with(RegionStatus::NonTrimmed) > 0 => Phase::Trim,
            Phase::Copy | Phase::Trim if map.bytes_with(RegionStatus::NonScraped) > 0 => Phase::Scrape,
            Phase::Copy | Phase::Trim | Phase::Scrape if map.bytes_with(RegionStatus::Bad) > 0 && !map.retry_done => {
                self.retried_until = 0;
                Phase::Retry
            }
            _ => {
                map.retry_done = true;
                return false;
            }
        };
        true
    }

    pub fn observe_ok(&mut self, map: &mut MapFile, request: ReadRequest) -> Result<(), String> {
        map.set(request.offset, request.length, RegionStatus::Finished)?;
        if self.phase == Phase::Copy {
            self.cursor = request.offset + request.length;
            self.skip = self.copy_block;
        }
        Ok(())
    }

    pub fn observe_fail(&mut self, map: &mut MapFile, request: ReadRequest) -> Result<(), String> {
        match self.phase {
            Phase::Copy => {
                map.set(request.offset, request.length, RegionStatus::NonTrimmed)?;
                self.cursor = (request.offset + request.length + self.skip).min(map.capacity_bytes);
                self.skip = (self.skip.saturating_mul(2)).min(self.max_skip);
            }
            Phase::Trim => {
                if self.forward_failed_at.is_none() {
                    self.forward_failed_at = Some(request.offset);
                } else {
                    let start = self.forward_failed_at.unwrap_or(request.offset);
                    let end = request.offset + request.length;
                    if end > start {
                        map.set(start, end - start, RegionStatus::NonScraped)?;
                    }
                    self.forward_failed_at = None;
                }
            }
            Phase::Scrape => {
                map.set(request.offset, request.length, RegionStatus::Bad)?;
            }
            Phase::Retry => {
                self.retried_until = request.offset + request.length;
            }
        }
        Ok(())
    }

    fn next_copy(&mut self, map: &MapFile) -> Option<ReadRequest> {
        let mut cursor = self.cursor;
        while cursor < map.capacity_bytes {
            let index = map.region_index(cursor).ok()?;
            let region = &map.regions[index];
            if region.status == RegionStatus::NonTried {
                let length = self.copy_block.min(region.offset + region.length - cursor);
                return Some(ReadRequest { offset: cursor, length, phase: Phase::Copy });
            }
            cursor = region.offset + region.length;
        }
        None
    }

    fn next_trim(&mut self, map: &mut MapFile) -> Option<ReadRequest> {
        let sector = map.sector_size;
        loop {
            let region = map.regions.iter().find(|region| region.status == RegionStatus::NonTrimmed).cloned();
            let Some(region) = region else {
                return None;
            };
            if let Some(failed) = self.forward_failed_at {
                if failed < region.offset || failed >= region.offset + region.length {
                    self.forward_failed_at = None;
                    continue;
                }
                let last = region.offset + region.length - sector;
                if last <= failed {
                    let _ = map.set(failed, region.offset + region.length - failed, RegionStatus::NonScraped);
                    self.forward_failed_at = None;
                    continue;
                }
                return Some(ReadRequest { offset: last, length: sector, phase: Phase::Trim });
            }
            return Some(ReadRequest { offset: region.offset, length: sector, phase: Phase::Trim });
        }
    }

    fn next_status(&self, map: &MapFile, status: RegionStatus, phase: Phase) -> Option<ReadRequest> {
        let region = map.regions.iter().find(|region| region.status == status)?;
        Some(ReadRequest { offset: region.offset, length: map.sector_size.min(region.length), phase })
    }

    fn next_retry(&self, map: &MapFile) -> Option<ReadRequest> {
        let region = map.regions.iter().find(|region| {
            region.status == RegionStatus::Bad && region.offset >= self.retried_until
        })?;
        Some(ReadRequest { offset: region.offset, length: map.sector_size.min(region.length), phase: Phase::Retry })
    }
}

fn initial_phase(map: &MapFile) -> Phase {
    if map.bytes_with(RegionStatus::NonTried) > 0 {
        Phase::Copy
    } else if map.bytes_with(RegionStatus::NonTrimmed) > 0 {
        Phase::Trim
    } else if map.bytes_with(RegionStatus::NonScraped) > 0 {
        Phase::Scrape
    } else if map.bytes_with(RegionStatus::Bad) > 0 && !map.retry_done {
        Phase::Retry
    } else {
        Phase::Copy
    }
}

impl ZoneMap {
    pub fn new(source_size: u64, zone_count: u32) -> Self {
        let zone_count = zone_count.max(1);
        Self {
            zone_count,
            source_size,
            max_latency_us: vec![0; zone_count as usize],
            error_count: vec![0; zone_count as usize],
        }
    }

    pub fn record(&mut self, offset: u64, latency_us: u64, error: bool) {
        if self.source_size == 0 || self.zone_count == 0 {
            return;
        }
        let index = ((offset as u128 * self.zone_count as u128) / self.source_size as u128) as usize;
        let index = index.min(self.zone_count as usize - 1);
        self.max_latency_us[index] = self.max_latency_us[index].max(latency_us);
        if error {
            self.error_count[index] = self.error_count[index].saturating_add(1);
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn splits_and_merges_ranges() {
        let mut map = MapFile::new("S", "M", 100 * 512, 512).unwrap();
        // Use a size that matches the old interval test by scaling: exercise set() on bytes.
        let mut raw = MapFile {
            version: 1,
            serial: "S".into(),
            model: "M".into(),
            capacity_bytes: 100,
            sector_size: 1,
            regions: vec![Region { offset: 0, length: 100, status: RegionStatus::NonTried }],
            retry_done: false,
        };
        raw.set(20, 10, RegionStatus::Finished).unwrap();
        raw.set(30, 10, RegionStatus::Finished).unwrap();
        assert_eq!(
            raw.regions,
            vec![
                Region { offset: 0, length: 20, status: RegionStatus::NonTried },
                Region { offset: 20, length: 20, status: RegionStatus::Finished },
                Region { offset: 40, length: 60, status: RegionStatus::NonTried },
            ]
        );
        map.validate().unwrap();
    }

    #[test]
    fn copy_failure_skips_ahead_and_trim_keeps_good_edges() {
        let mut map = MapFile::new("SER", "MODEL", 8192, 512).unwrap();
        let mut planner = Planner::start(&map, 1024).unwrap();
        let first = planner.next(&mut map).unwrap();
        assert_eq!(first, ReadRequest { offset: 0, length: 1024, phase: Phase::Copy });
        planner.observe_fail(&mut map, first).unwrap();
        assert_eq!(map.regions[0].status, RegionStatus::NonTrimmed);
        let second = planner.next(&mut map).unwrap();
        assert_eq!(second.offset, 2048);

        let mut trim_map = MapFile::new("SER", "MODEL", 2048, 512).unwrap();
        trim_map.set(0, 2048, RegionStatus::NonTrimmed).unwrap();
        let mut trim = Planner::start(&trim_map, 512).unwrap();
        assert_eq!(trim.phase, Phase::Trim);
        let head = trim.next(&mut trim_map).unwrap();
        trim.observe_fail(&mut trim_map, head).unwrap();
        let tail = trim.next(&mut trim_map).unwrap();
        assert_eq!(tail.offset, 1536);
        trim.observe_ok(&mut trim_map, tail).unwrap();
        assert_eq!(trim_map.bytes_with(RegionStatus::Finished), 512);
        assert!(trim_map.bytes_with(RegionStatus::NonTrimmed) > 0);
    }

    #[test]
    fn rescue_is_complete_only_after_retry() {
        let mut map = MapFile::new("SER", "MODEL", 1024, 512).unwrap();
        map.set(0, 1024, RegionStatus::Finished).unwrap();
        assert!(!map.rescue_finished());
        map.retry_done = true;
        assert!(map.rescue_finished());
    }
}
