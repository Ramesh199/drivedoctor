use crate::model::DriveIdentity;

#[derive(Clone, Copy, Debug)]
pub struct BridgeInfo {
    pub vendor_id: u16,
    pub product_id: u16,
    pub name: &'static str,
    /// SCSI-ATA Translation is good enough for SMART on this chip.
    pub sat_passthrough: bool,
    /// ATA SECURITY ERASE / NVMe Sanitize is known to pass through.
    pub secure_erase_passthrough: bool,
    pub notes: &'static str,
}

/// USB-SATA / USB-NVMe bridges DriveDoctor knows about.
/// Unknown chips are not treated as failures; SMART is simply "try SAT, then give up".
const BRIDGES: &[BridgeInfo] = &[
    BridgeInfo {
        vendor_id: 0x174C,
        product_id: 0x55AA,
        name: "ASMedia ASM105x / ASM1153 family",
        sat_passthrough: true,
        secure_erase_passthrough: false,
        notes: "Very common SATA bridge. SMART usually works with SAT. It often emulates 512-byte logical sectors on a 4Kn drive and does not pass ATA Secure Erase.",
    },
    BridgeInfo {
        vendor_id: 0x174C,
        product_id: 0x1153,
        name: "ASMedia ASM1153",
        sat_passthrough: true,
        secure_erase_passthrough: false,
        notes: "SAT SMART works on most firmware. Secure Erase does not pass through.",
    },
    BridgeInfo {
        vendor_id: 0x152D,
        product_id: 0x0562,
        name: "JMicron JMS567",
        sat_passthrough: true,
        secure_erase_passthrough: false,
        notes: "UASP bridge. Some firmware revisions drop SMART unless the tool uses SAT (-d sat).",
    },
    BridgeInfo {
        vendor_id: 0x152D,
        product_id: 0x0578,
        name: "JMicron JMS578",
        sat_passthrough: true,
        secure_erase_passthrough: false,
        notes: "Common HDD enclosure chip. SAT SMART is usually available. 4Kn translation differs from a bare SATA port on some boards.",
    },
    BridgeInfo {
        vendor_id: 0x152D,
        product_id: 0x0583,
        name: "JMicron JMS583",
        sat_passthrough: false,
        secure_erase_passthrough: false,
        notes: "NVMe enclosure bridge. Use NVMe passthrough, not ATA. Sanitize often does not pass through.",
    },
    BridgeInfo {
        vendor_id: 0x0BDA,
        product_id: 0x9210,
        name: "Realtek RTL9210",
        sat_passthrough: false,
        secure_erase_passthrough: false,
        notes: "NVMe enclosure bridge. SMART needs NVMe passthrough and is firmware-dependent.",
    },
    BridgeInfo {
        vendor_id: 0x0BDA,
        product_id: 0x9201,
        name: "Realtek RTL9201",
        sat_passthrough: true,
        secure_erase_passthrough: false,
        notes: "SATA bridge. SAT support varies by firmware.",
    },
    BridgeInfo {
        vendor_id: 0x2109,
        product_id: 0x0715,
        name: "VIA Labs VL715 / VL711 family",
        sat_passthrough: true,
        secure_erase_passthrough: false,
        notes: "Hub-and-bridge combos often brown out bus-powered 2.5 inch drives. Prefer a powered port.",
    },
    BridgeInfo {
        vendor_id: 0x13FD,
        product_id: 0x3920,
        name: "Initio INIC-3692 family",
        sat_passthrough: false,
        secure_erase_passthrough: false,
        notes: "Older Initio bridges often block SAT. SMART may be unavailable until the drive is in a different dock.",
    },
];

pub fn lookup_bridge(vid: u16, pid: u16) -> Option<&'static BridgeInfo> {
    BRIDGES.iter().find(|bridge| bridge.vendor_id == vid && bridge.product_id == pid)
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct EnclosureGuidance {
    pub hardware_encryption_likely: bool,
    pub message: String,
    pub sector_note: Option<String>,
}

/// Warn before anyone is told to move a drive into a new enclosure.
pub fn enclosure_guidance(identity: &DriveIdentity) -> EnclosureGuidance {
    let product = identity.usb_product.to_lowercase();
    let model = identity.model.to_lowercase();
    let blob = format!("{product} {model}");
    let wd_encrypted = identity.vid == Some(0x1058)
        && (blob.contains("passport") || blob.contains("my book") || blob.contains("easystore"));
    let seagate_encrypted = identity.vid == Some(0x0BC2)
        && (blob.contains("backup plus") || blob.contains("backup+plus") || blob.contains("goflex"));
    let lacie = blob.contains("lacie");
    let encrypted = wd_encrypted || seagate_encrypted || lacie;
    let mut message = String::new();
    if encrypted {
        message.push_str(
            "This enclosure family often encrypts data on the bridge board (the drive itself sees ciphertext). Moving the drive to another dock can make the files unreadable. Keep the original board, or use a lab that can work with that encryption.",
        );
    } else if identity.vid.is_some() {
        message.push_str(
            "If the drive works on SATA but not in this enclosure, the bridge board is the failed part. A plain SATA dock is appropriate only when this enclosure does not do hardware encryption.",
        );
    }
    let sector_note = if identity.logical_sector_size != 0
        && identity.physical_sector_size != 0
        && identity.logical_sector_size != identity.physical_sector_size
    {
        Some(format!(
            "Windows sees {}-byte logical sectors and {}-byte physical sectors. A different bridge may present 4Kn instead of 512e, which makes a healthy partition table look corrupt. Note the sector sizes before swapping enclosures.",
            identity.logical_sector_size, identity.physical_sector_size
        ))
    } else if lookup_bridge(identity.vid.unwrap_or(0), identity.pid.unwrap_or(0))
        .map(|bridge| bridge.notes.contains("4Kn") || bridge.notes.contains("512"))
        .unwrap_or(false)
    {
        Some(
            "This bridge family is known to emulate 512-byte sectors. A bare adapter might expose 4096-byte sectors instead."
                .into(),
        )
    } else {
        None
    };
    EnclosureGuidance {
        hardware_encryption_likely: encrypted,
        message,
        sector_note,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn asmedia_does_not_claim_secure_erase() {
        let bridge = lookup_bridge(0x174C, 0x55AA).unwrap();
        assert!(bridge.sat_passthrough);
        assert!(!bridge.secure_erase_passthrough);
    }

    #[test]
    fn my_passport_warns_about_bridge_encryption() {
        let identity = DriveIdentity {
            disk_number: 1,
            device_path: r"\\.\PhysicalDrive1".into(),
            model: "WDC WD20NMVW".into(),
            serial: "X".into(),
            firmware: String::new(),
            capacity_bytes: 2 << 40,
            logical_sector_size: 512,
            physical_sector_size: 4096,
            bus: "USB".into(),
            is_boot: false,
            is_system: false,
            pnp_id: String::new(),
            vid: Some(0x1058),
            pid: Some(0x25A2),
            usb_product: "My Passport 25A2".into(),
        };
        let guidance = enclosure_guidance(&identity);
        assert!(guidance.hardware_encryption_likely);
        assert!(guidance.sector_note.is_some());
    }
}
