/// Defensive reader for resident NTFS $FILE_NAME attributes.
/// Non-resident names and index records are skipped rather than guessed.

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct NtfsName {
    pub record: u64,
    pub in_use: bool,
    pub directory: bool,
    pub name: String,
}

pub fn parse_mft_records(buffer: &[u8], record_size: usize) -> Result<Vec<NtfsName>, String> {
    if !(512..=4096).contains(&record_size) || !record_size.is_power_of_two() {
        return Err("MFT record size is not believable".into());
    }
    let mut names = Vec::new();
    let max_records = 4096.min(buffer.len() / record_size);
    for index in 0..max_records {
        let start = index * record_size;
        let record = &buffer[start..start + record_size];
        if &record[0..4] != b"FILE" {
            continue;
        }
        let mut fixed = record.to_vec();
        if !apply_update_sequence(&mut fixed) {
            continue;
        }
        let first = u16::from_le_bytes([fixed[0x14], fixed[0x15]]) as usize;
        let flags = u16::from_le_bytes([fixed[0x16], fixed[0x17]]);
        if first >= fixed.len() {
            continue;
        }
        let mut cursor = first;
        for _ in 0..64 {
            if cursor + 16 > fixed.len() {
                break;
            }
            let attr_type = u32::from_le_bytes(fixed[cursor..cursor + 4].try_into().unwrap());
            let attr_len = u32::from_le_bytes(fixed[cursor + 4..cursor + 8].try_into().unwrap()) as usize;
            if attr_type == 0xFFFF_FFFF || attr_len == 0 {
                break;
            }
            if attr_len > fixed.len() - cursor {
                break;
            }
            let non_resident = fixed[cursor + 8] != 0;
            if attr_type == 0x30 && !non_resident {
                let value_len = u32::from_le_bytes(fixed[cursor + 16..cursor + 20].try_into().unwrap()) as usize;
                let value_off = u16::from_le_bytes(fixed[cursor + 20..cursor + 22].try_into().unwrap()) as usize;
                let value_at = cursor + value_off;
                if value_off >= attr_len || value_at + value_len > cursor + attr_len || value_len < 0x42 {
                    cursor += attr_len;
                    continue;
                }
                let value = &fixed[value_at..value_at + value_len];
                let name_len = value[0x40] as usize;
                if name_len == 0 || name_len > 255 || 0x42 + name_len * 2 > value.len() {
                    cursor += attr_len;
                    continue;
                }
                let units: Vec<u16> = value[0x42..0x42 + name_len * 2]
                    .chunks(2)
                    .map(|chunk| u16::from_le_bytes([chunk[0], chunk[1]]))
                    .collect();
                let name = String::from_utf16_lossy(&units);
                if !name.is_empty() {
                    names.push(NtfsName {
                        record: index as u64,
                        in_use: flags & 0x01 != 0,
                        directory: flags & 0x02 != 0,
                        name,
                    });
                }
            }
            cursor += attr_len;
        }
    }
    Ok(names)
}

fn apply_update_sequence(record: &mut [u8]) -> bool {
    if record.len() < 8 {
        return false;
    }
    let usa_off = u16::from_le_bytes([record[4], record[5]]) as usize;
    let usa_words = u16::from_le_bytes([record[6], record[7]]) as usize;
    if usa_words < 2 || usa_off + usa_words * 2 > record.len() {
        return false;
    }
    let sequence = u16::from_le_bytes([record[usa_off], record[usa_off + 1]]);
    let sectors = usa_words - 1;
    if sectors == 0 || record.len() % sectors != 0 {
        return false;
    }
    let sector_size = record.len() / sectors;
    for sector in 0..sectors {
        let at = (sector + 1) * sector_size - 2;
        if at + 2 > record.len() {
            return false;
        }
        let found = u16::from_le_bytes([record[at], record[at + 1]]);
        if found != sequence {
            return false;
        }
        let original_at = usa_off + (sector + 1) * 2;
        record[at] = record[original_at];
        record[at + 1] = record[original_at + 1];
    }
    true
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reads_a_resident_file_name_and_rejects_a_short_buffer() {
        let mut record = vec![0u8; 1024];
        record[0..4].copy_from_slice(b"FILE");
        // Update sequence at offset 0x30, two words: the sequence and one sector fixup.
        record[4] = 0x30;
        record[6] = 2;
        record[0x14] = 0x38; // first attribute
        record[0x16] = 0x01; // in use
        record[0x30] = 0x07; // sequence number
        record[0x32] = 0x00;
        record[0x33] = 0x00;
        record[1022] = 0x07; // sector end matches the sequence
        let attr = 0x38;
        record[attr..attr + 4].copy_from_slice(&0x30u32.to_le_bytes());
        let attr_len = 0x42 + 8 + 2 * 4; // header-ish, we place value at +24
        // Build a resident attribute large enough for the FILE_NAME body.
        let value_off = 24u16;
        let name = "note".encode_utf16().collect::<Vec<u16>>();
        let value_len = 0x42 + name.len() * 2;
        let attr_len = value_off as usize + value_len;
        record[attr + 4..attr + 8].copy_from_slice(&(attr_len as u32).to_le_bytes());
        record[attr + 8] = 0;
        record[attr + 16..attr + 20].copy_from_slice(&(value_len as u32).to_le_bytes());
        record[attr + 20..attr + 22].copy_from_slice(&value_off.to_le_bytes());
        let value = attr + value_off as usize;
        record[value + 0x40] = name.len() as u8;
        for (index, unit) in name.iter().enumerate() {
            record[value + 0x42 + index * 2..value + 0x44 + index * 2].copy_from_slice(&unit.to_le_bytes());
        }
        let names = parse_mft_records(&record, 1024).unwrap();
        assert_eq!(names.len(), 1);
        assert_eq!(names[0].name, "note");
        assert!(names[0].in_use);
        assert!(parse_mft_records(&record[..100], 1024).is_err());
    }
}
