use serde::{Deserialize, Serialize};

/// Read-only commands the advanced console is allowed to ask for.
/// The platform maps these onto smartctl. Arbitrary CDBs are not accepted.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AllowedAta {
    IdentifyDevice,
    SmartReadData,
    SmartReturnStatus,
    SmartLogDirectory,
}

impl AllowedAta {
    pub fn all() -> &'static [AllowedAta] {
        &[
            Self::IdentifyDevice,
            Self::SmartReadData,
            Self::SmartReturnStatus,
            Self::SmartLogDirectory,
        ]
    }

    pub fn label(self) -> &'static str {
        match self {
            Self::IdentifyDevice => "IDENTIFY DEVICE",
            Self::SmartReadData => "SMART READ DATA",
            Self::SmartReturnStatus => "SMART RETURN STATUS",
            Self::SmartLogDirectory => "READ SMART LOG DIRECTORY",
        }
    }

    pub fn smartctl_args(self) -> &'static [&'static str] {
        match self {
            Self::IdentifyDevice => &["-i", "-j"],
            Self::SmartReadData => &["-A", "-j"],
            Self::SmartReturnStatus => &["-H", "-j"],
            Self::SmartLogDirectory => &["-l", "directory", "-j"],
        }
    }
}

pub fn parse_allowed(name: &str) -> Option<AllowedAta> {
    AllowedAta::all().iter().copied().find(|command| command.label().eq_ignore_ascii_case(name) || command_name(*command) == name)
}

fn command_name(command: AllowedAta) -> &'static str {
    match command {
        AllowedAta::IdentifyDevice => "identify_device",
        AllowedAta::SmartReadData => "smart_read_data",
        AllowedAta::SmartReturnStatus => "smart_return_status",
        AllowedAta::SmartLogDirectory => "smart_log_directory",
    }
}
