use serde::{Deserialize, Serialize};

use crate::error::AuthError;

/// How an operation treats user data. Shown as a badge in the wizard.
#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RiskLevel {
    /// No user-sector or filesystem-metadata writes.
    Safe,
    /// Rewrites small structures (partition table, boot sector) and keeps file data.
    Metadata,
    /// Rewrites only sectors already unreadable. Files that used them are lost.
    TargetedLoss,
    /// Erases or reformats the whole device.
    DestroysAll,
}

impl RiskLevel {
    pub fn label(self) -> &'static str {
        match self {
            Self::Safe => "Safe",
            Self::Metadata => "Writes metadata",
            Self::TargetedLoss => "Destroys data in affected sectors",
            Self::DestroysAll => "Destroys all data",
        }
    }

    pub fn writes_disk(self) -> bool {
        !matches!(self, Self::Safe)
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Layer {
    Connection,
    OsDriver,
    Device,
    Partition,
    FileSystem,
    Media,
}

impl Layer {
    pub fn title(self) -> &'static str {
        match self {
            Self::Connection => "Connection and power",
            Self::OsDriver => "Operating system and drivers",
            Self::Device => "Drive hardware",
            Self::Partition => "Partition table",
            Self::FileSystem => "File system",
            Self::Media => "Media (sectors)",
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Severity {
    Info,
    Warning,
    Critical,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Repairability {
    NoRepairNeeded,
    Repairable,
    RepairableWithDataLoss,
    HardwareFault,
}

impl Repairability {
    pub fn label(self) -> &'static str {
        match self {
            Self::NoRepairNeeded => "No repair needed",
            Self::Repairable => "Repairable",
            Self::RepairableWithDataLoss => "Repairable with data loss",
            Self::HardwareFault => "Hardware fault, not repairable by software",
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Symptom {
    Clicking,
    Beeping,
    Buzzing,
    NotSpinning,
    VerySlow,
    Intermittent,
    Dropped,
    Liquid,
    BurntSmell,
    NotDetected,
    AsksToFormat,
    ZeroCapacity,
}

impl Symptom {
    pub fn label(self) -> &'static str {
        match self {
            Self::Clicking => "Clicking",
            Self::Beeping => "Beeping",
            Self::Buzzing => "Buzzing or grinding",
            Self::NotSpinning => "Not spinning",
            Self::VerySlow => "Very slow",
            Self::Intermittent => "Works, then disappears",
            Self::Dropped => "Was dropped or knocked",
            Self::Liquid => "Liquid exposure",
            Self::BurntSmell => "Burnt smell",
            Self::NotDetected => "Sometimes not detected",
            Self::AsksToFormat => "Computer asks to format it",
            Self::ZeroCapacity => "Shows 0 bytes or a tiny size",
        }
    }

    pub fn all() -> &'static [Symptom] {
        &[
            Self::Clicking,
            Self::Beeping,
            Self::Buzzing,
            Self::NotSpinning,
            Self::VerySlow,
            Self::Intermittent,
            Self::Dropped,
            Self::Liquid,
            Self::BurntSmell,
            Self::NotDetected,
            Self::AsksToFormat,
            Self::ZeroCapacity,
        ]
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum HardwareFaultKind {
    HeadCrash,
    SeizedMotor,
    PcbFailure,
    FirmwareCorruption,
    LiquidDamage,
    FireOrBurn,
    DeadUsbBridge,
    SsdController,
}

impl HardwareFaultKind {
    pub fn title(self) -> &'static str {
        match self {
            Self::HeadCrash => "Read/write head failure",
            Self::SeizedMotor => "Spindle motor not spinning",
            Self::PcbFailure => "Circuit board failure",
            Self::FirmwareCorruption => "Drive firmware failure",
            Self::LiquidDamage => "Liquid damage",
            Self::FireOrBurn => "Burn or short-circuit damage",
            Self::DeadUsbBridge => "USB enclosure bridge failed",
            Self::SsdController => "SSD controller failure",
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct HardwareFault {
    pub kind: HardwareFaultKind,
    pub explanation: String,
    pub next_steps: Vec<String>,
    pub power_down: bool,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct DriveIdentity {
    pub disk_number: u32,
    pub device_path: String,
    pub model: String,
    pub serial: String,
    pub firmware: String,
    pub capacity_bytes: u64,
    pub logical_sector_size: u32,
    pub physical_sector_size: u32,
    pub bus: String,
    pub is_boot: bool,
    pub is_system: bool,
    pub pnp_id: String,
    pub vid: Option<u16>,
    pub pid: Option<u16>,
    pub usb_product: String,
}

impl DriveIdentity {
    pub fn is_system_disk(&self) -> bool {
        self.is_boot || self.is_system
    }

    pub fn has_serial(&self) -> bool {
        !normalize_serial(&self.serial).is_empty()
    }

    /// Bound a job to the drive itself, not to a Windows disk number that can change on replug.
    pub fn lock(&self) -> Result<IdentityLock, AuthError> {
        if !self.has_serial() {
            return Err(AuthError::SerialRequired);
        }
        Ok(IdentityLock {
            serial: normalize_serial(&self.serial),
            model: normalize_model(&self.model),
            capacity_bytes: self.capacity_bytes,
        })
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct IdentityLock {
    pub serial: String,
    pub model: String,
    pub capacity_bytes: u64,
}

impl IdentityLock {
    pub fn matches(&self, current: &DriveIdentity) -> Result<(), AuthError> {
        if self.serial != normalize_serial(&current.serial)
            || self.model != normalize_model(&current.model)
            || self.capacity_bytes != current.capacity_bytes
        {
            Err(AuthError::IdentityChanged)
        } else {
            Ok(())
        }
    }
}

pub fn normalize_serial(value: &str) -> String {
    value
        .chars()
        .filter(|c| !c.is_whitespace())
        .flat_map(|c| c.to_uppercase())
        .collect()
}

pub fn normalize_model(value: &str) -> String {
    let collapsed: String = value.split_whitespace().collect::<Vec<_>>().join(" ");
    collapsed.to_uppercase()
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ActionId {
    ProtectData,
    BringOnline,
    ClearReadOnly,
    ClearRegistryWriteProtect,
    AssignDriveLetter,
    RescanDevices,
    DisableSelectiveSuspend,
    UnlockBitLocker,
    RestoreGpt,
    FixProtectiveMbr,
    ScanLostPartitions,
    RebuildMbr,
    RestoreNtfsBoot,
    RestoreExfatBoot,
    ChkdskDryRun,
    ChkdskFix,
    RemapPendingSectors,
    MarkBadClusters,
    ZeroFill,
    SecureErase,
    RemoveHpa,
    VendorFirmwareGuide,
    CreatePartitionAndFormat,
    RestoreFromImage,
    PowerDown,
    ProfessionalHandoff,
    SmartShortTest,
    SurfaceScan,
    ShowGuidance,
}

impl ActionId {
    pub fn as_str(self) -> &'static str {
        match self {
            Self::ProtectData => "protect_data",
            Self::BringOnline => "bring_online",
            Self::ClearReadOnly => "clear_read_only",
            Self::ClearRegistryWriteProtect => "clear_registry_write_protect",
            Self::AssignDriveLetter => "assign_drive_letter",
            Self::RescanDevices => "rescan_devices",
            Self::DisableSelectiveSuspend => "disable_selective_suspend",
            Self::UnlockBitLocker => "unlock_bitlocker",
            Self::RestoreGpt => "restore_gpt",
            Self::FixProtectiveMbr => "fix_protective_mbr",
            Self::ScanLostPartitions => "scan_lost_partitions",
            Self::RebuildMbr => "rebuild_mbr",
            Self::RestoreNtfsBoot => "restore_ntfs_boot",
            Self::RestoreExfatBoot => "restore_exfat_boot",
            Self::ChkdskDryRun => "chkdsk_dry_run",
            Self::ChkdskFix => "chkdsk_fix",
            Self::RemapPendingSectors => "remap_pending_sectors",
            Self::MarkBadClusters => "mark_bad_clusters",
            Self::ZeroFill => "zero_fill",
            Self::SecureErase => "secure_erase",
            Self::RemoveHpa => "remove_hpa",
            Self::VendorFirmwareGuide => "vendor_firmware_guide",
            Self::CreatePartitionAndFormat => "create_partition_and_format",
            Self::RestoreFromImage => "restore_from_image",
            Self::PowerDown => "power_down",
            Self::ProfessionalHandoff => "professional_handoff",
            Self::SmartShortTest => "smart_short_test",
            Self::SurfaceScan => "surface_scan",
            Self::ShowGuidance => "show_guidance",
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct PlannedAction {
    pub id: ActionId,
    pub level: u8,
    pub title: String,
    pub summary: String,
    pub risk: RiskLevel,
    pub data_effect: String,
    pub estimated_time: String,
    /// When false, the wizard lists the step under "not recommended yet".
    pub recommended: bool,
    pub requires_gate: bool,
    pub requires_typed_serial: bool,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct LayerFinding {
    pub layer: Layer,
    pub ok: bool,
    /// True when the layer could not be read. Not treated as damage.
    pub inconclusive: bool,
    pub severity: Severity,
    pub summary: String,
    pub detail: String,
}

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct DiagnosisReport {
    pub sample: bool,
    pub identity: DriveIdentity,
    pub findings: Vec<LayerFinding>,
    pub failed_layers: Vec<Layer>,
    pub root_cause: String,
    pub severity: Severity,
    pub repairability: Repairability,
    pub hardware_fault: Option<HardwareFault>,
    pub warnings: Vec<String>,
    pub plan: Vec<PlannedAction>,
    pub recommended: Option<ActionId>,
    pub current_trust: crate::trust::TrustScore,
}

/// Proof that a long operation may write this drive.
///
/// Only [`crate::safety::authorize`] can build one. Sector writers require it.
#[derive(Clone, Debug)]
pub struct WritePermit {
    action: ActionId,
    serial: String,
    risk: RiskLevel,
}

impl WritePermit {
    pub(crate) fn new(action: ActionId, serial: String, risk: RiskLevel) -> Self {
        Self { action, serial, risk }
    }

    pub fn action(&self) -> ActionId {
        self.action
    }

    pub fn serial(&self) -> &str {
        &self.serial
    }

    pub fn risk(&self) -> RiskLevel {
        self.risk
    }
}
