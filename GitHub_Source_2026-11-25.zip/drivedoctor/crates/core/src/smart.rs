use serde::{Deserialize, Serialize};
use serde_json::Value;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum SmartVerdict {
    Healthy,
    Warning,
    Failing,
    Unknown,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct SmartAttribute {
    pub id: u8,
    pub name: String,
    pub current: u8,
    pub worst: u8,
    pub threshold: u8,
    pub raw: u64,
    pub prefail: bool,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct NvmeSmart {
    pub critical_warning: u8,
    pub temperature_c: Option<i64>,
    pub available_spare: u8,
    pub available_spare_threshold: u8,
    pub percentage_used: u8,
    pub media_errors: u64,
    pub power_on_hours: Option<u64>,
}

#[derive(Clone, Debug, Default, PartialEq, Eq, Serialize, Deserialize)]
pub struct SmartDump {
    pub attributes: Vec<SmartAttribute>,
    pub passed: Option<bool>,
    pub nvme: Option<NvmeSmart>,
    pub model: Option<String>,
    pub serial: Option<String>,
    /// Larger than the OS-reported size when an HPA/DCO limit is visible.
    pub native_capacity_bytes: Option<u64>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct SmartAssessment {
    pub verdict: SmartVerdict,
    pub pending: u64,
    pub reallocated: u64,
    pub uncorrectable: u64,
    pub reported_uncorrectable: u64,
    pub spin_retry: u64,
    pub command_timeout: u64,
    pub udma_crc: u64,
    pub temperature_c: Option<i64>,
    pub power_on_hours: Option<u64>,
    pub load_cycles: Option<u64>,
    pub nvme_critical_warning: u8,
    pub nvme_media_errors: u64,
    pub nvme_percentage_used: u8,
    pub nvme_available_spare: u8,
    pub lines: Vec<String>,
    pub failing: bool,
    pub hpa_suspected: bool,
}

impl SmartAssessment {
    pub fn unknown() -> Self {
        Self {
            verdict: SmartVerdict::Unknown,
            pending: 0,
            reallocated: 0,
            uncorrectable: 0,
            reported_uncorrectable: 0,
            spin_retry: 0,
            command_timeout: 0,
            udma_crc: 0,
            temperature_c: None,
            power_on_hours: None,
            load_cycles: None,
            nvme_critical_warning: 0,
            nvme_media_errors: 0,
            nvme_percentage_used: 0,
            nvme_available_spare: 100,
            lines: vec!["SMART was not readable. Install smartmontools or connect the drive so ATA/NVMe passthrough works.".into()],
            failing: false,
            hpa_suspected: false,
        }
    }
}

pub fn attribute_name(id: u8) -> &'static str {
    match id {
        1 => "Read error rate",
        5 => "Reallocated sectors",
        9 => "Power-on hours",
        10 => "Spin retry count",
        12 => "Power cycle count",
        187 => "Reported uncorrectable",
        188 => "Command timeout",
        190 | 194 => "Temperature",
        193 => "Load cycle count",
        196 => "Reallocation events",
        197 => "Current pending sectors",
        198 => "Offline uncorrectable",
        199 => "UDMA CRC errors",
        _ => "Attribute",
    }
}

fn raw_of(dump: &SmartDump, id: u8) -> u64 {
    dump.attributes.iter().find(|a| a.id == id).map(|a| a.raw).unwrap_or(0)
}

pub fn assess_smart(dump: &SmartDump, reported_capacity: u64) -> SmartAssessment {
    if dump.attributes.is_empty() && dump.nvme.is_none() && dump.passed.is_none() {
        return SmartAssessment::unknown();
    }
    let mut lines = Vec::new();
    let pending = raw_of(dump, 197);
    let reallocated = raw_of(dump, 5);
    let uncorrectable = raw_of(dump, 198);
    let reported_unc = raw_of(dump, 187);
    let spin_retry = raw_of(dump, 10);
    let timeout = raw_of(dump, 188);
    let crc = raw_of(dump, 199);
    let hours = dump.attributes.iter().find(|a| a.id == 9).map(|a| a.raw);
    let load_cycles = dump.attributes.iter().find(|a| a.id == 193).map(|a| a.raw);
    let temperature_c = dump
        .attributes
        .iter()
        .find(|a| a.id == 194 || a.id == 190)
        .map(|a| a.raw as i64)
        .or_else(|| dump.nvme.as_ref().and_then(|n| n.temperature_c));

    let mut failing = dump.passed == Some(false);
    if pending > 0 {
        failing = true;
        lines.push(format!(
            "{pending} sector(s) are waiting to be remapped (SMART 197). Data in those sectors may already be unreadable."
        ));
    }
    if uncorrectable > 0 {
        failing = true;
        lines.push(format!("{uncorrectable} offline uncorrectable sector(s) (SMART 198)."));
    }
    if reported_unc > 0 {
        lines.push(format!("{reported_unc} reported uncorrectable error(s) (SMART 187)."));
    }
    if reallocated > 0 {
        lines.push(format!(
            "{reallocated} sector(s) have already been replaced from the spare pool (SMART 5). This does not restore the old data."
        ));
    }
    if spin_retry > 0 {
        failing = true;
        lines.push(format!(
            "The motor needed {spin_retry} spin retry(s) (SMART 10). That points to power or mechanical trouble."
        ));
    }
    if timeout > 0 {
        lines.push(format!("{timeout} command timeout(s) (SMART 188)."));
    }
    if crc > 0 {
        lines.push(format!(
            "{crc} interface CRC error(s) (SMART 199). This is usually the cable, port, or USB bridge, not the platters."
        ));
    }
    if let Some(temp) = temperature_c {
        if temp >= 55 {
            lines.push(format!("Temperature is {temp}°C. Cool the drive before any long operation."));
        }
    }
    for attr in &dump.attributes {
        if attr.prefail && attr.threshold > 0 && attr.current <= attr.threshold {
            failing = true;
            lines.push(format!(
                "Attribute {} ({}) is at or below its failure threshold.",
                attr.id,
                if attr.name.is_empty() { attribute_name(attr.id) } else { attr.name.as_str() }
            ));
        }
    }

    let mut nvme_critical = 0;
    let mut nvme_media = 0;
    let mut nvme_used = 0;
    let mut nvme_spare = 100;
    if let Some(nvme) = &dump.nvme {
        nvme_critical = nvme.critical_warning;
        nvme_media = nvme.media_errors;
        nvme_used = nvme.percentage_used;
        nvme_spare = nvme.available_spare;
        if nvme.critical_warning != 0 {
            failing = true;
            lines.push(format!("NVMe critical warning flags are 0x{nvme_critical:02X}."));
        }
        if nvme.media_errors > 0 {
            failing = true;
            lines.push(format!("NVMe media errors: {nvme_media}."));
        }
        if nvme.available_spare <= nvme.available_spare_threshold {
            failing = true;
            lines.push("NVMe available spare space is at or below its threshold.".into());
        } else if nvme.percentage_used >= 90 {
            lines.push(format!("NVMe media is {nvme_used}% used."));
        }
    }

    let hpa = dump
        .native_capacity_bytes
        .map(|native| reported_capacity > 0 && native > reported_capacity.saturating_add(1024 * 1024))
        .unwrap_or(false);
    if hpa {
        lines.push(
            "The drive reports a native capacity larger than the size Windows sees. A Host Protected Area or DCO limit may be hiding space."
                .into(),
        );
    }

    let warning = !failing
        && (reallocated > 0 || crc > 0 || timeout > 0 || reported_unc > 0 || temperature_c.unwrap_or(0) >= 55 || nvme_used >= 90);
    let verdict = if failing {
        SmartVerdict::Failing
    } else if warning {
        SmartVerdict::Warning
    } else {
        SmartVerdict::Healthy
    };
    if lines.is_empty() {
        lines.push("SMART attributes that DriveDoctor watches are in the normal range.".into());
    }

    SmartAssessment {
        verdict,
        pending,
        reallocated,
        uncorrectable,
        reported_uncorrectable: reported_unc,
        spin_retry,
        command_timeout: timeout,
        udma_crc: crc,
        temperature_c,
        power_on_hours: hours.or_else(|| dump.nvme.as_ref().and_then(|n| n.power_on_hours)),
        load_cycles,
        nvme_critical_warning: nvme_critical,
        nvme_media_errors: nvme_media,
        nvme_percentage_used: nvme_used,
        nvme_available_spare: nvme_spare,
        lines,
        failing,
        hpa_suspected: hpa,
    }
}

/// Parse `smartctl -j` output. Missing data becomes an empty dump, not an error,
/// so a partial report can still be assessed.
pub fn parse_smartctl_json(text: &str) -> Result<SmartDump, String> {
    let value: Value = serde_json::from_str(text).map_err(|err| format!("smartctl JSON: {err}"))?;
    let mut dump = SmartDump {
        model: value.get("model_name").and_then(|v| v.as_str()).map(str::to_owned),
        serial: value.get("serial_number").and_then(|v| v.as_str()).map(str::to_owned),
        passed: value.pointer("/smart_status/passed").and_then(|v| v.as_bool()),
        native_capacity_bytes: None,
        ..SmartDump::default()
    };
    if let Some(bytes) = value.pointer("/user_capacity/bytes").and_then(|v| v.as_u64()) {
        if let Some(native) = value.get("nvme_total_capacity").and_then(|v| v.as_u64()) {
            if native > bytes {
                dump.native_capacity_bytes = Some(native);
            }
        }
    }
    if let Some(table) = value.pointer("/ata_smart_attributes/table").and_then(|v| v.as_array()) {
        for item in table {
            let id = item.get("id").and_then(|v| v.as_u64()).unwrap_or(0) as u8;
            if id == 0 {
                continue;
            }
            let raw = item.pointer("/raw/value").and_then(|v| v.as_u64()).unwrap_or(0);
            let flags = item.get("flags").cloned().unwrap_or(Value::Null);
            let prefail = flags
                .pointer("/prefailure")
                .and_then(|v| v.as_bool())
                .or_else(|| item.pointer("/flags/string").and_then(|v| v.as_str()).map(|s| s.contains('P')))
                .unwrap_or(false);
            dump.attributes.push(SmartAttribute {
                id,
                name: item.get("name").and_then(|v| v.as_str()).unwrap_or("").to_owned(),
                current: item.get("value").and_then(|v| v.as_u64()).unwrap_or(0) as u8,
                worst: item.get("worst").and_then(|v| v.as_u64()).unwrap_or(0) as u8,
                threshold: item.get("thresh").and_then(|v| v.as_u64()).unwrap_or(0) as u8,
                raw,
                prefail,
            });
        }
    }
    if let Some(nvme) = value.get("nvme_smart_health_information_log") {
        dump.nvme = Some(NvmeSmart {
            critical_warning: nvme.get("critical_warning").and_then(|v| v.as_u64()).unwrap_or(0) as u8,
            temperature_c: nvme.get("temperature").and_then(|v| v.as_i64()),
            available_spare: nvme.get("available_spare").and_then(|v| v.as_u64()).unwrap_or(100) as u8,
            available_spare_threshold: nvme
                .get("available_spare_threshold")
                .and_then(|v| v.as_u64())
                .unwrap_or(10) as u8,
            percentage_used: nvme.get("percentage_used").and_then(|v| v.as_u64()).unwrap_or(0) as u8,
            media_errors: nvme.get("media_errors").and_then(|v| v.as_u64()).unwrap_or(0),
            power_on_hours: nvme.get("power_on_hours").and_then(|v| v.as_u64()),
        });
        if dump.passed.is_none() {
            dump.passed = Some(dump.nvme.as_ref().map(|n| n.critical_warning == 0).unwrap_or(true));
        }
    }
    Ok(dump)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn pending_sectors_fail_the_drive() {
        let dump = SmartDump {
            passed: Some(true),
            attributes: vec![SmartAttribute {
                id: 197,
                name: "Current_Pending_Sector".into(),
                current: 100,
                worst: 100,
                threshold: 0,
                raw: 3,
                prefail: false,
            }],
            ..SmartDump::default()
        };
        let assessed = assess_smart(&dump, 1_000);
        assert_eq!(assessed.verdict, SmartVerdict::Failing);
        assert_eq!(assessed.pending, 3);
    }

    #[test]
    fn parses_smartctl_attribute_table() {
        let json = r#"{
            "model_name": "ST2000DM001",
            "serial_number": "Z123",
            "smart_status": {"passed": true},
            "ata_smart_attributes": {"table": [
                {"id": 5, "name": "Reallocated_Sector_Ct", "value": 100, "worst": 100, "thresh": 36, "raw": {"value": 0}, "flags": {"prefailure": true}},
                {"id": 199, "name": "UDMA_CRC_Error_Count", "value": 200, "worst": 200, "thresh": 0, "raw": {"value": 12}}
            ]}
        }"#;
        let dump = parse_smartctl_json(json).unwrap();
        let assessed = assess_smart(&dump, 2_000_000_000_000);
        assert_eq!(assessed.verdict, SmartVerdict::Warning);
        assert_eq!(assessed.udma_crc, 12);
        assert!(!assessed.failing);
    }
}
