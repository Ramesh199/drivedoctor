use serde::{Deserialize, Serialize};

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum FsKind {
    Ntfs,
    ExFat,
    Fat32,
    Fat,
    Ext4,
    HfsPlus,
    Apfs,
    Unknown,
}

impl FsKind {
    pub fn label(self) -> &'static str {
        match self {
            Self::Ntfs => "NTFS",
            Self::ExFat => "exFAT",
            Self::Fat32 => "FAT32",
            Self::Fat => "FAT",
            Self::Ext4 => "ext4",
            Self::HfsPlus => "HFS+",
            Self::Apfs => "APFS",
            Self::Unknown => "Unknown",
        }
    }
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum FsClass {
    Healthy,
    Dirty,
    Corrupted,
    Raw,
    Unknown,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct VolumeAssessment {
    pub index: u32,
    pub kind: FsKind,
    pub class: FsClass,
    pub detail: String,
    pub can_restore_ntfs_boot: bool,
    pub can_restore_exfat_boot: bool,
    pub drive_letter: Option<String>,
    pub start_lba: u64,
}

#[derive(Clone, Debug, Default, Serialize, Deserialize)]
pub struct VolumeProbe {
    pub index: u32,
    pub start_lba: u64,
    pub length_bytes: u64,
    pub drive_letter: Option<String>,
    pub bitlocker_locked: bool,
    pub windows_filesystem: String,
    pub windows_health: String,
    /// First 8 sectors is enough for NTFS, FAT, exFAT, APFS, HFS+, and ext4 magics.
    pub head: Option<Vec<u8>>,
    pub backup_boot: Option<Vec<u8>>,
    /// Twelve exFAT sectors (11-sector boot region plus the checksum sector).
    pub exfat_boot_region: Option<Vec<u8>>,
}

pub fn assess_volume(volume: &VolumeProbe) -> VolumeAssessment {
    if volume.bitlocker_locked {
        return VolumeAssessment {
            index: volume.index,
            kind: FsKind::Unknown,
            class: FsClass::Unknown,
            detail: format!(
                "Volume {} is locked by BitLocker. Unlock it before treating the file system as corrupt.",
                letter(volume)
            ),
            can_restore_ntfs_boot: false,
            can_restore_exfat_boot: false,
            drive_letter: volume.drive_letter.clone(),
            start_lba: volume.start_lba,
        };
    }
    let Some(head) = volume.head.as_deref() else {
        return VolumeAssessment {
            index: volume.index,
            kind: kind_from_windows(&volume.windows_filesystem),
            class: FsClass::Unknown,
            detail: "The boot sector was not read, so the file system was not judged.".into(),
            can_restore_ntfs_boot: false,
            can_restore_exfat_boot: false,
            drive_letter: volume.drive_letter.clone(),
            start_lba: volume.start_lba,
        };
    };
    if head.iter().all(|byte| *byte == 0) {
        return VolumeAssessment {
            index: volume.index,
            kind: FsKind::Unknown,
            class: FsClass::Raw,
            detail: "The first sectors are zeros. Windows will ask to format this volume. A backup boot sector may still exist.".into(),
            can_restore_ntfs_boot: volume.backup_boot.as_deref().map(ntfs_boot_valid).unwrap_or(false),
            can_restore_exfat_boot: false,
            drive_letter: volume.drive_letter.clone(),
            start_lba: volume.start_lba,
        };
    }

    if ntfs_boot_valid(head) {
        return assess_ntfs(volume, head);
    }
    if exfat_boot_valid(head) {
        return assess_exfat(volume, head);
    }
    if fat32_boot_valid(head) {
        return VolumeAssessment {
            index: volume.index,
            kind: FsKind::Fat32,
            class: FsClass::Healthy,
            detail: "FAT32 boot sector structure looks consistent. FAT1/FAT2 were not compared in this pass.".into(),
            can_restore_ntfs_boot: false,
            can_restore_exfat_boot: false,
            drive_letter: volume.drive_letter.clone(),
            start_lba: volume.start_lba,
        };
    }
    if let Some(kind) = other_magic(head) {
        let native = match kind {
            FsKind::Ext4 => "Journal replay is a later milestone. After imaging, run e2fsck on a Linux system.",
            FsKind::HfsPlus => "HFS+ catalog repair is a later milestone. After imaging, use macOS Disk Utility or fsck_hfs.",
            FsKind::Apfs => "APFS container repair is a later milestone. After imaging, use macOS Disk Utility.",
            _ => "No in-app repair is available for this file system yet.",
        };
        return VolumeAssessment {
            index: volume.index,
            kind,
            class: FsClass::Healthy,
            detail: format!("{} signature found. {native}", kind.label()),
            can_restore_ntfs_boot: false,
            can_restore_exfat_boot: false,
            drive_letter: volume.drive_letter.clone(),
            start_lba: volume.start_lba,
        };
    }
    if head.len() >= 512 && &head[3..11] == b"NTFS    " {
        return VolumeAssessment {
            index: volume.index,
            kind: FsKind::Ntfs,
            class: FsClass::Corrupted,
            detail: "The sector claims to be NTFS but its geometry or signature is not valid.".into(),
            can_restore_ntfs_boot: volume.backup_boot.as_deref().map(ntfs_boot_valid).unwrap_or(false),
            can_restore_exfat_boot: false,
            drive_letter: volume.drive_letter.clone(),
            start_lba: volume.start_lba,
        };
    }
    VolumeAssessment {
        index: volume.index,
        kind: FsKind::Unknown,
        class: FsClass::Raw,
        detail: "No NTFS, exFAT, FAT32, ext4, HFS+, or APFS signature was found in the first sectors.".into(),
        can_restore_ntfs_boot: volume.backup_boot.as_deref().map(ntfs_boot_valid).unwrap_or(false),
        can_restore_exfat_boot: false,
        drive_letter: volume.drive_letter.clone(),
        start_lba: volume.start_lba,
    }
}

fn assess_ntfs(volume: &VolumeProbe, head: &[u8]) -> VolumeAssessment {
    match volume.backup_boot.as_deref() {
        Some(backup) if ntfs_boot_valid(backup) && backup[..512] == head[..512] => VolumeAssessment {
            index: volume.index,
            kind: FsKind::Ntfs,
            class: FsClass::Healthy,
            detail: "NTFS boot sector matches its backup copy. The $Volume dirty flag lives in the MFT and was not read.".into(),
            can_restore_ntfs_boot: false,
            can_restore_exfat_boot: false,
            drive_letter: volume.drive_letter.clone(),
            start_lba: volume.start_lba,
        },
        Some(backup) if ntfs_boot_valid(backup) && backup[..512] != head[..512] => VolumeAssessment {
            index: volume.index,
            kind: FsKind::Ntfs,
            class: FsClass::Corrupted,
            detail: "NTFS boot sector and its backup both parse, but they differ. DriveDoctor will not guess which one is current.".into(),
            can_restore_ntfs_boot: false,
            can_restore_exfat_boot: false,
            drive_letter: volume.drive_letter.clone(),
            start_lba: volume.start_lba,
        },
        Some(backup) if !ntfs_boot_valid(backup) => VolumeAssessment {
            index: volume.index,
            kind: FsKind::Ntfs,
            class: FsClass::Healthy,
            detail: "NTFS boot sector looks valid. Its backup copy does not, so a metadata repair can rewrite the backup from the primary.".into(),
            can_restore_ntfs_boot: false,
            can_restore_exfat_boot: false,
            drive_letter: volume.drive_letter.clone(),
            start_lba: volume.start_lba,
        },
        _ => VolumeAssessment {
            index: volume.index,
            kind: FsKind::Ntfs,
            class: FsClass::Healthy,
            detail: "NTFS boot sector looks valid. The backup copy was not read.".into(),
            can_restore_ntfs_boot: false,
            can_restore_exfat_boot: false,
            drive_letter: volume.drive_letter.clone(),
            start_lba: volume.start_lba,
        },
    }
}

fn assess_exfat(volume: &VolumeProbe, head: &[u8]) -> VolumeAssessment {
    let dirty = volume_flags(head) & 0x0002 != 0;
    let mut class = if dirty { FsClass::Dirty } else { FsClass::Healthy };
    let mut detail = if dirty {
        "exFAT volume dirty flag is set. Clear it only after a successful check.".into()
    } else {
        "exFAT boot sector structure looks consistent.".into()
    };
    let mut can_restore = false;
    if let Some(region) = volume.exfat_boot_region.as_deref() {
        if let Some(expected) = exfat_boot_checksum(region) {
            let stored = stored_exfat_checksum(region);
            if stored != Some(expected) {
                class = FsClass::Corrupted;
                detail = "exFAT boot-region checksum does not match. It can be recomputed from the boot sectors.".into();
                can_restore = true;
            }
        }
    }
    VolumeAssessment {
        index: volume.index,
        kind: FsKind::ExFat,
        class,
        detail,
        can_restore_ntfs_boot: false,
        can_restore_exfat_boot: can_restore,
        drive_letter: volume.drive_letter.clone(),
        start_lba: volume.start_lba,
    }
}

pub fn ntfs_boot_valid(sector: &[u8]) -> bool {
    if sector.len() < 512 || &sector[3..11] != b"NTFS    " || sector[510] != 0x55 || sector[511] != 0xAA {
        return false;
    }
    let bps = u16::from_le_bytes([sector[0x0B], sector[0x0C]]);
    let spc = sector[0x0D];
    let total = u64::from_le_bytes(sector[0x28..0x30].try_into().unwrap());
    let mft = u64::from_le_bytes(sector[0x30..0x38].try_into().unwrap());
    let mirror = u64::from_le_bytes(sector[0x38..0x40].try_into().unwrap());
    matches!(bps, 512 | 1024 | 2048 | 4096)
        && spc.is_power_of_two()
        && spc != 0
        && total > 16
        && mft > 0
        && mirror > 0
        && mft * u64::from(spc) < total
}

pub fn synthesize_ntfs_boot(total_sectors: u64) -> Vec<u8> {
    let mut sector = vec![0u8; 512];
    sector[0] = 0xEB;
    sector[1] = 0x52;
    sector[2] = 0x90;
    sector[3..11].copy_from_slice(b"NTFS    ");
    sector[0x0B] = 0x00;
    sector[0x0C] = 0x02;
    sector[0x0D] = 8;
    sector[0x15] = 0xF8;
    sector[0x28..0x30].copy_from_slice(&total_sectors.to_le_bytes());
    sector[0x30..0x38].copy_from_slice(&4u64.to_le_bytes());
    let mirror = (total_sectors / 2).max(8);
    sector[0x38..0x40].copy_from_slice(&mirror.to_le_bytes());
    sector[510] = 0x55;
    sector[511] = 0xAA;
    sector
}

pub fn ntfs_boot_restore<'a>(primary: &'a [u8], backup: &'a [u8]) -> Option<&'a [u8]> {
    if !ntfs_boot_valid(primary) && ntfs_boot_valid(backup) {
        Some(&backup[..512])
    } else {
        None
    }
}

fn exfat_boot_valid(sector: &[u8]) -> bool {
    sector.len() >= 512
        && &sector[3..11] == b"EXFAT   "
        && sector[510] == 0x55
        && sector[511] == 0xAA
        && (9..=12).contains(&sector[0x6C])
        && sector[0x6E] >= 1
        && sector[0x6E] <= 2
}

fn volume_flags(sector: &[u8]) -> u16 {
    u16::from_le_bytes([sector[0x6A], sector[0x6B]])
}

/// Microsoft exFAT boot checksum over the first 11 sectors.
/// Skips VolumeFlags (bytes 106-107) and PercentInUse (byte 112).
pub fn exfat_boot_checksum(region: &[u8]) -> Option<u32> {
    if region.len() < 512 * 11 {
        return None;
    }
    let bytes = &region[..512 * 11];
    let mut checksum = 0u32;
    for (index, byte) in bytes.iter().enumerate() {
        if index == 106 || index == 107 || index == 112 {
            continue;
        }
        checksum = checksum.rotate_right(1).wrapping_add(u32::from(*byte));
    }
    Some(checksum)
}

fn stored_exfat_checksum(region: &[u8]) -> Option<u32> {
    if region.len() < 512 * 12 {
        return None;
    }
    Some(u32::from_le_bytes(region[512 * 11..512 * 11 + 4].try_into().unwrap()))
}

pub fn synthesize_exfat_boot() -> Vec<u8> {
    let mut region = vec![0u8; 512 * 12];
    region[0] = 0xEB;
    region[1] = 0x76;
    region[2] = 0x90;
    region[3..11].copy_from_slice(b"EXFAT   ");
    region[0x6C] = 9; // 512-byte sectors
    region[0x6D] = 3; // 8 sectors per cluster
    region[0x6E] = 1;
    region[510] = 0x55;
    region[511] = 0xAA;
    let checksum = exfat_boot_checksum(&region).unwrap();
    for chunk in region[512 * 11..512 * 12].chunks_mut(4) {
        chunk.copy_from_slice(&checksum.to_le_bytes());
    }
    region
}

fn fat32_boot_valid(sector: &[u8]) -> bool {
    if sector.len() < 512 || sector[510] != 0x55 || sector[511] != 0xAA || &sector[0x52..0x5A] != b"FAT32   " {
        return false;
    }
    let bps = u16::from_le_bytes([sector[0x0B], sector[0x0C]]);
    let spc = sector[0x0D];
    let fats = sector[0x10];
    matches!(bps, 512 | 1024 | 2048 | 4096) && spc.is_power_of_two() && spc != 0 && (1..=2).contains(&fats)
}

fn other_magic(head: &[u8]) -> Option<FsKind> {
    if head.len() >= 1082 {
        let magic = u16::from_le_bytes([head[1080], head[1081]]);
        if magic == 0xEF53 {
            return Some(FsKind::Ext4);
        }
    }
    if head.len() >= 1026 {
        let magic = u16::from_be_bytes([head[1024], head[1025]]);
        if magic == 0x482B || magic == 0x4858 {
            return Some(FsKind::HfsPlus);
        }
    }
    if head.len() >= 36 && &head[32..36] == b"NXSB" {
        return Some(FsKind::Apfs);
    }
    None
}

fn kind_from_windows(name: &str) -> FsKind {
    match name.to_uppercase().as_str() {
        "NTFS" => FsKind::Ntfs,
        "EXFAT" => FsKind::ExFat,
        "FAT32" => FsKind::Fat32,
        "FAT" => FsKind::Fat,
        _ => FsKind::Unknown,
    }
}

fn letter(volume: &VolumeProbe) -> String {
    volume.drive_letter.clone().unwrap_or_else(|| format!("#{}", volume.index))
}

/// Describe what a bad disk LBA means, using only structures we actually parsed.
pub fn describe_lba(start_lba: u64, sector_size: u32, kind: FsKind, lba: u64) -> String {
    if lba < start_lba {
        return "This LBA is outside the volume.".into();
    }
    let relative = lba - start_lba;
    if relative < 64 {
        return format!("Disk LBA {lba} is in the {} boot/metadata region of this volume.", kind.label());
    }
    let _ = sector_size;
    "This LBA is inside the volume. Mapping it to a file name needs a full file-system walk, which this pass does not do.".into()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn ntfs_backup_restores_only_when_primary_is_invalid() {
        let good = synthesize_ntfs_boot(1_000_000);
        let mut bad = good.clone();
        bad[510] = 0;
        assert!(ntfs_boot_restore(&bad, &good).is_some());
        assert!(ntfs_boot_restore(&good, &good).is_none());
        let mut volume = VolumeProbe::default();
        volume.head = Some(bad);
        volume.backup_boot = Some(good);
        let assessed = assess_volume(&volume);
        assert_eq!(assessed.class, FsClass::Corrupted);
        assert!(assessed.can_restore_ntfs_boot);
    }

    #[test]
    fn exfat_checksum_detects_a_flipped_byte() {
        let mut region = synthesize_exfat_boot();
        assert!(exfat_boot_valid(&region));
        let mut volume = VolumeProbe { exfat_boot_region: Some(region.clone()), head: Some(region[..512].to_vec()), ..VolumeProbe::default() };
        assert_eq!(assess_volume(&volume).class, FsClass::Healthy);
        region[64] ^= 0xFF;
        volume.head = Some(region[..512].to_vec());
        volume.exfat_boot_region = Some(region);
        let assessed = assess_volume(&volume);
        assert_eq!(assessed.class, FsClass::Corrupted);
        assert!(assessed.can_restore_exfat_boot);
    }

    #[test]
    fn sees_ext4_and_apfs_magics() {
        let mut ext4 = vec![0u8; 2048];
        ext4[1080] = 0x53;
        ext4[1081] = 0xEF;
        assert_eq!(other_magic(&ext4), Some(FsKind::Ext4));
        let mut apfs = vec![0u8; 512];
        apfs[32..36].copy_from_slice(b"NXSB");
        assert_eq!(other_magic(&apfs), Some(FsKind::Apfs));
    }
}
