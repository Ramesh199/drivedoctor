use serde::{Deserialize, Serialize};

use crate::bridges::{enclosure_guidance, lookup_bridge};
use crate::filesystem::{assess_volume, FsClass, VolumeProbe};
use crate::firmware::{assess_firmware, looks_like_empty_reader};
use crate::model::{
    ActionId, DiagnosisReport, DriveIdentity, HardwareFault, HardwareFaultKind, Layer, LayerFinding,
    Repairability, Severity, Symptom,
};
use crate::partition::{analyze_partitions, FoundSignature, PartitionStyle};
use crate::plan::{build_plan, first_recommended, DiagnosisFacts};
use crate::smart::{assess_smart, SmartAssessment, SmartDump};
use crate::symptoms::{severe_hardware, interpret};
use crate::trust::{trust_score, TrustInput, TrustScore};

/// Everything a platform collected. Diagnosis is a pure function of this value.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct ProbeInput {
    pub sample: bool,
    pub identity: DriveIdentity,
    pub symptoms: Vec<Symptom>,
    pub offline: bool,
    pub read_only: bool,
    pub operational_status: String,
    pub registry_write_protect: bool,
    pub driver_problems: Vec<String>,
    pub surprise_removals: u32,
    pub read_error: Option<String>,
    pub smart: Option<SmartDump>,
    pub sector_size: u32,
    pub disk_sectors: u64,
    pub mbr: Option<Vec<u8>>,
    pub gpt_header: Option<Vec<u8>>,
    pub gpt_entries: Option<Vec<u8>>,
    pub gpt_backup_header: Option<Vec<u8>>,
    pub gpt_backup_entries: Option<Vec<u8>>,
    pub volumes: Vec<VolumeProbe>,
    pub lost_signatures: Vec<FoundSignature>,
}

pub fn diagnose(probe: &ProbeInput) -> DiagnosisReport {
    let mut findings = Vec::new();
    let mut warnings = Vec::new();
    let mut facts = DiagnosisFacts::default();
    let smart = probe.smart.as_ref().map(|dump| assess_smart(dump, probe.identity.capacity_bytes));
    let firmware = assess_firmware(&probe.identity);
    let symptom_views = interpret(&probe.symptoms);
    let severe = severe_hardware(&probe.symptoms);

    let enclosure = enclosure_guidance(&probe.identity);
    if enclosure.hardware_encryption_likely {
        warnings.push(enclosure.message.clone());
    }
    if let Some(note) = &enclosure.sector_note {
        warnings.push(note.clone());
    }
    if let (Some(vid), Some(pid)) = (probe.identity.vid, probe.identity.pid) {
        if let Some(bridge) = lookup_bridge(vid, pid) {
            warnings.push(format!("{} (USB {:04X}:{:04X}). {}", bridge.name, vid, pid, bridge.notes));
        }
    }

    let connection = connection_finding(probe, smart.as_ref(), &mut facts, &mut warnings);
    findings.push(connection);
    let os = os_finding(probe, &mut facts);
    findings.push(os);

    let mut hardware_fault = None;
    if let Some(cause) = severe {
        let kind = cause.hardware.unwrap_or(HardwareFaultKind::HeadCrash);
        hardware_fault = Some(hardware_fault_for(kind, &cause.cause));
        facts.hardware = hardware_fault.clone();
        findings.push(LayerFinding {
            layer: Layer::Device,
            ok: false,
            inconclusive: false,
            severity: Severity::Critical,
            summary: kind.title().to_owned(),
            detail: cause.cause.clone(),
        });
    } else if firmware.suspected && !looks_like_empty_reader(&probe.identity.model) {
        facts.firmware = true;
        facts.firmware_summary = firmware.summary.clone();
        facts.vendor_name = firmware.vendor_name.map(str::to_owned);
        facts.vendor_url = firmware.vendor_url.map(str::to_owned);
        hardware_fault = Some(hardware_fault_for(HardwareFaultKind::FirmwareCorruption, &firmware.summary));
        findings.push(LayerFinding {
            layer: Layer::Device,
            ok: false,
            inconclusive: false,
            severity: Severity::Critical,
            summary: "Firmware is not reporting the drive correctly".into(),
            detail: firmware.summary.clone(),
        });
    } else {
        findings.push(device_finding(probe, smart.as_ref(), &mut facts, &mut warnings));
    }

    if facts.hardware.is_none() && !facts.firmware {
        findings.push(partition_finding(probe, &mut facts));
        findings.push(filesystem_finding(probe, &mut facts));
    } else {
        findings.push(skipped(Layer::Partition));
        findings.push(skipped(Layer::FileSystem));
    }
    findings.push(media_finding(smart.as_ref(), &mut facts));

    if !symptom_views.is_empty() && facts.hardware.is_none() {
        let text = symptom_views
            .iter()
            .map(|cause| format!("{}: {}", cause.symptom.label(), cause.cause))
            .collect::<Vec<_>>()
            .join(" ");
        warnings.push(text);
    }

    let failed_layers: Vec<Layer> = findings
        .iter()
        .filter(|finding| !finding.ok && !finding.inconclusive)
        .map(|finding| finding.layer)
        .collect();

    let (root_cause, severity, repairability) = conclude(&facts, &findings);
    facts.healthy = repairability == Repairability::NoRepairNeeded;
    let plan = build_plan(&facts);
    let recommended = first_recommended(&plan);
    let current_trust = trust_score(&TrustInput {
        smart: smart.unwrap_or_else(SmartAssessment::unknown),
        hardware_fault: facts.hardware.is_some() || facts.firmware,
        self_test_failed: false,
        realloc_increased: false,
        pending_increased: false,
        surface_unreadable_zones: 0,
    });

    DiagnosisReport {
        sample: probe.sample,
        identity: probe.identity.clone(),
        findings,
        failed_layers,
        root_cause,
        severity,
        repairability,
        hardware_fault,
        warnings,
        plan,
        recommended,
        current_trust,
    }
}

fn conclude(facts: &DiagnosisFacts, findings: &[LayerFinding]) -> (String, Severity, Repairability) {
    if let Some(hardware) = &facts.hardware {
        return (
            format!("{} {}", hardware.kind.title(), hardware.explanation),
            Severity::Critical,
            Repairability::HardwareFault,
        );
    }
    if facts.firmware {
        return (facts.firmware_summary.clone(), Severity::Critical, Repairability::HardwareFault);
    }
    if facts.sectors_unreadable && !facts.offline {
        return (
            "Sector reads did not succeed, so the partition table and file system have not been judged yet.".into(),
            Severity::Warning,
            Repairability::Repairable,
        );
    }
    if facts.offline || facts.bitlocker_locked || facts.read_only || facts.registry_write_protect {
        let reason = if facts.bitlocker_locked {
            "BitLocker is locked. Unlock it before calling the volume corrupt."
        } else if facts.offline {
            "Windows has the disk offline."
        } else if facts.read_only {
            "Windows has the disk read-only."
        } else {
            "A Windows write-protect policy is set."
        };
        return (reason.into(), Severity::Warning, Repairability::Repairable);
    }
    if facts.gpt_restore || facts.ntfs_boot_restore || facts.exfat_boot_restore || facts.partition_corrupt {
        return (
            "The partition table or a boot sector is damaged. The file data may still be intact.".into(),
            Severity::Warning,
            Repairability::Repairable,
        );
    }
    if facts.fs_corrupt || facts.fs_dirty {
        return (
            "The file system metadata is dirty or inconsistent.".into(),
            Severity::Warning,
            Repairability::Repairable,
        );
    }
    if facts.pending > 0 {
        return (
            format!(
                "{} sector(s) are pending remap. A targeted rewrite retires those sectors; it does not repair the surface.",
                facts.pending
            ),
            Severity::Critical,
            Repairability::RepairableWithDataLoss,
        );
    }
    if facts.fs_raw && facts.partition_empty {
        return (
            "No partition table or file system was found.".into(),
            Severity::Warning,
            Repairability::RepairableWithDataLoss,
        );
    }
    if facts.cable_crc || facts.brown_out {
        return (
            "The drive is reachable, but the cable, port, or power is dropping the link.".into(),
            Severity::Warning,
            Repairability::Repairable,
        );
    }
    if findings.iter().all(|finding| finding.ok || finding.inconclusive) {
        return (
            "No failed layer was found. The drive looks structurally healthy.".into(),
            Severity::Info,
            Repairability::NoRepairNeeded,
        );
    }
    (
        "The drive needs attention. Follow the first recommended step.".into(),
        Severity::Warning,
        Repairability::Repairable,
    )
}

fn connection_finding(
    probe: &ProbeInput,
    smart: Option<&SmartAssessment>,
    facts: &mut DiagnosisFacts,
    warnings: &mut Vec<String>,
) -> LayerFinding {
    let mut detail = Vec::new();
    let status = probe.operational_status.to_lowercase();
    let no_media = status.contains("no media") || (probe.identity.capacity_bytes == 0 && looks_like_empty_reader(&probe.identity.model));
    if no_media {
        detail.push("The device is enumerated but reports no media. If this is a card reader, insert a card. If it is a disk, the bridge may not be talking to the drive.".into());
    }
    if probe.surprise_removals >= 2 {
        facts.brown_out = true;
        detail.push(format!(
            "Windows logged {} surprise removal(s) in the last few hours. That pattern is usually power: try another port, a powered hub, a Y-cable, or the official adapter on a 3.5 inch drive.",
            probe.surprise_removals
        ));
    }
    if smart.map(|item| item.udma_crc > 0).unwrap_or(false) {
        facts.cable_crc = true;
        detail.push("Interface CRC errors are climbing. Swap the cable and avoid USB hubs before blaming the platters.".into());
    }
    if probe.identity.bus.eq_ignore_ascii_case("usb") && probe.identity.capacity_bytes >= 3_000_000_000_000 {
        warnings.push(
            "This is a large USB disk. Desktop 3.5 inch drives need their own power supply; a laptop port will brown out under load.".into(),
        );
    }
    let ok = !facts.brown_out && !facts.cable_crc && !no_media;
    if detail.is_empty() {
        detail.push(format!(
            "The drive is enumerated on {} as {}.",
            if probe.identity.bus.is_empty() { "an unknown bus" } else { &probe.identity.bus },
            probe.identity.device_path
        ));
    }
    LayerFinding {
        layer: Layer::Connection,
        ok,
        inconclusive: false,
        severity: if ok { Severity::Info } else { Severity::Warning },
        summary: if ok { "The drive is connected.".into() } else { "The connection or power looks unstable.".into() },
        detail: detail.join(" "),
    }
}

fn os_finding(probe: &ProbeInput, facts: &mut DiagnosisFacts) -> LayerFinding {
    facts.offline = probe.offline;
    facts.read_only = probe.read_only;
    facts.registry_write_protect = probe.registry_write_protect;
    facts.driver_problem = !probe.driver_problems.is_empty();
    facts.bitlocker_locked = probe.volumes.iter().any(|volume| volume.bitlocker_locked);
    facts.missing_letter = probe.volumes.iter().any(|volume| volume.drive_letter.is_none() && volume.length_bytes > 0);
    facts.has_letter = probe.volumes.iter().any(|volume| volume.drive_letter.is_some());
    let mut parts = Vec::new();
    if probe.offline {
        parts.push("The disk is offline.".into());
    }
    if probe.read_only {
        parts.push("The disk is marked read-only.".into());
    }
    if probe.registry_write_protect {
        parts.push("The StorageDevicePolicies write-protect registry value is on.".into());
    }
    if facts.bitlocker_locked {
        parts.push("A volume is locked by BitLocker.".into());
    }
    if facts.driver_problem {
        parts.push(format!("Device Manager reports: {}.", probe.driver_problems.join("; ")));
    }
    if !probe.operational_status.is_empty() {
        parts.push(format!("Windows operational status: {}.", probe.operational_status));
    }
    let ok = parts.iter().all(|part| part.starts_with("Windows operational"));
    if parts.is_empty() {
        parts.push("Windows is presenting the disk without an offline, read-only, or policy block.".into());
    }
    LayerFinding {
        layer: Layer::OsDriver,
        ok,
        inconclusive: false,
        severity: if ok { Severity::Info } else { Severity::Warning },
        summary: if ok { "Windows is not blocking the disk.".into() } else { "Windows is blocking normal access.".into() },
        detail: parts.join(" "),
    }
}

fn device_finding(
    probe: &ProbeInput,
    smart: Option<&SmartAssessment>,
    facts: &mut DiagnosisFacts,
    _warnings: &mut Vec<String>,
) -> LayerFinding {
    let Some(smart) = smart else {
        return LayerFinding {
            layer: Layer::Device,
            ok: true,
            inconclusive: true,
            severity: Severity::Warning,
            summary: "SMART was not read".into(),
            detail: "Install smartmontools so DriveDoctor can read ATA/NVMe health. Windows storage status alone is not a SMART report.".into(),
        };
    };
    facts.hpa = smart.hpa_suspected;
    facts.pending = smart.pending;
    if smart.spin_retry > 0 {
        facts.guidance = "Spin retries mean the motor or the power path is failing. Use a known-good power supply, and do not run a surface write. If the drive still will not stay ready, treat it as a hardware fault.".into();
    }
    let ok = !smart.failing;
    LayerFinding {
        layer: Layer::Device,
        ok,
        inconclusive: false,
        severity: if smart.failing { Severity::Critical } else if smart.verdict == crate::smart::SmartVerdict::Warning { Severity::Warning } else { Severity::Info },
        summary: match smart.verdict {
            crate::smart::SmartVerdict::Healthy => "SMART looks normal".into(),
            crate::smart::SmartVerdict::Warning => "SMART shows wear or link errors".into(),
            crate::smart::SmartVerdict::Failing => "SMART says the drive is failing".into(),
            crate::smart::SmartVerdict::Unknown => "SMART was not readable".into(),
        },
        detail: smart.lines.join(" "),
    }
}

fn partition_finding(probe: &ProbeInput, facts: &mut DiagnosisFacts) -> LayerFinding {
    if let Some(error) = &probe.read_error {
        facts.sectors_unreadable = true;
        return LayerFinding {
            layer: Layer::Partition,
            ok: false,
            inconclusive: true,
            severity: Severity::Warning,
            summary: "Partition table was not read".into(),
            detail: format!("{error} This is not evidence that the partition table is corrupt."),
        };
    }
    if probe.mbr.is_none() && probe.gpt_header.is_none() {
        facts.sectors_unreadable = true;
        return LayerFinding {
            layer: Layer::Partition,
            ok: false,
            inconclusive: true,
            severity: Severity::Warning,
            summary: "Partition table was not read".into(),
            detail: "No sector data was collected.".into(),
        };
    }
    let analysis = analyze_partitions(
        probe.disk_sectors,
        probe.sector_size,
        probe.mbr.as_deref(),
        probe.gpt_header.as_deref(),
        probe.gpt_entries.as_deref(),
        probe.gpt_backup_header.as_deref(),
        probe.gpt_backup_entries.as_deref(),
    );
    facts.gpt_restore = analysis.can_restore_primary_from_backup || analysis.can_restore_backup_from_primary;
    facts.protective_mbr = analysis.protective_mbr_needs_fix;
    facts.partition_corrupt = analysis.style == PartitionStyle::Corrupt || analysis.problems.iter().any(|p| p.contains("overlap") || p.contains("past the"));
    facts.partition_empty = matches!(analysis.style, PartitionStyle::Empty);
    facts.lost_signatures = probe.lost_signatures.len();
    let ok = analysis.problems.is_empty() && !matches!(analysis.style, PartitionStyle::Corrupt | PartitionStyle::Empty);
    let summary = if ok {
        format!("{:?} partition table looks consistent.", analysis.style)
    } else if facts.gpt_restore {
        "One GPT copy is damaged and the other is usable.".into()
    } else {
        "The partition table needs repair or was not found.".into()
    };
    let names = if analysis.partitions.is_empty() {
        String::new()
    } else {
        format!(
            " Partitions: {}.",
            analysis
                .partitions
                .iter()
                .map(|part| format!("{} {} (LBA {}-{})", part.index, part.type_name, part.start_lba, part.end_lba))
                .collect::<Vec<_>>()
                .join("; ")
        )
    };
    LayerFinding {
        layer: Layer::Partition,
        ok,
        inconclusive: false,
        severity: if ok { Severity::Info } else { Severity::Warning },
        summary,
        detail: format!("{}{names}", if analysis.problems.is_empty() { "No partition-table problems.".into() } else { analysis.problems.join(" ") }),
    }
}

fn filesystem_finding(probe: &ProbeInput, facts: &mut DiagnosisFacts) -> LayerFinding {
    if facts.sectors_unreadable {
        return skipped_inconclusive(Layer::FileSystem, "File system was not read because the sector read failed.");
    }
    if probe.volumes.is_empty() {
        facts.fs_raw = facts.partition_empty || facts.partition_corrupt;
        return LayerFinding {
            layer: Layer::FileSystem,
            ok: !facts.fs_raw,
            inconclusive: !facts.fs_raw,
            severity: if facts.fs_raw { Severity::Warning } else { Severity::Info },
            summary: if facts.fs_raw { "No file system to inspect.".into() } else { "No volumes were collected.".into() },
            detail: "Volume boot sectors were not passed in.".into(),
        };
    }
    let assessments: Vec<_> = probe.volumes.iter().map(assess_volume).collect();
    facts.ntfs_boot_restore = assessments.iter().any(|item| item.can_restore_ntfs_boot);
    facts.exfat_boot_restore = assessments.iter().any(|item| item.can_restore_exfat_boot);
    facts.fs_dirty = assessments.iter().any(|item| item.class == FsClass::Dirty);
    facts.fs_corrupt = assessments.iter().any(|item| item.class == FsClass::Corrupted);
    facts.fs_raw = assessments.iter().any(|item| item.class == FsClass::Raw);
    facts.fs_structurally_ok = assessments.iter().any(|item| matches!(item.class, FsClass::Healthy | FsClass::Dirty));
    facts.has_letter = facts.has_letter || assessments.iter().any(|item| item.drive_letter.is_some());
    let ok = assessments.iter().all(|item| matches!(item.class, FsClass::Healthy | FsClass::Unknown));
    let detail = assessments
        .iter()
        .map(|item| format!("Volume {}: {}", item.index, item.detail))
        .collect::<Vec<_>>()
        .join(" ");
    LayerFinding {
        layer: Layer::FileSystem,
        ok,
        inconclusive: assessments.iter().all(|item| item.class == FsClass::Unknown),
        severity: if facts.fs_corrupt || facts.fs_raw { Severity::Warning } else if facts.fs_dirty { Severity::Warning } else { Severity::Info },
        summary: if ok { "File system structures look consistent.".into() } else { "A file system needs repair.".into() },
        detail,
    }
}

fn media_finding(smart: Option<&SmartAssessment>, facts: &mut DiagnosisFacts) -> LayerFinding {
    let pending = smart.map(|item| item.pending).unwrap_or(0);
    facts.pending = pending;
    if pending == 0 && smart.map(|item| item.uncorrectable == 0).unwrap_or(true) {
        return LayerFinding {
            layer: Layer::Media,
            ok: true,
            inconclusive: smart.is_none(),
            severity: Severity::Info,
            summary: "No pending sectors reported".into(),
            detail: "SMART is not reporting sectors waiting to be remapped. A surface scan is still the way to find slow zones.".into(),
        };
    }
    LayerFinding {
        layer: Layer::Media,
        ok: false,
        inconclusive: false,
        severity: Severity::Critical,
        summary: format!("{pending} pending sector(s)"),
        detail: "Pending sectors are LBAs the drive could not read. Writing them later tells the firmware to use a spare. It does not bring the old bytes back.".into(),
    }
}

fn hardware_fault_for(kind: HardwareFaultKind, explanation: &str) -> HardwareFault {
    let next_steps = match kind {
        HardwareFaultKind::HeadCrash => vec![
            "Power the drive down and leave it down. Each spin-up can scratch the platters.".into(),
            "Do not run chkdsk, a format, or a full-surface write.".into(),
            "A recovery lab can image it with a head swap if the platters are not scored.".into(),
        ],
        HardwareFaultKind::SeizedMotor => vec![
            "Stop retrying spin-up. Motors that cannot turn get hotter on every attempt.".into(),
            "A lab may transplant the platters. That is not a software repair.".into(),
        ],
        HardwareFaultKind::PcbFailure => vec![
            "A board swap only works if the ROM and adaptive data are moved to the donor board.".into(),
            "A matching donor without that transfer usually reads zeros or clicks.".into(),
        ],
        HardwareFaultKind::FirmwareCorruption => vec![
            "Do not zero-fill a drive whose firmware is not reporting its real size.".into(),
            "Check the maker's firmware tool, then a lab if the model is a known brick.".into(),
        ],
        HardwareFaultKind::LiquidDamage | HardwareFaultKind::FireOrBurn => vec![
            "Do not power the drive, and do not dry it in an oven.".into(),
            "Keep it as it is and hand it to a lab that accepts contamination cases.".into(),
        ],
        HardwareFaultKind::DeadUsbBridge => vec![
            "The disk may be fine. Read the encryption warning before moving it to a new enclosure.".into(),
            "A plain SATA dock is the test only when the original bridge does not encrypt.".into(),
        ],
        HardwareFaultKind::SsdController => vec![
            "Controller failure is not a format problem. Further writes reduce what a lab can still extract.".into(),
        ],
    };
    HardwareFault {
        kind,
        explanation: explanation.to_owned(),
        next_steps,
        power_down: !matches!(kind, HardwareFaultKind::FirmwareCorruption | HardwareFaultKind::DeadUsbBridge | HardwareFaultKind::SsdController),
    }
}

fn skipped(layer: Layer) -> LayerFinding {
    LayerFinding {
        layer,
        ok: true,
        inconclusive: true,
        severity: Severity::Info,
        summary: "Not inspected".into(),
        detail: "Lower layers were skipped because a hardware or firmware fault already explains the failure. Reading further can make a mechanical fault worse.".into(),
    }
}

fn skipped_inconclusive(layer: Layer, detail: &str) -> LayerFinding {
    LayerFinding {
        layer,
        ok: false,
        inconclusive: true,
        severity: Severity::Warning,
        summary: "Not judged".into(),
        detail: detail.to_owned(),
    }
}

pub fn recommended_id(report: &DiagnosisReport) -> Option<ActionId> {
    report.recommended
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::filesystem::synthesize_ntfs_boot;
    use crate::model::ActionId;
    use crate::partition::{synthesize_gpt, GptPartSpec, BASIC_DATA_GUID};
    use crate::smart::{SmartAttribute, SmartDump};

    fn base() -> ProbeInput {
        ProbeInput {
            sample: true,
            identity: DriveIdentity {
                disk_number: 3,
                device_path: r"\\.\PhysicalDrive3".into(),
                model: "WDC WD20EZRZ-00Z5HB0".into(),
                serial: "WD-SAMPLE0001".into(),
                firmware: "80.00A80".into(),
                capacity_bytes: 2048 * 512,
                logical_sector_size: 512,
                physical_sector_size: 512,
                bus: "USB".into(),
                is_boot: false,
                is_system: false,
                pnp_id: String::new(),
                vid: Some(0x174C),
                pid: Some(0x55AA),
                usb_product: "ASM1153".into(),
            },
            symptoms: vec![],
            offline: false,
            read_only: false,
            operational_status: "Online".into(),
            registry_write_protect: false,
            driver_problems: vec![],
            surprise_removals: 0,
            read_error: None,
            smart: Some(SmartDump { passed: Some(true), ..SmartDump::default() }),
            sector_size: 512,
            disk_sectors: 2048,
            mbr: None,
            gpt_header: None,
            gpt_entries: None,
            gpt_backup_header: None,
            gpt_backup_entries: None,
            volumes: vec![],
            lost_signatures: vec![],
        }
    }

    #[test]
    fn a_broken_gpt_recommends_restore_not_format() {
        let disk = synthesize_gpt(2048, 512, &[GptPartSpec {
            type_guid: BASIC_DATA_GUID,
            start_lba: 34,
            end_lba: 200,
            name: "Data".into(),
        }]).unwrap();
        let mut header = disk.header.clone();
        header[0] = b'X';
        let mut probe = base();
        probe.mbr = Some(disk.mbr);
        probe.gpt_header = Some(header);
        probe.gpt_entries = Some(disk.entries);
        probe.gpt_backup_header = Some(disk.backup_header);
        probe.gpt_backup_entries = Some(disk.backup_entries);
        let mut boot = synthesize_ntfs_boot(160);
        let mut head = boot.clone();
        // Keep a valid backup and a damaged primary so the file system is not the root cause.
        head[510] = 0;
        probe.volumes = vec![VolumeProbe {
            index: 1,
            start_lba: 34,
            length_bytes: 160 * 512,
            head: Some(head),
            backup_boot: Some(boot.split_off(0)),
            ..VolumeProbe::default()
        }];
        let report = diagnose(&probe);
        assert_eq!(report.repairability, Repairability::Repairable);
        assert_eq!(report.recommended, Some(ActionId::ProtectData));
        assert!(report.plan.iter().any(|item| item.id == ActionId::RestoreGpt && item.recommended));
        assert!(report.plan.iter().any(|item| item.id == ActionId::CreatePartitionAndFormat && !item.recommended));
    }

    #[test]
    fn clicking_is_a_hardware_fault_with_no_write_plan() {
        let mut probe = base();
        probe.symptoms = vec![Symptom::Clicking];
        let report = diagnose(&probe);
        assert_eq!(report.repairability, Repairability::HardwareFault);
        assert_eq!(report.recommended, Some(ActionId::PowerDown));
        assert!(report.plan.iter().all(|item| item.risk == crate::model::RiskLevel::Safe));
    }

    #[test]
    fn access_denied_is_not_called_corruption() {
        let mut probe = base();
        probe.read_error = Some("Access is denied.".into());
        probe.mbr = None;
        let report = diagnose(&probe);
        let partition = report.findings.iter().find(|f| f.layer == Layer::Partition).unwrap();
        assert!(partition.inconclusive);
        assert!(!report.root_cause.to_lowercase().contains("corrupt"));
    }

    #[test]
    fn pending_sectors_are_targeted() {
        let mut probe = base();
        let disk = synthesize_gpt(2048, 512, &[GptPartSpec {
            type_guid: BASIC_DATA_GUID,
            start_lba: 34,
            end_lba: 200,
            name: "Data".into(),
        }]).unwrap();
        probe.mbr = Some(disk.mbr);
        probe.gpt_header = Some(disk.header);
        probe.gpt_entries = Some(disk.entries);
        probe.gpt_backup_header = Some(disk.backup_header);
        probe.gpt_backup_entries = Some(disk.backup_entries);
        probe.volumes = vec![VolumeProbe {
            index: 1,
            start_lba: 34,
            head: Some(synthesize_ntfs_boot(100)),
            backup_boot: Some(synthesize_ntfs_boot(100)),
            ..VolumeProbe::default()
        }];
        probe.smart = Some(SmartDump {
            passed: Some(true),
            attributes: vec![SmartAttribute {
                id: 197,
                name: "Current_Pending_Sector".into(),
                current: 100,
                worst: 100,
                threshold: 0,
                raw: 6,
                prefail: false,
            }],
            ..SmartDump::default()
        });
        let report = diagnose(&probe);
        assert_eq!(report.repairability, Repairability::RepairableWithDataLoss);
        assert!(report.plan.iter().any(|item| item.id == ActionId::RemapPendingSectors && item.recommended));
    }
}
