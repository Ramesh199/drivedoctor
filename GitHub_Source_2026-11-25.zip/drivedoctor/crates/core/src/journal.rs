use serde::{Deserialize, Serialize};

use crate::partition::SectorWrite;

/// Bytes that were on the disk before a metadata repair. Rollback writes these back.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct JournalFile {
    pub version: u32,
    pub serial: String,
    pub model: String,
    pub capacity_bytes: u64,
    pub reason: String,
    pub entries: Vec<JournalEntry>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct JournalEntry {
    pub lba: u64,
    pub before_hex: String,
}

impl JournalFile {
    pub fn from_writes(serial: &str, model: &str, capacity_bytes: u64, reason: &str, before: &[(u64, Vec<u8>)]) -> Result<Self, String> {
        let mut entries = Vec::new();
        for (lba, bytes) in before {
            if bytes.is_empty() || bytes.len() > 4096 {
                return Err(format!("refusing to journal LBA {lba}: sector length {} is not believable", bytes.len()));
            }
            entries.push(JournalEntry { lba: *lba, before_hex: hex_encode(bytes) });
        }
        Ok(Self {
            version: 1,
            serial: serial.to_owned(),
            model: model.to_owned(),
            capacity_bytes,
            reason: reason.to_owned(),
            entries,
        })
    }

    pub fn rollback_writes(&self) -> Result<Vec<SectorWrite>, String> {
        let mut writes = Vec::new();
        for entry in &self.entries {
            let data = hex_decode(&entry.before_hex)?;
            writes.push(SectorWrite {
                lba: entry.lba,
                data,
                what: format!("rollback LBA {}", entry.lba),
            });
        }
        Ok(writes)
    }
}

pub fn hex_encode(bytes: &[u8]) -> String {
    const HEX: &[u8; 16] = b"0123456789abcdef";
    let mut out = String::with_capacity(bytes.len() * 2);
    for byte in bytes {
        out.push(HEX[(byte >> 4) as usize] as char);
        out.push(HEX[(byte & 0x0F) as usize] as char);
    }
    out
}

pub fn hex_decode(text: &str) -> Result<Vec<u8>, String> {
    if text.len() % 2 != 0 {
        return Err("hex length is odd".into());
    }
    let bytes = text.as_bytes();
    let mut out = Vec::with_capacity(text.len() / 2);
    let mut index = 0;
    while index < bytes.len() {
        let hi = unhex(bytes[index])?;
        let lo = unhex(bytes[index + 1])?;
        out.push((hi << 4) | lo);
        index += 2;
    }
    Ok(out)
}

fn unhex(byte: u8) -> Result<u8, String> {
    match byte {
        b'0'..=b'9' => Ok(byte - b'0'),
        b'a'..=b'f' => Ok(byte - b'a' + 10),
        b'A'..=b'F' => Ok(byte - b'A' + 10),
        _ => Err("journal contains a non-hex digit".into()),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn journal_round_trips_a_sector() {
        let before = vec![(1u64, vec![0x55, 0xAA, 0x10])];
        let journal = JournalFile::from_writes("SER", "MODEL", 1000, "gpt", &before).unwrap();
        let writes = journal.rollback_writes().unwrap();
        assert_eq!(writes[0].lba, 1);
        assert_eq!(writes[0].data, vec![0x55, 0xAA, 0x10]);
    }
}
