use serde::{Deserialize, Serialize};

use crate::crc::crc32;

pub const GPT_SIGNATURE: &[u8; 8] = b"EFI PART";
pub const BASIC_DATA_GUID: [u8; 16] = [
    0xA2, 0xA0, 0xD0, 0xEB, 0xE5, 0xB9, 0x33, 0x44, 0x87, 0xC0, 0x68, 0xB6, 0xB7, 0x26, 0x99, 0xC7,
];

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum PartitionStyle {
    Gpt,
    Mbr,
    Empty,
    Corrupt,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct ParsedPartition {
    pub index: u32,
    pub start_lba: u64,
    pub end_lba: u64,
    pub type_name: String,
    pub name: String,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct PartitionAnalysis {
    pub style: PartitionStyle,
    pub problems: Vec<String>,
    pub partitions: Vec<ParsedPartition>,
    pub can_restore_primary_from_backup: bool,
    pub can_restore_backup_from_primary: bool,
    pub protective_mbr_needs_fix: bool,
    pub has_extended: bool,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct SectorWrite {
    pub lba: u64,
    pub data: Vec<u8>,
    pub what: String,
}

#[derive(Clone, Debug)]
struct GptHeader {
    valid: bool,
    my_lba: u64,
    alternate_lba: u64,
    first_usable: u64,
    last_usable: u64,
    entry_lba: u64,
    num_entries: u32,
    entry_size: u32,
    entry_crc: u32,
    problems: Vec<String>,
}

pub fn analyze_partitions(
    disk_sectors: u64,
    sector_size: u32,
    mbr: Option<&[u8]>,
    primary_header: Option<&[u8]>,
    primary_entries: Option<&[u8]>,
    backup_header: Option<&[u8]>,
    backup_entries: Option<&[u8]>,
) -> PartitionAnalysis {
    let sector_size = if sector_size == 0 { 512 } else { sector_size };
    let mbr_info = mbr.map(|bytes| parse_mbr(bytes, disk_sectors));
    let primary = primary_header.map(|bytes| parse_gpt_header(bytes, sector_size));
    let backup = backup_header.map(|bytes| parse_gpt_header(bytes, sector_size));
    let primary_crc_ok = gpt_entries_match(primary.as_ref(), primary_entries);
    let backup_crc_ok = gpt_entries_match(backup.as_ref(), backup_entries);

    let mut problems = Vec::new();
    let mut partitions = Vec::new();
    let mut style = PartitionStyle::Empty;
    let mut has_extended = false;

    if let Some(mbr_info) = &mbr_info {
        has_extended = mbr_info.has_extended;
        if !mbr_info.signature_ok {
            problems.push("Sector 0 has no 0x55AA signature, so there is no readable MBR.".into());
            style = PartitionStyle::Corrupt;
        } else if mbr_info.partitions.is_empty() && !mbr_info.protective {
            problems.push("The MBR signature is present but every partition entry is empty.".into());
            style = PartitionStyle::Empty;
        } else if !mbr_info.protective {
            style = PartitionStyle::Mbr;
            partitions = mbr_info.partitions.clone();
            problems.extend(mbr_info.problems.clone());
        }
    } else {
        problems.push("Sector 0 was not read.".into());
    }

    let primary_ok = primary.as_ref().map(|h| h.valid).unwrap_or(false) && primary_crc_ok;
    let backup_ok = backup.as_ref().map(|h| h.valid).unwrap_or(false) && backup_crc_ok;
    if primary.as_ref().map(|h| h.valid).unwrap_or(false) || backup.as_ref().map(|h| h.valid).unwrap_or(false) {
        style = PartitionStyle::Gpt;
        if let Some(header) = primary.as_ref().filter(|h| h.valid) {
            problems.extend(header.problems.clone());
            if !primary_crc_ok {
                problems.push("The primary GPT entry array CRC does not match the header.".into());
            } else if let Some(entries) = primary_entries {
                partitions = parse_gpt_entries(entries, header, disk_sectors);
            }
        } else if let Some(header) = &primary {
            problems.extend(header.problems.clone());
        }
        if let Some(header) = &backup {
            if !header.valid {
                problems.push("The backup GPT header is missing or its CRC is wrong.".into());
            } else if !backup_crc_ok {
                problems.push("The backup GPT entry array CRC does not match its header.".into());
            }
        } else {
            problems.push("The backup GPT header was not read.".into());
        }
        if primary_ok && backup_ok {
            if let (Some(a), Some(b)) = (primary_entries, backup_entries) {
                if a != b {
                    problems.push("The primary and backup GPT partition arrays do not match.".into());
                }
            }
        }
        if !primary_ok && !backup_ok {
            style = PartitionStyle::Corrupt;
            problems.push("Neither GPT copy could be validated.".into());
        }
        if partitions.is_empty() && backup_ok {
            if let (Some(header), Some(entries)) = (backup.as_ref(), backup_entries) {
                partitions = parse_gpt_entries(entries, header, disk_sectors);
            }
        }
    }

    if style != PartitionStyle::Gpt {
        if let Some(mbr_info) = &mbr_info {
            partitions = if mbr_info.protective { Vec::new() } else { mbr_info.partitions.clone() };
        }
    }

    let overlaps = overlapping(&partitions);
    let out_of_bounds = partitions.iter().any(|part| part.end_lba >= disk_sectors && disk_sectors > 0);
    if overlaps {
        problems.push("Two partitions overlap.".into());
    }
    if out_of_bounds {
        problems.push("A partition ends past the end of the disk.".into());
    }

    let protective_mbr_needs_fix = style == PartitionStyle::Gpt
        && mbr_info
            .as_ref()
            .map(|info| !info.protective || !info.signature_ok)
            .unwrap_or(false);

    PartitionAnalysis {
        style,
        problems,
        partitions,
        can_restore_primary_from_backup: !primary_ok && backup_ok,
        can_restore_backup_from_primary: primary_ok && !backup_ok,
        protective_mbr_needs_fix,
        has_extended,
    }
}

pub fn gpt_repair_writes(
    disk_sectors: u64,
    sector_size: u32,
    primary_header: Option<&[u8]>,
    primary_entries: Option<&[u8]>,
    backup_header: Option<&[u8]>,
    backup_entries: Option<&[u8]>,
) -> Result<Vec<SectorWrite>, String> {
    let analysis = analyze_partitions(
        disk_sectors,
        sector_size,
        None,
        primary_header,
        primary_entries,
        backup_header,
        backup_entries,
    );
    let sector_size = sector_size as usize;
    if analysis.can_restore_primary_from_backup {
        let entries = backup_entries.ok_or("Backup GPT entries were not read.")?;
        let source = parse_gpt_header(backup_header.ok_or("Backup GPT header was not read.")?, sector_size as u32);
        if !source.valid {
            return Err("Backup GPT header is not valid.".into());
        }
        let mut writes = Vec::new();
        let entry_sectors = entry_sector_count(source.num_entries, source.entry_size, sector_size as u32);
        let header = build_header_sector(
            sector_size,
            1,
            disk_sectors - 1,
            source.first_usable,
            source.last_usable,
            2,
            source.num_entries,
            source.entry_size,
            crc32(entries),
        );
        writes.push(SectorWrite { lba: 1, data: header, what: "primary GPT header restored from the backup copy".into() });
        push_entry_writes(&mut writes, 2, entries, sector_size, "primary GPT entries restored from the backup copy");
        let _ = entry_sectors;
        Ok(writes)
    } else if analysis.can_restore_backup_from_primary {
        let entries = primary_entries.ok_or("Primary GPT entries were not read.")?;
        let source = parse_gpt_header(primary_header.ok_or("Primary GPT header was not read.")?, sector_size as u32);
        if !source.valid {
            return Err("Primary GPT header is not valid.".into());
        }
        let entry_sectors = entry_sector_count(source.num_entries, source.entry_size, sector_size as u32) as u64;
        let backup_entry_lba = disk_sectors - 1 - entry_sectors;
        let header = build_header_sector(
            sector_size,
            disk_sectors - 1,
            1,
            source.first_usable,
            source.last_usable,
            backup_entry_lba,
            source.num_entries,
            source.entry_size,
            crc32(entries),
        );
        let mut writes = vec![SectorWrite {
            lba: disk_sectors - 1,
            data: header,
            what: "backup GPT header restored from the primary copy".into(),
        }];
        push_entry_writes(&mut writes, backup_entry_lba, entries, sector_size, "backup GPT entries restored from the primary copy");
        Ok(writes)
    } else {
        Err("Neither GPT copy can be rebuilt from the other.".into())
    }
}

pub fn protective_mbr(disk_sectors: u64, sector_size: usize) -> Vec<u8> {
    let mut sector = vec![0u8; sector_size.max(512)];
    let size = disk_sectors.saturating_sub(1).min(0xFFFF_FFFF) as u32;
    write_mbr_entry(&mut sector[446..462], 0xEE, 1, size);
    sector[510] = 0x55;
    sector[511] = 0xAA;
    sector.truncate(sector_size.max(512));
    if sector.len() < sector_size {
        sector.resize(sector_size, 0);
    }
    sector
}

fn push_entry_writes(writes: &mut Vec<SectorWrite>, start_lba: u64, entries: &[u8], sector_size: usize, what: &str) {
    for (index, chunk) in entries.chunks(sector_size).enumerate() {
        let mut data = vec![0u8; sector_size];
        data[..chunk.len()].copy_from_slice(chunk);
        writes.push(SectorWrite {
            lba: start_lba + index as u64,
            data,
            what: what.to_owned(),
        });
    }
}

#[derive(Clone, Debug)]
struct MbrInfo {
    signature_ok: bool,
    protective: bool,
    has_extended: bool,
    partitions: Vec<ParsedPartition>,
    problems: Vec<String>,
}

fn parse_mbr(sector: &[u8], disk_sectors: u64) -> MbrInfo {
    if sector.len() < 512 {
        return MbrInfo {
            signature_ok: false,
            protective: false,
            has_extended: false,
            partitions: Vec::new(),
            problems: vec!["MBR sector is shorter than 512 bytes.".into()],
        };
    }
    let signature_ok = sector[510] == 0x55 && sector[511] == 0xAA;
    let mut partitions = Vec::new();
    let mut protective = false;
    let mut has_extended = false;
    let mut problems = Vec::new();
    if !signature_ok {
        return MbrInfo { signature_ok, protective, has_extended, partitions, problems };
    }
    for index in 0..4 {
        let entry = &sector[446 + index * 16..446 + (index + 1) * 16];
        let kind = entry[4];
        let start = u32::from_le_bytes(entry[8..12].try_into().unwrap()) as u64;
        let count = u32::from_le_bytes(entry[12..16].try_into().unwrap()) as u64;
        if kind == 0 || count == 0 {
            continue;
        }
        if kind == 0xEE {
            protective = true;
        }
        if matches!(kind, 0x05 | 0x0F | 0x85) {
            has_extended = true;
        }
        let end = start.saturating_add(count).saturating_sub(1);
        if disk_sectors > 0 && end >= disk_sectors && kind != 0xEE {
            problems.push(format!("MBR partition {} ends past the disk.", index + 1));
        }
        partitions.push(ParsedPartition {
            index: index as u32 + 1,
            start_lba: start,
            end_lba: end,
            type_name: mbr_type_name(kind).to_owned(),
            name: String::new(),
        });
    }
    if protective && partitions.iter().any(|part| part.type_name != "Protective MBR") {
        problems.push("The protective MBR contains a partition that is not the 0xEE placeholder.".into());
    }
    MbrInfo { signature_ok, protective, has_extended, partitions, problems }
}

fn mbr_type_name(kind: u8) -> &'static str {
    match kind {
        0x07 => "NTFS/exFAT",
        0x0B | 0x0C => "FAT32",
        0x0E | 0x06 => "FAT16",
        0x83 => "Linux",
        0xEE => "Protective MBR",
        0xEF => "EFI system",
        0x05 | 0x0F => "Extended",
        0x42 => "Dynamic disk",
        _ => "Other",
    }
}

fn parse_gpt_header(sector: &[u8], sector_size: u32) -> GptHeader {
    let mut problems = Vec::new();
    let blank = GptHeader {
        valid: false,
        my_lba: 0,
        alternate_lba: 0,
        first_usable: 0,
        last_usable: 0,
        entry_lba: 0,
        num_entries: 0,
        entry_size: 0,
        entry_crc: 0,
        problems: Vec::new(),
    };
    if sector.len() < 92 {
        problems.push("GPT header is shorter than 92 bytes.".into());
        return GptHeader { problems, ..blank };
    }
    if &sector[0..8] != GPT_SIGNATURE {
        problems.push("GPT signature is not \"EFI PART\".".into());
        return GptHeader { problems, ..blank };
    }
    let header_size = u32::from_le_bytes(sector[12..16].try_into().unwrap());
    if header_size < 92 || header_size as usize > sector.len() || header_size > sector_size {
        problems.push("GPT header size is out of range.".into());
        return GptHeader { problems, ..blank };
    }
    let stored_crc = u32::from_le_bytes(sector[16..20].try_into().unwrap());
    let mut zeroed = sector[..header_size as usize].to_vec();
    zeroed[16..20].fill(0);
    if crc32(&zeroed) != stored_crc {
        problems.push("GPT header CRC does not match.".into());
        return GptHeader { problems, ..blank };
    }
    let num_entries = u32::from_le_bytes(sector[80..84].try_into().unwrap());
    let entry_size = u32::from_le_bytes(sector[84..88].try_into().unwrap());
    if num_entries == 0 || num_entries > 4096 || entry_size < 128 || entry_size > 4096 || entry_size % 8 != 0 {
        problems.push("GPT entry count or size is not believable.".into());
        return GptHeader { problems, ..blank };
    }
    GptHeader {
        valid: true,
        my_lba: u64::from_le_bytes(sector[24..32].try_into().unwrap()),
        alternate_lba: u64::from_le_bytes(sector[32..40].try_into().unwrap()),
        first_usable: u64::from_le_bytes(sector[40..48].try_into().unwrap()),
        last_usable: u64::from_le_bytes(sector[48..56].try_into().unwrap()),
        entry_lba: u64::from_le_bytes(sector[72..80].try_into().unwrap()),
        num_entries,
        entry_size,
        entry_crc: u32::from_le_bytes(sector[88..92].try_into().unwrap()),
        problems,
    }
}

fn gpt_entries_match(header: Option<&GptHeader>, entries: Option<&[u8]>) -> bool {
    match (header, entries) {
        (Some(header), Some(entries)) if header.valid => {
            let need = header.num_entries.saturating_mul(header.entry_size) as usize;
            entries.len() >= need && crc32(&entries[..need]) == header.entry_crc
        }
        _ => false,
    }
}

fn parse_gpt_entries(entries: &[u8], header: &GptHeader, disk_sectors: u64) -> Vec<ParsedPartition> {
    let mut found = Vec::new();
    let size = header.entry_size as usize;
    for index in 0..header.num_entries as usize {
        let start = index * size;
        let end = start + size;
        if end > entries.len() {
            break;
        }
        let entry = &entries[start..end];
        if entry[..16].iter().all(|byte| *byte == 0) {
            continue;
        }
        let start_lba = u64::from_le_bytes(entry[32..40].try_into().unwrap());
        let end_lba = u64::from_le_bytes(entry[40..48].try_into().unwrap());
        let name = decode_utf16_name(&entry[56..56 + 72.min(entry.len().saturating_sub(56))]);
        let _ = disk_sectors;
        found.push(ParsedPartition {
            index: index as u32 + 1,
            start_lba,
            end_lba,
            type_name: gpt_type_name(&entry[..16]).to_owned(),
            name,
        });
    }
    found
}

fn gpt_type_name(guid: &[u8]) -> &'static str {
    if guid == BASIC_DATA_GUID {
        "Microsoft basic data"
    } else if guid == [0x28, 0x73, 0x2A, 0xC1, 0x1F, 0xF8, 0xD2, 0x11, 0xBA, 0x4B, 0x00, 0xA0, 0xC9, 0x3E, 0xC9, 0x3B] {
        "EFI system"
    } else {
        "Other GPT type"
    }
}

fn decode_utf16_name(bytes: &[u8]) -> String {
    let units: Vec<u16> = bytes
        .chunks(2)
        .map(|chunk| u16::from_le_bytes([chunk[0], *chunk.get(1).unwrap_or(&0)]))
        .take_while(|unit| *unit != 0)
        .take(36)
        .collect();
    String::from_utf16_lossy(&units)
}

fn overlapping(parts: &[ParsedPartition]) -> bool {
    let mut ordered: Vec<&ParsedPartition> = parts.iter().collect();
    ordered.sort_by_key(|part| part.start_lba);
    ordered.windows(2).any(|pair| pair[1].start_lba <= pair[0].end_lba)
}

fn entry_sector_count(num_entries: u32, entry_size: u32, sector_size: u32) -> u32 {
    let bytes = num_entries.saturating_mul(entry_size);
    bytes.div_ceil(sector_size.max(1))
}

fn build_header_sector(
    sector_size: usize,
    my_lba: u64,
    alternate_lba: u64,
    first_usable: u64,
    last_usable: u64,
    entry_lba: u64,
    num_entries: u32,
    entry_size: u32,
    entry_crc: u32,
) -> Vec<u8> {
    let mut sector = vec![0u8; sector_size];
    sector[0..8].copy_from_slice(GPT_SIGNATURE);
    sector[8..12].copy_from_slice(&0x0001_0000u32.to_le_bytes());
    sector[12..16].copy_from_slice(&92u32.to_le_bytes());
    sector[24..32].copy_from_slice(&my_lba.to_le_bytes());
    sector[32..40].copy_from_slice(&alternate_lba.to_le_bytes());
    sector[40..48].copy_from_slice(&first_usable.to_le_bytes());
    sector[48..56].copy_from_slice(&last_usable.to_le_bytes());
    sector[56..72].copy_from_slice(&[0x11; 16]);
    sector[72..80].copy_from_slice(&entry_lba.to_le_bytes());
    sector[80..84].copy_from_slice(&num_entries.to_le_bytes());
    sector[84..88].copy_from_slice(&entry_size.to_le_bytes());
    sector[88..92].copy_from_slice(&entry_crc.to_le_bytes());
    let crc = crc32(&sector[..92]);
    sector[16..20].copy_from_slice(&crc.to_le_bytes());
    sector
}

fn write_mbr_entry(entry: &mut [u8], kind: u8, start: u32, count: u32) {
    entry[4] = kind;
    entry[8..12].copy_from_slice(&start.to_le_bytes());
    entry[12..16].copy_from_slice(&count.to_le_bytes());
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct GptPartSpec {
    pub type_guid: [u8; 16],
    pub start_lba: u64,
    pub end_lba: u64,
    pub name: String,
}

#[derive(Clone, Debug)]
pub struct SynthesizedGpt {
    pub mbr: Vec<u8>,
    pub header: Vec<u8>,
    pub entries: Vec<u8>,
    pub backup_header: Vec<u8>,
    pub backup_entries: Vec<u8>,
}

pub fn synthesize_gpt(disk_sectors: u64, sector_size: u32, parts: &[GptPartSpec]) -> Result<SynthesizedGpt, String> {
    if sector_size < 512 || !sector_size.is_power_of_two() {
        return Err("sector size must be a power of two and at least 512".into());
    }
    let num_entries = 128u32;
    let entry_size = 128u32;
    let entry_sectors = entry_sector_count(num_entries, entry_size, sector_size) as u64;
    if disk_sectors < entry_sectors * 2 + 64 {
        return Err("disk is too small for a GPT".into());
    }
    let mut entries = vec![0u8; (num_entries * entry_size) as usize];
    for (index, part) in parts.iter().enumerate() {
        if index >= num_entries as usize {
            break;
        }
        let at = index * 128;
        entries[at..at + 16].copy_from_slice(&part.type_guid);
        entries[at + 16..at + 32].copy_from_slice(&[index as u8 + 1; 16]);
        entries[at + 32..at + 40].copy_from_slice(&part.start_lba.to_le_bytes());
        entries[at + 40..at + 48].copy_from_slice(&part.end_lba.to_le_bytes());
        let name: Vec<u16> = part.name.encode_utf16().take(36).collect();
        for (n, unit) in name.iter().enumerate() {
            entries[at + 56 + n * 2..at + 58 + n * 2].copy_from_slice(&unit.to_le_bytes());
        }
    }
    let entry_crc = crc32(&entries);
    let first_usable = 2 + entry_sectors;
    let last_usable = disk_sectors - entry_sectors - 2;
    let header = build_header_sector(
        sector_size as usize,
        1,
        disk_sectors - 1,
        first_usable,
        last_usable,
        2,
        num_entries,
        entry_size,
        entry_crc,
    );
    let backup_header = build_header_sector(
        sector_size as usize,
        disk_sectors - 1,
        1,
        first_usable,
        last_usable,
        disk_sectors - 1 - entry_sectors,
        num_entries,
        entry_size,
        entry_crc,
    );
    Ok(SynthesizedGpt {
        mbr: protective_mbr(disk_sectors, sector_size as usize),
        header,
        entries: entries.clone(),
        backup_header,
        backup_entries: entries,
    })
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct FoundSignature {
    pub lba: u64,
    pub kind: String,
}

/// Scan a read-only buffer for filesystem boot signatures. `base_lba` is the LBA of byte 0.
pub fn scan_boot_signatures(data: &[u8], base_lba: u64, sector_size: u32) -> Vec<FoundSignature> {
    let sector_size = sector_size.max(512) as usize;
    let mut found = Vec::new();
    if sector_size == 0 {
        return found;
    }
    let mut offset = 0;
    while offset + 512 <= data.len() {
        let sector = &data[offset..offset + 512];
        let lba = base_lba + (offset / sector_size) as u64;
        if let Some(kind) = boot_kind(sector) {
            found.push(FoundSignature { lba, kind });
        }
        offset += sector_size;
        if found.len() >= 64 {
            break;
        }
    }
    found
}

fn boot_kind(sector: &[u8]) -> Option<String> {
    if sector.len() < 512 || sector[510] != 0x55 || sector[511] != 0xAA {
        return None;
    }
    if &sector[3..11] == b"NTFS    " {
        Some("NTFS".into())
    } else if &sector[3..11] == b"EXFAT   " {
        Some("exFAT".into())
    } else if sector.len() >= 0x5A && &sector[0x52..0x5A] == b"FAT32   " {
        Some("FAT32".into())
    } else {
        None
    }
}

/// Build a primary MBR that points at discovered boot sectors (at most four).
pub fn rebuild_mbr_from_signatures(disk_sectors: u64, sector_size: usize, found: &[FoundSignature]) -> Vec<u8> {
    let mut sector = vec![0u8; sector_size.max(512)];
    for (index, sig) in found.iter().take(4).enumerate() {
        let kind = match sig.kind.as_str() {
            "NTFS" | "exFAT" => 0x07,
            "FAT32" => 0x0C,
            _ => 0x07,
        };
        let start = sig.lba.min(u32::MAX as u64) as u32;
        let remaining = disk_sectors.saturating_sub(sig.lba).min(u32::MAX as u64) as u32;
        // One placeholder extent. The user reviews it before anything is written.
        let count = remaining.max(1);
        write_mbr_entry(&mut sector[446 + index * 16..462 + index * 16], kind, start, count);
    }
    sector[510] = 0x55;
    sector[511] = 0xAA;
    sector
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn round_trips_a_gpt_and_restores_a_damaged_primary() {
        let part = GptPartSpec {
            type_guid: BASIC_DATA_GUID,
            start_lba: 34,
            end_lba: 200,
            name: "Data".into(),
        };
        let disk = synthesize_gpt(2048, 512, &[part]).unwrap();
        let ok = analyze_partitions(2048, 512, Some(&disk.mbr), Some(&disk.header), Some(&disk.entries), Some(&disk.backup_header), Some(&disk.backup_entries));
        assert_eq!(ok.style, PartitionStyle::Gpt);
        assert!(ok.problems.is_empty(), "{:?}", ok.problems);
        assert_eq!(ok.partitions[0].name, "Data");

        let mut broken = disk.header.clone();
        broken[0] = b'X';
        let bad = analyze_partitions(2048, 512, Some(&disk.mbr), Some(&broken), Some(&disk.entries), Some(&disk.backup_header), Some(&disk.backup_entries));
        assert!(bad.can_restore_primary_from_backup);
        let writes = gpt_repair_writes(2048, 512, Some(&broken), Some(&disk.entries), Some(&disk.backup_header), Some(&disk.backup_entries)).unwrap();
        assert_eq!(writes[0].lba, 1);
        let restored = analyze_partitions(2048, 512, Some(&disk.mbr), Some(&writes[0].data), Some(&disk.backup_entries), Some(&disk.backup_header), Some(&disk.backup_entries));
        assert!(restored.can_restore_primary_from_backup == false);
        assert_eq!(restored.style, PartitionStyle::Gpt);
        assert!(restored.problems.iter().all(|p| !p.contains("CRC") && !p.contains("signature")));
    }

    #[test]
    fn detects_overlapping_mbr_partitions() {
        let mut sector = vec![0u8; 512];
        write_mbr_entry(&mut sector[446..462], 0x07, 64, 100);
        write_mbr_entry(&mut sector[462..478], 0x07, 100, 50);
        sector[510] = 0x55;
        sector[511] = 0xAA;
        let parsed = analyze_partitions(10_000, 512, Some(&sector), None, None, None, None);
        assert!(parsed.problems.iter().any(|p| p.contains("overlap")));
    }

    #[test]
    fn scans_an_ntfs_boot_sector() {
        let mut data = vec![0u8; 1024];
        data[512 + 3..512 + 11].copy_from_slice(b"NTFS    ");
        data[512 + 510] = 0x55;
        data[512 + 511] = 0xAA;
        let found = scan_boot_signatures(&data, 10, 512);
        assert_eq!(found, vec![FoundSignature { lba: 11, kind: "NTFS".into() }]);
    }
}
