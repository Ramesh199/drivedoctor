use thiserror::Error;

/// Why a write was refused. These are the non-bypassable safety checks.
#[derive(Debug, Error, Clone, PartialEq, Eq)]
pub enum AuthError {
    #[error("refusing to write the system or boot disk")]
    SystemDiskForbidden,
    #[error("data safety gate is locked; image the drive or type its serial to confirm there is no data to keep")]
    SafetyGateLocked,
    #[error("typed confirmation does not match this drive")]
    PhraseMismatch,
    #[error("this drive has no readable serial; image it before any repair that writes")]
    SerialRequired,
    #[error("the device behind this path changed (serial, model, or capacity); aborting")]
    IdentityChanged,
    #[error("hardware fault: write-heavy repair is blocked")]
    HardwareFaultBlocksWrite,
    #[error("a lighter repair is still available; refusing a more destructive step")]
    LighterFixAvailable,
    #[error("this action does not apply to the current diagnosis")]
    ActionNotAllowed,
}

#[derive(Debug, Error)]
pub enum CoreError {
    #[error("{0}")]
    Message(String),
    #[error(transparent)]
    Auth(#[from] AuthError),
}
