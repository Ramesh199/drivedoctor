use crate::model::{ActionId, HardwareFault, PlannedAction, RiskLevel};

/// Facts the diagnosis has already established. Planning does not re-read the disk.
#[derive(Clone, Debug, Default)]
pub struct DiagnosisFacts {
    pub brown_out: bool,
    pub cable_crc: bool,
    pub offline: bool,
    pub read_only: bool,
    pub registry_write_protect: bool,
    pub missing_letter: bool,
    pub bitlocker_locked: bool,
    pub driver_problem: bool,
    pub gpt_restore: bool,
    pub protective_mbr: bool,
    pub partition_corrupt: bool,
    pub partition_empty: bool,
    pub lost_signatures: usize,
    pub ntfs_boot_restore: bool,
    pub exfat_boot_restore: bool,
    pub fs_dirty: bool,
    pub fs_corrupt: bool,
    pub fs_raw: bool,
    pub fs_structurally_ok: bool,
    pub has_letter: bool,
    pub pending: u64,
    pub firmware: bool,
    pub firmware_summary: String,
    pub vendor_name: Option<String>,
    pub vendor_url: Option<String>,
    pub hardware: Option<HardwareFault>,
    pub hpa: bool,
    pub sectors_unreadable: bool,
    pub healthy: bool,
    pub guidance: String,
}

pub fn build_plan(facts: &DiagnosisFacts) -> Vec<PlannedAction> {
    if let Some(hardware) = &facts.hardware {
        let mut plan = Vec::new();
        if hardware.power_down {
            plan.push(action(
                ActionId::PowerDown,
                0,
                RiskLevel::Safe,
                "Power the drive down",
                "Unplug power and USB. Clicking, a seized motor, liquid, or a burnt smell gets worse every time the drive tries to spin.",
                "No bytes are written.",
                "now",
                true,
            ));
        }
        plan.push(action(
            ActionId::ProfessionalHandoff,
            5,
            RiskLevel::Safe,
            "Create a lab handoff report",
            &format!(
                "{}. A clean-room lab can transplant heads or move the ROM. DriveDoctor will not keep retrying this drive.",
                hardware.explanation
            ),
            "No bytes are written. The report is a file on this computer.",
            "a few seconds",
            true,
        ));
        return plan;
    }

    if facts.firmware {
        let where_to = match (&facts.vendor_name, &facts.vendor_url) {
            (Some(name), Some(url)) => format!(" Use the official {name} tool: {url}. DriveDoctor does not flash firmware."),
            _ => " Use the drive maker's official firmware tool. DriveDoctor does not flash firmware.".into(),
        };
        return vec![
            action(
                ActionId::VendorFirmwareGuide,
                3,
                RiskLevel::Safe,
                "Open the vendor firmware guidance",
                &format!("{}{where_to}", facts.firmware_summary),
                "No bytes are written.",
                "depends on the vendor tool",
                true,
            ),
            action(
                ActionId::ProfessionalHandoff,
                5,
                RiskLevel::Safe,
                "Create a lab handoff report",
                "If the vendor tool does not list this drive, a recovery lab is the next step.",
                "No bytes are written.",
                "a few seconds",
                true,
            ),
        ];
    }

    let mut repairs = Vec::new();
    if facts.offline {
        repairs.push(action(
            ActionId::BringOnline,
            0,
            RiskLevel::Safe,
            "Bring the disk online",
            "Windows has the disk marked offline, so sectors cannot be read. This changes the Windows operational state, not file data.",
            "No user data is rewritten.",
            "a few seconds",
            true,
        ));
    }
    if facts.bitlocker_locked {
        repairs.push(action(
            ActionId::UnlockBitLocker,
            0,
            RiskLevel::Safe,
            "Unlock BitLocker",
            "The volume is locked. A locked volume looks corrupt until it is unlocked with your key.",
            "No user data is rewritten. The key is not stored in the case log.",
            "a few seconds",
            true,
        ));
    }
    if facts.read_only {
        repairs.push(action(
            ActionId::ClearReadOnly,
            0,
            RiskLevel::Safe,
            "Clear the read-only flag",
            "Windows has marked the disk read-only. Imaging does not need this. Clear it only when you are ready for a later repair that writes.",
            "Clears a Windows disk attribute. File contents are not rewritten.",
            "a few seconds",
            true,
        ));
    }
    if facts.registry_write_protect {
        repairs.push(action(
            ActionId::ClearRegistryWriteProtect,
            0,
            RiskLevel::Safe,
            "Clear the Windows write-protect policy",
            "HKLM\\...\\StorageDevicePolicies\\WriteProtect is set. That blocks every USB disk, not just this one.",
            "Changes a registry value on this PC. The drive's bytes are not modified.",
            "a few seconds",
            true,
        ));
    }
    if facts.missing_letter && facts.fs_structurally_ok {
        repairs.push(action(
            ActionId::AssignDriveLetter,
            0,
            RiskLevel::Safe,
            "Assign a drive letter",
            "The volume has a file system but Windows has not mounted it.",
            "Creates a mount point. File contents are not rewritten.",
            "a few seconds",
            true,
        ));
    }
    if facts.driver_problem || facts.brown_out {
        repairs.push(action(
            ActionId::RescanDevices,
            0,
            RiskLevel::Safe,
            "Rescan USB storage devices",
            "Ask Windows to rescan devices. DriveDoctor does not delete the USBSTOR driver, because that affects every USB disk on this PC.",
            "No user data is rewritten.",
            "a few seconds",
            true,
        ));
        repairs.push(action(
            ActionId::DisableSelectiveSuspend,
            0,
            RiskLevel::Safe,
            "How to stop USB selective suspend",
            "Selective suspend and a weak port drop external disks. Use a rear port on a desktop, a powered hub, or the drive's own power supply if it is a 3.5 inch disk.",
            "No bytes are written until you change Windows power settings yourself.",
            "a few minutes",
            true,
        ));
    }
    if facts.cable_crc {
        repairs.push(action(
            ActionId::ShowGuidance,
            0,
            RiskLevel::Safe,
            "Replace the cable or bridge",
            "SMART 199 CRC errors count link problems. Try another cable, another port, and then another enclosure before any file-system repair.",
            "No bytes are written.",
            "a few minutes",
            true,
        ));
    }

    if facts.sectors_unreadable {
        repairs.push(action(
            ActionId::ShowGuidance,
            0,
            RiskLevel::Safe,
            "Sector reads were denied",
            "Run DriveDoctor's helper as Administrator to read \\\\.\\PhysicalDriveN. Until that works, partition and file-system results are incomplete, not a diagnosis of corruption.",
            "No bytes are written.",
            "a few seconds",
            true,
        ));
    }

    if facts.gpt_restore {
        repairs.push(meta(
            ActionId::RestoreGpt,
            "Restore the GPT from the surviving copy",
            "One GPT copy failed its CRC and the other still validates. Restoring rewrites the header and partition array, not the files inside the partitions.",
            true,
        ));
    }
    if facts.protective_mbr {
        repairs.push(meta(
            ActionId::FixProtectiveMbr,
            "Rewrite the protective MBR",
            "A GPT disk needs a single 0xEE placeholder in sector 0. This does not change partition contents.",
            true,
        ));
    }
    if facts.partition_corrupt && facts.lost_signatures == 0 && !facts.gpt_restore {
        repairs.push(action(
            ActionId::ScanLostPartitions,
            1,
            RiskLevel::Safe,
            "Scan for lost partition boot sectors",
            "Read the start of the disk looking for NTFS, exFAT, and FAT32 boot sectors. Nothing is written. You review any candidate before a rebuild.",
            "Read-only.",
            "minutes, and longer on a failing drive",
            true,
        ));
    }
    if facts.lost_signatures > 0 && (facts.partition_corrupt || facts.partition_empty) {
        repairs.push(meta(
            ActionId::RebuildMbr,
            "Rebuild an MBR from the boot sectors that were found",
            &format!(
                "{} boot-sector signature(s) were found. The new MBR is shown first and is written only after you confirm it.",
                facts.lost_signatures
            ),
            true,
        ));
    }
    if facts.ntfs_boot_restore {
        repairs.push(meta(
            ActionId::RestoreNtfsBoot,
            "Restore the NTFS boot sector from its backup",
            "The primary boot sector does not validate and the backup copy does. This rewrites one sector at the start of the volume.",
            true,
        ));
    }
    if facts.exfat_boot_restore {
        repairs.push(meta(
            ActionId::RestoreExfatBoot,
            "Recompute the exFAT boot checksum",
            "The boot region checksum does not match. Recomputing it rewrites the checksum sector and leaves file data in place.",
            true,
        ));
    }
    if (facts.fs_dirty || facts.fs_corrupt) && facts.has_letter && !facts.ntfs_boot_restore && !facts.exfat_boot_restore {
        repairs.push(action(
            ActionId::ChkdskDryRun,
            1,
            RiskLevel::Safe,
            "Preview the file-system check",
            "Run chkdsk without /f so you can read what it would change. A metadata backup is stored in the case folder before any later fix.",
            "Read-only preview.",
            "minutes to hours",
            true,
        ));
        repairs.push(meta(
            ActionId::ChkdskFix,
            "Repair the file system with chkdsk /f",
            "Applies the file-system repair after the preview. Orphaned records may be moved to found.000. The metadata region is backed up first so this can be rolled back.",
            true,
        ));
    }

    if facts.pending > 0 && facts.fs_structurally_ok {
        repairs.push(action(
            ActionId::SurfaceScan,
            2,
            RiskLevel::Safe,
            "Read-only surface scan",
            "Read the disk in zones and record unreadable LBAs. This does not regenerate the magnetic surface. Stop if the drive starts clicking.",
            "Read-only. It does stress a weak drive.",
            "hours on a large disk",
            true,
        ));
        repairs.push(action(
            ActionId::RemapPendingSectors,
            2,
            RiskLevel::TargetedLoss,
            "Ask the drive to remap unreadable sectors",
            "Writing a sector the drive cannot read makes its firmware retire that LBA and use a spare. The bytes that were in the bad sector are gone. This does not repair the platter.",
            "Destroys data only in sectors that are already unreadable.",
            "minutes, depending on how many sectors are pending",
            true,
        ));
        repairs.push(action(
            ActionId::MarkBadClusters,
            2,
            RiskLevel::Metadata,
            "Mark the bad clusters in the file system",
            "After a remap, mark those clusters in $BadClus (NTFS) or the FAT so Windows stops using them.",
            "Writes file-system metadata.",
            "minutes",
            true,
        ));
    }

    let lighter_structural = repairs.iter().any(|item| item.recommended && item.level <= 1);
    let structure_dead = facts.fs_raw && !facts.gpt_restore && facts.lost_signatures == 0 && !facts.fs_structurally_ok;
    if structure_dead && !lighter_structural {
        if facts.pending > 0 {
            repairs.push(destroy(
                ActionId::ZeroFill,
                3,
                "Write zeros across the whole disk",
                "A full write forces the firmware to remap weak sectors, then a read-back checks them. Every file on the disk is erased. Do this only after an image, or after you confirm there is nothing to keep.",
                true,
            ));
        }
        repairs.push(destroy(
            ActionId::CreatePartitionAndFormat,
            4,
            "Partition and format the disk",
            "Create a new GPT and format it (exFAT for sharing, NTFS for Windows). Existing files will not be accessible through the new file system.",
            true,
        ));
    }

    // Heavier steps stay visible and locked while a lighter fix exists.
    if !structure_dead || lighter_structural {
        if facts.pending > 0 && !repairs.iter().any(|item| item.id == ActionId::ZeroFill) {
            repairs.push(destroy(
                ActionId::ZeroFill,
                3,
                "Write zeros across the whole disk",
                "Not recommended while a less destructive repair is available. A full write erases every file and only then asks the firmware to remap weak sectors.",
                false,
            ));
        }
        if !repairs.iter().any(|item| item.id == ActionId::CreatePartitionAndFormat) {
            repairs.push(destroy(
                ActionId::CreatePartitionAndFormat,
                4,
                "Partition and format the disk",
                "Not recommended while the current partition table or file system can still be repaired.",
                false,
            ));
        }
    }
    if !repairs.iter().any(|item| item.id == ActionId::SecureErase) {
        repairs.push(destroy(
            ActionId::SecureErase,
            3,
            "ATA secure erase or NVMe sanitize",
            "Secure erase destroys every sector. Most USB bridges do not pass the command; DriveDoctor will refuse and tell you to connect SATA or NVMe directly instead of pretending the erase worked.",
            false,
        ));
    }
    if facts.hpa {
        repairs.push(destroy(
            ActionId::RemoveHpa,
            3,
            "Remove a Host Protected Area",
            "SET MAX ADDRESS can reveal hidden capacity and can also make the drive unreadable if it is used on the wrong disk. The current size is left alone unless you type the erase phrase.",
            false,
        ));
    }

    let mut plan = Vec::new();
    let needs_gate = repairs.iter().any(|item| item.requires_gate && item.recommended);
    if needs_gate {
        plan.push(action(
            ActionId::ProtectData,
            0,
            RiskLevel::Safe,
            "Protect the data first",
            "Clone the disk to another physical disk with a resumable, multi-pass copy (copy, trim, scrape, retry). Repairs that write stay locked until this finishes, or until you type the serial to confirm there is no data to keep.",
            "The source is opened read-only. The image is a new file on a different disk.",
            "hours on a large or failing disk",
            true,
        ));
    }
    if !facts.guidance.is_empty() {
        plan.insert(
            0,
            action(
                ActionId::ShowGuidance,
                0,
                RiskLevel::Safe,
                "Read the connection guidance",
                &facts.guidance,
                "No bytes are written.",
                "a few minutes",
                true,
            ),
        );
    }
    plan.extend(repairs);
    if facts.healthy && !plan.iter().any(|item| item.recommended) {
        plan.push(action(
            ActionId::SmartShortTest,
            0,
            RiskLevel::Safe,
            "Run a SMART short self-test",
            "Optional. The drive updates its self-test log. User files are not modified.",
            "No user data is rewritten.",
            "about two minutes",
            false,
        ));
    }
    plan
}

pub fn first_recommended(plan: &[PlannedAction]) -> Option<ActionId> {
    plan.iter().find(|item| item.recommended).map(|item| item.id)
}

fn action(
    id: ActionId,
    level: u8,
    risk: RiskLevel,
    title: &str,
    summary: &str,
    data_effect: &str,
    estimated_time: &str,
    recommended: bool,
) -> PlannedAction {
    PlannedAction {
        id,
        level,
        title: title.to_owned(),
        summary: summary.to_owned(),
        risk,
        data_effect: data_effect.to_owned(),
        estimated_time: estimated_time.to_owned(),
        recommended,
        requires_gate: risk.writes_disk(),
        requires_typed_serial: risk.writes_disk(),
    }
}

fn meta(id: ActionId, title: &str, summary: &str, recommended: bool) -> PlannedAction {
    action(
        id,
        1,
        RiskLevel::Metadata,
        title,
        summary,
        "Rewrites a small metadata structure. File contents stay where they are. The previous bytes are saved in the case folder.",
        "seconds, after the safety gate is open",
        recommended,
    )
}

fn destroy(id: ActionId, level: u8, title: &str, summary: &str, recommended: bool) -> PlannedAction {
    action(
        id,
        level,
        RiskLevel::DestroysAll,
        title,
        summary,
        "Destroys all data on the selected disk.",
        "hours for a full-surface pass",
        recommended,
    )
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::HardwareFaultKind;

    #[test]
    fn gpt_damage_does_not_skip_to_a_format() {
        let plan = build_plan(&DiagnosisFacts { gpt_restore: true, ..DiagnosisFacts::default() });
        assert_eq!(plan[0].id, ActionId::ProtectData);
        assert!(plan.iter().any(|item| item.id == ActionId::RestoreGpt && item.recommended));
        assert!(plan.iter().any(|item| item.id == ActionId::CreatePartitionAndFormat && !item.recommended));
    }

    #[test]
    fn clicking_never_offers_chkdsk_or_a_wipe() {
        let plan = build_plan(&DiagnosisFacts {
            hardware: Some(crate::model::HardwareFault {
                kind: HardwareFaultKind::HeadCrash,
                explanation: "Clicking.".into(),
                next_steps: vec![],
                power_down: true,
            }),
            fs_corrupt: true,
            pending: 10,
            ..DiagnosisFacts::default()
        });
        assert!(plan.iter().all(|item| {
            !matches!(item.id, ActionId::ChkdskFix | ActionId::ZeroFill | ActionId::RestoreGpt)
        }));
        assert_eq!(plan[0].id, ActionId::PowerDown);
    }

    #[test]
    fn pending_sectors_on_a_healthy_file_system_stay_targeted() {
        let plan = build_plan(&DiagnosisFacts {
            pending: 4,
            fs_structurally_ok: true,
            ..DiagnosisFacts::default()
        });
        assert!(plan.iter().any(|item| item.id == ActionId::RemapPendingSectors && item.recommended));
        assert!(plan.iter().any(|item| item.id == ActionId::ZeroFill && !item.recommended));
    }

    #[test]
    fn a_blank_disk_can_be_formatted_after_imaging() {
        let plan = build_plan(&DiagnosisFacts {
            fs_raw: true,
            partition_empty: true,
            ..DiagnosisFacts::default()
        });
        assert!(plan.iter().any(|item| item.id == ActionId::CreatePartitionAndFormat && item.recommended));
        assert!(!plan.iter().any(|item| item.id == ActionId::ZeroFill && item.recommended));
    }
}
