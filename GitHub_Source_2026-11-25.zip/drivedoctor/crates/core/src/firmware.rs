use crate::model::DriveIdentity;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct FirmwareAssessment {
    pub suspected: bool,
    pub summary: String,
    pub vendor_url: Option<&'static str>,
    pub vendor_name: Option<&'static str>,
}

/// Known firmware failures and capacity lies. This never flashes firmware.
pub fn assess_firmware(identity: &DriveIdentity) -> FirmwareAssessment {
    let model = identity.model.to_uppercase();
    let vendor = vendor_of(&model);
    if model.contains("ST_M13FQBL") || looks_like_factory_alias(&model) {
        return hit(
            "The model string is a factory alias rather than the retail model. That usually means the drive firmware did not finish identifying itself.",
            vendor,
        );
    }
    if is_seagate_7200_11(&model) {
        return hit(
            "This model is in the Seagate 7200.11 family, which has a known firmware fault (BSY / 0 LBA). DriveDoctor will not try to repair that firmware.",
            vendor,
        );
    }
    if identity.capacity_bytes == 0 && !looks_like_empty_reader(&model) {
        return hit(
            "The drive reports 0 bytes. If it is not an empty card reader, the firmware is not presenting the media (BSY or LBA 0).",
            vendor,
        );
    }
    // The widely reported "about 3.86 GB" identification failure.
    let tiny = (3_700_000_000..4_000_000_000).contains(&identity.capacity_bytes);
    if tiny && !looks_like_empty_reader(&model) && !model_claims_small_disk(&model) {
        return hit(
            "The drive reports about 3.86 GB, a classic firmware identification failure on a much larger disk.",
            vendor,
        );
    }
    FirmwareAssessment {
        suspected: false,
        summary: String::new(),
        vendor_url: vendor.map(|(_, url)| url),
        vendor_name: vendor.map(|(name, _)| name),
    }
}

fn hit(summary: &str, vendor: Option<(&'static str, &'static str)>) -> FirmwareAssessment {
    FirmwareAssessment {
        suspected: true,
        summary: summary.to_owned(),
        vendor_url: vendor.map(|(_, url)| url),
        vendor_name: vendor.map(|(name, _)| name),
    }
}

fn is_seagate_7200_11(model: &str) -> bool {
    const MODELS: &[&str] = &[
        "ST31500341AS",
        "ST31000333AS",
        "ST3640323AS",
        "ST3640530AS",
        "ST3320613AS",
        "ST3320813AS",
        "ST3160813AS",
        "ST3500320AS",
        "ST3500620AS",
        "ST3500820AS",
        "ST31000340AS",
    ];
    MODELS.iter().any(|known| model.contains(known))
}

fn looks_like_factory_alias(model: &str) -> bool {
    let compact: String = model.chars().filter(|c| !c.is_whitespace()).collect();
    let mut parts = compact.split('_');
    match (parts.next(), parts.next(), parts.next()) {
        (Some(prefix), Some(rest), None) if prefix.len() == 2 && rest.len() >= 6 && prefix.chars().all(|c| c.is_ascii_uppercase()) => {
            rest.chars().all(|c| c.is_ascii_uppercase() || c.is_ascii_digit())
        }
        _ => false,
    }
}

pub fn looks_like_empty_reader(model: &str) -> bool {
    let model = model.to_lowercase();
    ["card reader", "cardreader", "sd/mmc", "compact flash", "cf reader"]
        .iter()
        .any(|needle| model.contains(needle))
}

fn model_claims_small_disk(model: &str) -> bool {
    model.contains("4GB") || model.contains("8GB") || model.contains(" 4G")
}

pub fn vendor_of(model: &str) -> Option<(&'static str, &'static str)> {
    let model = model.to_uppercase();
    if model.starts_with("ST") || model.contains("SEAGATE") {
        Some(("Seagate", "https://www.seagate.com/support/downloads/"))
    } else if model.starts_with("WDC") || model.starts_with("WD") || model.contains("WESTERN") {
        Some(("Western Digital", "https://support.wdc.com/"))
    } else if model.starts_with("TOSHIBA") || model.starts_with("DT") || model.starts_with("MQ") || model.starts_with("HDW") {
        Some(("Toshiba", "https://www.toshiba-storage.com/support/"))
    } else if model.starts_with("SAMSUNG") || model.starts_with("SSD") {
        Some(("Samsung", "https://semiconductor.samsung.com/consumer-storage/support/"))
    } else if model.contains("CRUCIAL") || model.starts_with("CT") {
        Some(("Crucial", "https://www.crucial.com/support/"))
    } else if model.contains("NVME") || model.contains("INTEL") || model.starts_with("SSDPE") {
        Some(("Intel", "https://www.intel.com/content/www/us/en/download-center/home.html"))
    } else {
        None
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::model::DriveIdentity;

    fn id(model: &str, bytes: u64) -> DriveIdentity {
        DriveIdentity {
            disk_number: 1,
            device_path: r"\\.\PhysicalDrive1".into(),
            model: model.into(),
            serial: "S".into(),
            firmware: String::new(),
            capacity_bytes: bytes,
            logical_sector_size: 512,
            physical_sector_size: 512,
            bus: "USB".into(),
            is_boot: false,
            is_system: false,
            pnp_id: String::new(),
            vid: None,
            pid: None,
            usb_product: String::new(),
        }
    }

    #[test]
    fn flags_factory_alias_and_7200_11() {
        assert!(assess_firmware(&id("ST_M13FQBL", 0)).suspected);
        assert!(assess_firmware(&id("ST31500341AS", 1_500_000_000_000)).suspected);
        assert!(!assess_firmware(&id("ST2000DM008", 2_000_000_000_000)).suspected);
    }

    #[test]
    fn empty_card_reader_is_not_a_firmware_fault() {
        assert!(!assess_firmware(&id("USB Card Reader", 0)).suspected);
    }
}
