use serde::{Deserialize, Serialize};

use crate::smart::SmartAssessment;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TrustVerdict {
    Healthy,
    UsableWithBackups,
    Unreliable,
    Retire,
}

impl TrustVerdict {
    pub fn label(self) -> &'static str {
        match self {
            Self::Healthy => "Healthy, safe for daily use",
            Self::UsableWithBackups => "Usable, but keep backups",
            Self::Unreliable => "Unreliable, use only for non-critical temporary data",
            Self::Retire => "Retire, failing or hardware fault",
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct TrustScore {
    pub score: u8,
    pub verdict: TrustVerdict,
    pub reasons: Vec<String>,
}

#[derive(Clone, Debug)]
pub struct TrustInput {
    pub smart: SmartAssessment,
    pub hardware_fault: bool,
    pub self_test_failed: bool,
    pub realloc_increased: bool,
    pub pending_increased: bool,
    pub surface_unreadable_zones: u32,
}

pub fn trust_score(input: &TrustInput) -> TrustScore {
    if input.hardware_fault {
        return TrustScore {
            score: 5,
            verdict: TrustVerdict::Retire,
            reasons: vec!["A hardware fault was identified. Software cannot make this drive trustworthy.".into()],
        };
    }
    let smart = &input.smart;
    let mut score: i32 = 100;
    let mut reasons = Vec::new();
    if smart.pending > 0 {
        score -= 30;
        reasons.push(format!("{} pending sector(s) are still waiting for remap.", smart.pending));
    }
    if smart.uncorrectable > 0 {
        score -= 20;
        reasons.push(format!("{} offline uncorrectable sector(s).", smart.uncorrectable));
    }
    if smart.reported_uncorrectable > 0 {
        score -= 10;
    }
    if smart.reallocated > 0 && smart.reallocated < 20 {
        score -= 8;
        reasons.push(format!(
            "{} reallocated sector(s). Stable spares are a scar, not a cure. Keep backups.",
            smart.reallocated
        ));
    } else if smart.reallocated >= 20 {
        score -= 25;
        reasons.push(format!("{} reallocated sectors. The spare pool is being used heavily.", smart.reallocated));
    }
    if input.realloc_increased || input.pending_increased {
        score -= 40;
        reasons.push("Reallocated or pending counts increased during testing. The drive is still degrading.".into());
    }
    if smart.spin_retry > 0 {
        score -= 25;
        reasons.push("Spin retries indicate the motor or power path is unreliable.".into());
    }
    if smart.command_timeout > 0 {
        score -= 10;
    }
    if smart.udma_crc > 0 {
        score -= 8;
        reasons.push("Interface CRC errors point at the cable, port, or USB bridge.".into());
    }
    if input.self_test_failed {
        score -= 25;
        reasons.push("The drive failed its SMART self-test.".into());
    }
    if smart.temperature_c.unwrap_or(0) >= 60 {
        score -= 15;
        reasons.push("Temperature reached 60°C or more.".into());
    } else if smart.temperature_c.unwrap_or(0) >= 55 {
        score -= 8;
    }
    if smart.nvme_media_errors > 0 {
        score -= 30;
    }
    if smart.nvme_critical_warning != 0 {
        score -= 35;
    }
    if smart.nvme_percentage_used > 90 {
        score -= 15;
        reasons.push("NVMe wear is above 90%.".into());
    }
    if input.surface_unreadable_zones > 0 {
        score -= (input.surface_unreadable_zones as i32 * 5).min(25);
        reasons.push(format!(
            "{} surface zone(s) had unreadable sectors.",
            input.surface_unreadable_zones
        ));
    }
    if smart.verdict == crate::smart::SmartVerdict::Unknown {
        score -= 15;
        reasons.push("SMART could not be read, so this score is incomplete.".into());
    }
    let score = score.clamp(0, 100) as u8;
    let verdict = if input.realloc_increased || input.pending_increased || smart.spin_retry > 5 || smart.pending > 50 {
        TrustVerdict::Retire
    } else if smart.pending > 0 || input.self_test_failed || smart.nvme_critical_warning != 0 || score < 50 {
        TrustVerdict::Retire
    } else if smart.reallocated > 0 || smart.udma_crc > 0 || score < 90 {
        if score >= 75 {
            TrustVerdict::UsableWithBackups
        } else {
            TrustVerdict::Unreliable
        }
    } else if score >= 90 {
        TrustVerdict::Healthy
    } else if score >= 75 {
        TrustVerdict::UsableWithBackups
    } else if score >= 50 {
        TrustVerdict::Unreliable
    } else {
        TrustVerdict::Retire
    };
    // Any stable reallocation keeps the drive out of the "daily driver" band.
    let verdict = if smart.reallocated > 0 && verdict == TrustVerdict::Healthy {
        TrustVerdict::UsableWithBackups
    } else {
        verdict
    };
    if reasons.is_empty() {
        reasons.push("Watched SMART attributes are in range and no hardware fault was found.".into());
    }
    TrustScore { score, verdict, reasons }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::smart::{assess_smart, SmartAttribute, SmartDump, SmartVerdict};

    fn from_attrs(attrs: Vec<SmartAttribute>) -> SmartAssessment {
        assess_smart(
            &SmartDump {
                attributes: attrs,
                passed: Some(true),
                ..SmartDump::default()
            },
            100,
        )
    }

    fn attr(id: u8, raw: u64) -> SmartAttribute {
        SmartAttribute { id, name: String::new(), current: 100, worst: 100, threshold: 0, raw, prefail: false }
    }

    #[test]
    fn clean_drive_is_healthy() {
        let score = trust_score(&TrustInput {
            smart: from_attrs(vec![attr(5, 0), attr(197, 0)]),
            hardware_fault: false,
            self_test_failed: false,
            realloc_increased: false,
            pending_increased: false,
            surface_unreadable_zones: 0,
        });
        assert_eq!(score.verdict, TrustVerdict::Healthy);
        assert!(score.score >= 90);
    }

    #[test]
    fn stable_reallocations_need_backups() {
        let score = trust_score(&TrustInput {
            smart: from_attrs(vec![attr(5, 4)]),
            hardware_fault: false,
            self_test_failed: false,
            realloc_increased: false,
            pending_increased: false,
            surface_unreadable_zones: 0,
        });
        assert_eq!(score.verdict, TrustVerdict::UsableWithBackups);
        assert!(score.score < 100);
    }

    #[test]
    fn growing_pending_retires_the_drive() {
        let smart = from_attrs(vec![attr(197, 2)]);
        assert_eq!(smart.verdict, SmartVerdict::Failing);
        let score = trust_score(&TrustInput {
            smart,
            hardware_fault: false,
            self_test_failed: false,
            realloc_increased: false,
            pending_increased: true,
            surface_unreadable_zones: 0,
        });
        assert_eq!(score.verdict, TrustVerdict::Retire);
    }
}
